from __future__ import annotations

import csv
import hashlib
import io
import math
import os
import random
import re
import shutil
import statistics
import sys
import zipfile
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parents[1]

RUNTIME_ZIP = ROOT / "KOUCHA_GOLD_TA9_SHADOW_RUNTIME_REGRESSION_AUDIT.zip"
CANDIDATE_ZIP = ROOT / "KOUCHA_GOLD_TIMING_ALIGNMENT_CANDIDATE_SAFETY_AUDIT.zip"
MULTI_AXIS_ZIP = ROOT / "KOUCHA_GOLD_TIMING_ALIGNMENT_MULTI_AXIS_AUDIT.zip"
SOURCE = ROOT / "KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5"
EXPECTED = {
    RUNTIME_ZIP.name: "07E61AE4ED26AFAE4041CF9F9B93BD8D103299D98580EA42BF647B9024532423",
    CANDIDATE_ZIP.name: "7A8008A27F20184188423E18193F27BD918D0003B404A814092BB7FEF5DC1C24",
    MULTI_AXIS_ZIP.name: "01574CC3481878A15B11B54ECC866E8618C33E9715D36AA22E8B1F6058F037D4",
    SOURCE.name: "1353718F46D727DB775827AAF30F86EC790056CB59CE46EB00D5BAD563EF1DE3",
}

CLOSE_TYPES = {
    "BASKET_CLOSE",
    "HARDSTOP_CLOSE",
    "HEDGED_BASKET_TIME_EXIT",
    "RECOVERY_CLOSE",
    "RECOVERY_LOSS_CUT",
}
ENTRY_TYPES = {"ENTRY_BUY", "ENTRY_SELL"}
HEDGE_TYPES = {"DEFENSE_HEDGE_BUY", "DEFENSE_HEDGE_SELL"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def fnum(value, default=0.0):
    if value is None:
        return default
    s = str(value).strip()
    if not s or s.upper() == "NA":
        return default
    try:
        return float(s)
    except ValueError:
        return default


def parse_dt(s: str):
    if not s:
        return None
    return datetime.strptime(s, "%Y.%m.%d %H:%M:%S")


def seconds_between(a: str, b: str) -> int:
    da = parse_dt(a)
    db = parse_dt(b)
    if not da or not db:
        return 0
    return int((db - da).total_seconds())


def write_csv(path: Path, rows: list[dict], fieldnames: list[str] | None = None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys = []
        for row in rows:
            for k in row:
                if k not in keys:
                    keys.append(k)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def pct(values, p):
    vals = sorted(v for v in values if v is not None)
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    pos = (len(vals) - 1) * p
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return vals[lo]
    return vals[lo] * (hi - pos) + vals[hi] * (pos - lo)


def avg(values):
    vals = [v for v in values if v is not None]
    return sum(vals) / len(vals) if vals else None


def med(values):
    vals = [v for v in values if v is not None]
    return statistics.median(vals) if vals else None


def gini(values):
    vals = sorted(abs(v) for v in values if v is not None and abs(v) > 0)
    n = len(vals)
    if n == 0:
        return None
    total = sum(vals)
    return (2 * sum((i + 1) * x for i, x in enumerate(vals)) / (n * total)) - (n + 1) / n


def run_meta(run_name: str) -> dict:
    m = re.match(
        r"TA9_A_FRESH_BASELINE_(?P<deposit>\d+)_(?P<label>.+)_M5_(?P<start>\d{8})_(?P<end>\d{8})",
        run_name,
    )
    if not m:
        return {"run_id": run_name, "deposit": "", "period_start": "", "period_end": "", "period_label": ""}
    start = datetime.strptime(m.group("start"), "%Y%m%d").strftime("%Y.%m.%d")
    end = datetime.strptime(m.group("end"), "%Y%m%d").strftime("%Y.%m.%d")
    return {
        "run_id": run_name,
        "deposit": int(m.group("deposit")),
        "period_start": start,
        "period_end": end,
        "period_label": f"{start}-{end}",
    }


def load_trade_events():
    runs = []
    with zipfile.ZipFile(RUNTIME_ZIP) as z:
        names = [
            n for n in z.namelist()
            if n.endswith("_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv")
            and "/TA9_A_FRESH_BASELINE_" in "/" + n
        ]
        for name in sorted(names):
            run_name = name.split("/")[0]
            data = z.read(name).decode("utf-8-sig", errors="replace")
            rows = list(csv.DictReader(io.StringIO(data)))
            meta = run_meta(run_name)
            meta["zip_member"] = name
            meta["row_count"] = len(rows)
            runs.append((meta, rows))
    return runs


def reconstruct_baskets(meta: dict, rows: list[dict]):
    baskets = []
    audit = []
    close_rows = []
    current = None
    seq = 0
    i = 0
    while i < len(rows):
        r = rows[i]
        et = r.get("EventType", "")
        t = r.get("ServerTime") or r.get("TesterTime")
        if et in ENTRY_TYPES:
            if current is None:
                seq += 1
                current = {
                    "run_id": meta["run_id"],
                    "period_start": meta["period_start"],
                    "period_end": meta["period_end"],
                    "period_label": meta["period_label"],
                    "deposit": meta["deposit"],
                    "symbol": r.get("Symbol", "GOLD"),
                    "basket_sequence": seq,
                    "basket_start_time": t,
                    "basket_uid": f"{meta['run_id']}|{r.get('Symbol','GOLD')}|{t}|SEQ{seq}",
                    "entry_count": 0,
                    "hedge_count": 0,
                    "close_row_count": 0,
                    "max_simultaneous_positions": 0,
                    "current_positions": 0,
                    "starting_balance": fnum(r.get("Balance")),
                    "first_entry_direction": r.get("OrderDirection", ""),
                    "hedged": False,
                    "join_status": "CLOSED_BASKET",
                    "raw_close_profit_sum": 0.0,
                    "close_tickets": [],
                }
            current["entry_count"] += 1
            current["current_positions"] += 1
            current["max_simultaneous_positions"] = max(current["max_simultaneous_positions"], current["current_positions"])
            audit.append({"run_id": meta["run_id"], "event_index": i, "event_type": et, "action": "ENTRY_ADDED", "basket_sequence": current["basket_sequence"], "time": t})
            i += 1
            continue
        if et in HEDGE_TYPES:
            if current is None:
                seq += 1
                current = {
                    "run_id": meta["run_id"],
                    "period_start": meta["period_start"],
                    "period_end": meta["period_end"],
                    "period_label": meta["period_label"],
                    "deposit": meta["deposit"],
                    "symbol": r.get("Symbol", "GOLD"),
                    "basket_sequence": seq,
                    "basket_start_time": t,
                    "basket_uid": f"{meta['run_id']}|{r.get('Symbol','GOLD')}|{t}|SEQ{seq}|AMBIG_HEDGE_START",
                    "entry_count": 0,
                    "hedge_count": 0,
                    "close_row_count": 0,
                    "max_simultaneous_positions": 0,
                    "current_positions": 0,
                    "starting_balance": fnum(r.get("Balance")),
                    "first_entry_direction": "",
                    "hedged": True,
                    "join_status": "JOIN_AMBIGUOUS",
                    "raw_close_profit_sum": 0.0,
                    "close_tickets": [],
                }
            current["hedged"] = True
            current["hedge_count"] += 1
            current["current_positions"] += 1
            current["max_simultaneous_positions"] = max(current["max_simultaneous_positions"], current["current_positions"])
            audit.append({"run_id": meta["run_id"], "event_index": i, "event_type": et, "action": "HEDGE_ADDED", "basket_sequence": current["basket_sequence"], "time": t})
            i += 1
            continue
        if et in CLOSE_TYPES:
            if current is None:
                seq += 1
                current = {
                    "run_id": meta["run_id"],
                    "period_start": meta["period_start"],
                    "period_end": meta["period_end"],
                    "period_label": meta["period_label"],
                    "deposit": meta["deposit"],
                    "symbol": r.get("Symbol", "GOLD"),
                    "basket_sequence": seq,
                    "basket_start_time": t,
                    "basket_uid": f"{meta['run_id']}|{r.get('Symbol','GOLD')}|{t}|SEQ{seq}|AMBIG_CLOSE_START",
                    "entry_count": 0,
                    "hedge_count": 0,
                    "close_row_count": 0,
                    "max_simultaneous_positions": 0,
                    "current_positions": 0,
                    "starting_balance": None,
                    "first_entry_direction": "",
                    "hedged": False,
                    "join_status": "JOIN_AMBIGUOUS",
                    "raw_close_profit_sum": 0.0,
                    "close_tickets": [],
                }
            j = i
            group = []
            while j < len(rows):
                rr = rows[j]
                if rr.get("EventType") == et and (rr.get("ServerTime") or rr.get("TesterTime")) == t:
                    group.append(rr)
                    j += 1
                else:
                    break
            profit_sum = sum(fnum(x.get("ProfitYen")) for x in group)
            last = group[-1]
            current.update({
                "basket_end_time": t,
                "final_close_reason": et,
                "close_row_count": len(group),
                "gross_profit": profit_sum,
                "swap": "NA",
                "commission": "NA",
                "fee": "NA",
                "net_profit": profit_sum,
                "ending_balance": fnum(last.get("Balance")),
                "return_on_deposit": profit_sum / meta["deposit"] if meta.get("deposit") else None,
                "holding_seconds": seconds_between(current["basket_start_time"], t),
                "holding_minutes": seconds_between(current["basket_start_time"], t) / 60.0,
                "resolved": True,
                "pre_post_hedge": "POST_HEDGE" if current["hedged"] else "PRE_HEDGE",
                "basket_net_profit_field": fnum(last.get("BasketNetProfitYen")),
                "close_tickets": ";".join(x.get("Ticket", "") for x in group),
            })
            current["max_simultaneous_positions"] = max(current["max_simultaneous_positions"], current["entry_count"] + current["hedge_count"])
            current["hedge_lifecycle_class"] = classify_hedge_lifecycle(current)
            baskets.append(current)
            for x in group:
                close_rows.append({**meta, **x})
            audit.append({"run_id": meta["run_id"], "event_index": i, "event_type": et, "action": "BASKET_CLOSED", "basket_sequence": current["basket_sequence"], "time": t, "close_rows": len(group), "profit_sum": profit_sum})
            current = None
            i = j
            continue
        i += 1
    if current is not None:
        current.update({
            "basket_end_time": "",
            "final_close_reason": "UNRESOLVED_OR_END_OPEN",
            "gross_profit": "NA",
            "swap": "NA",
            "commission": "NA",
            "fee": "NA",
            "net_profit": "NA",
            "ending_balance": "",
            "return_on_deposit": "NA",
            "holding_seconds": "",
            "holding_minutes": "",
            "resolved": False,
            "pre_post_hedge": "POST_HEDGE" if current["hedged"] else "PRE_HEDGE",
            "hedge_lifecycle_class": "Hedged and Unresolved" if current["hedged"] else "Unresolved Never Hedged",
            "final_close_reason": "UNRESOLVED_OR_END_OPEN",
        })
        baskets.append(current)
        audit.append({"run_id": meta["run_id"], "event_index": len(rows), "event_type": "EOF", "action": "UNRESOLVED_END_OPEN", "basket_sequence": current["basket_sequence"], "time": ""})
    return baskets, audit, close_rows


def classify_hedge_lifecycle(b):
    if not b.get("hedged"):
        return "Never Hedged"
    reason = b.get("final_close_reason")
    if reason == "HEDGED_BASKET_TIME_EXIT":
        return "Hedged and HTE"
    if reason == "HARDSTOP_CLOSE":
        return "Hedged and HardStop"
    if reason in {"RECOVERY_CLOSE", "BASKET_CLOSE"}:
        return "Hedged and Recovered"
    if reason == "UNRESOLVED_OR_END_OPEN":
        return "Hedged and Unresolved"
    return "Other"


def metrics_for(rows: list[dict]) -> dict:
    closed = [r for r in rows if str(r.get("resolved")) == "True" or r.get("resolved") is True]
    pnl = [fnum(r.get("net_profit")) for r in closed]
    wins = [x for x in pnl if x > 0]
    losses = [x for x in pnl if x < 0]
    breakeven = [x for x in pnl if x == 0]
    gp = sum(wins)
    gl = sum(losses)
    avg_win = avg(wins)
    avg_loss = avg(losses)
    med_win = med(wins)
    med_loss = med(losses)
    wr = len(wins) / len(closed) if closed else None
    lr = len(losses) / len(closed) if closed else None
    payoff = (avg_win / abs(avg_loss)) if avg_win is not None and avg_loss not in (None, 0) else None
    median_payoff = (med_win / abs(med_loss)) if med_win is not None and med_loss not in (None, 0) else None
    if wr is not None:
        win_component = wr * (avg_win if avg_win is not None else 0.0)
        loss_component = lr * abs(avg_loss if avg_loss is not None else 0.0)
        expectancy = win_component - loss_component
    else:
        expectancy = None
    pf = gp / abs(gl) if gl < 0 else None
    abs_losses = [abs(x) for x in losses]
    return {
        "total_basket_count": len(rows),
        "closed_basket_count": len(closed),
        "unresolved_basket_count": len(rows) - len(closed),
        "winning_basket_count": len(wins),
        "losing_basket_count": len(losses),
        "breakeven_basket_count": len(breakeven),
        "basket_win_rate": wr,
        "average_winning_basket_yen": avg_win,
        "median_winning_basket_yen": med_win,
        "maximum_winning_basket_yen": max(wins) if wins else None,
        "p75_winning_basket_yen": pct(wins, 0.75),
        "p90_winning_basket_yen": pct(wins, 0.90),
        "p95_winning_basket_yen": pct(wins, 0.95),
        "average_losing_basket_yen": avg_loss,
        "median_losing_basket_yen": med_loss,
        "worst_losing_basket_yen": min(losses) if losses else None,
        "p75_abs_loss_yen": pct(abs_losses, 0.75),
        "p90_abs_loss_yen": pct(abs_losses, 0.90),
        "p95_abs_loss_yen": pct(abs_losses, 0.95),
        "p99_abs_loss_yen": pct(abs_losses, 0.99),
        "payoff_ratio": payoff,
        "median_payoff_ratio": median_payoff,
        "expectancy_per_basket_yen": expectancy,
        "profit_factor": pf,
        "gross_profit_yen": gp,
        "gross_loss_yen": gl,
        "net_profit_yen": sum(pnl),
        "average_holding_minutes": avg([fnum(r.get("holding_minutes")) for r in closed]),
        "win_holding_minutes": avg([fnum(r.get("holding_minutes")) for r in closed if fnum(r.get("net_profit")) > 0]),
        "loss_holding_minutes": avg([fnum(r.get("holding_minutes")) for r in closed if fnum(r.get("net_profit")) < 0]),
    }


def streaks(rows: list[dict]):
    ordered = sorted([r for r in rows if r.get("resolved") is True], key=lambda r: (r["run_id"], r["basket_start_time"], r["basket_sequence"]))
    max_loss = max_win = 0
    cur_loss = cur_win = 0
    cur_loss_yen = cur_win_yen = 0
    max_loss_yen = max_win_yen = 0
    for r in ordered:
        pnl = fnum(r["net_profit"])
        if pnl < 0:
            cur_loss += 1
            cur_loss_yen += pnl
            cur_win = 0
            cur_win_yen = 0
        elif pnl > 0:
            cur_win += 1
            cur_win_yen += pnl
            cur_loss = 0
            cur_loss_yen = 0
        else:
            cur_loss = cur_win = 0
            cur_loss_yen = cur_win_yen = 0
        max_loss = max(max_loss, cur_loss)
        max_win = max(max_win, cur_win)
        max_loss_yen = min(max_loss_yen, cur_loss_yen)
        max_win_yen = max(max_win_yen, cur_win_yen)
    return {
        "maximum_consecutive_losing_baskets": max_loss,
        "maximum_consecutive_winning_baskets": max_win,
        "largest_losing_streak_yen": max_loss_yen,
        "largest_winning_streak_yen": max_win_yen,
    }


def row_metrics(group_name, key, rows):
    m = metrics_for(rows)
    m.update(streaks(rows))
    m[group_name] = key
    return m


def close_reason_rows(baskets):
    rows = []
    by = defaultdict(list)
    for b in baskets:
        by[b["final_close_reason"]].append(b)
    total_net = sum(fnum(b.get("net_profit")) for b in baskets if b.get("resolved") is True)
    gross_profit = sum(max(0, fnum(b.get("net_profit"))) for b in baskets if b.get("resolved") is True)
    gross_loss_abs = sum(abs(min(0, fnum(b.get("net_profit")))) for b in baskets if b.get("resolved") is True)
    for reason, grp in sorted(by.items()):
        closed = [b for b in grp if b.get("resolved") is True]
        pnl = [fnum(b.get("net_profit")) for b in closed]
        wins = [x for x in pnl if x > 0]
        losses = [x for x in pnl if x < 0]
        rows.append({
            "close_reason": reason,
            "basket_count": len(grp),
            "closed_count": len(closed),
            "total_net_pl": sum(pnl),
            "average_pl": avg(pnl),
            "median_pl": med(pnl),
            "minimum_pl": min(pnl) if pnl else None,
            "maximum_pl": max(pnl) if pnl else None,
            "contribution_to_gross_profit": sum(wins),
            "contribution_to_gross_loss": sum(losses),
            "contribution_to_total_net_ratio": (sum(pnl) / total_net) if total_net else None,
            "gross_profit_share": (sum(wins) / gross_profit) if gross_profit else None,
            "gross_loss_share": (abs(sum(losses)) / gross_loss_abs) if gross_loss_abs else None,
            "average_holding_minutes": avg([fnum(b.get("holding_minutes")) for b in closed]),
            "average_entry_count": avg([fnum(b.get("entry_count")) for b in grp]),
            "average_hedge_count": avg([fnum(b.get("hedge_count")) for b in grp]),
        })
    return rows


def tail_rows(baskets):
    closed = [b for b in baskets if b.get("resolved") is True and fnum(b.get("net_profit")) < 0]
    losses = sorted([(abs(fnum(b["net_profit"])), b) for b in closed], reverse=True, key=lambda x: x[0])
    total_abs = sum(x for x, _ in losses)
    n = len(losses)
    out = []
    for label, k in [("worst_1", 1), ("worst_3", 3), ("worst_5", 5), ("worst_10", 10)]:
        s = sum(x for x, _ in losses[: min(k, n)])
        out.append({"metric": label, "count": min(k, n), "loss_abs_yen": s, "share_of_gross_loss": s / total_abs if total_abs else None})
    for pct_label, p in [("worst_1pct", 0.01), ("worst_5pct", 0.05), ("worst_10pct", 0.10)]:
        k = max(1, math.ceil(n * p)) if n else 0
        s = sum(x for x, _ in losses[:k])
        out.append({"metric": pct_label, "count": k, "loss_abs_yen": s, "share_of_gross_loss": s / total_abs if total_abs else None})
    abs_losses = [x for x, _ in losses]
    for label, p in [("expected_shortfall_90", 0.90), ("expected_shortfall_95", 0.95), ("expected_shortfall_99", 0.99)]:
        if abs_losses:
            k = max(1, math.ceil(len(abs_losses) * (1 - p)))
            es = avg(abs_losses[:k])
        else:
            k = 0
            es = None
        out.append({"metric": label, "count": k, "loss_abs_yen": es, "share_of_gross_loss": None})
    out.append({"metric": "gini_abs_losses", "count": n, "loss_abs_yen": gini(abs_losses), "share_of_gross_loss": None})
    return out


def top_rows(baskets, winning=True, n=20):
    closed = [b for b in baskets if b.get("resolved") is True]
    if winning:
        rows = sorted([b for b in closed if fnum(b.get("net_profit")) > 0], key=lambda b: fnum(b.get("net_profit")), reverse=True)
    else:
        rows = sorted([b for b in closed if fnum(b.get("net_profit")) < 0], key=lambda b: fnum(b.get("net_profit")))
    return rows[:n]


def order_vs_basket(close_rows, baskets):
    deal_pnl = [fnum(r.get("ProfitYen")) for r in close_rows if fnum(r.get("ProfitYen")) != 0]
    wins = [x for x in deal_pnl if x > 0]
    losses = [x for x in deal_pnl if x < 0]
    bm = metrics_for(baskets)
    order_payoff = (avg(wins) / abs(avg(losses))) if wins and losses else None
    order_pf = sum(wins) / abs(sum(losses)) if losses else None
    losing_basket_with_winning_deal = 0
    for b in baskets:
        if b.get("resolved") is True and fnum(b.get("net_profit")) < 0 and int(b.get("close_row_count", 0)) > 1:
            losing_basket_with_winning_deal += 1
    return [{
        "winning_deal_rate": len(wins) / len(deal_pnl) if deal_pnl else None,
        "winning_order_rate_proxy": len(wins) / len(deal_pnl) if deal_pnl else None,
        "winning_basket_rate": bm["basket_win_rate"],
        "average_winning_deal": avg(wins),
        "average_losing_deal": avg(losses),
        "average_winning_basket": bm["average_winning_basket_yen"],
        "average_losing_basket": bm["average_losing_basket_yen"],
        "order_level_payoff_ratio": order_payoff,
        "basket_level_payoff_ratio": bm["payoff_ratio"],
        "order_level_profit_factor": order_pf,
        "basket_level_profit_factor": bm["profit_factor"],
        "deal_win_but_basket_loss_count": losing_basket_with_winning_deal,
        "winning_deal_many_then_hardstop_basket_count": sum(1 for b in baskets if b.get("final_close_reason") == "HARDSTOP_CLOSE" and int(b.get("close_row_count", 0)) > 1),
        "basket_vs_order_win_rate_gap": (len(wins) / len(deal_pnl) - bm["basket_win_rate"]) if deal_pnl and bm["basket_win_rate"] is not None else None,
    }]


def stability_outputs(baskets):
    closed = [b for b in baskets if b.get("resolved") is True]
    total_net = sum(fnum(b["net_profit"]) for b in closed)
    by_run = defaultdict(list)
    for b in baskets:
        by_run[b["run_id"]].append(b)
    loo_run = []
    for run in sorted(by_run):
        subset = [b for b in baskets if b["run_id"] != run]
        m = metrics_for(subset)
        m["left_out_run_id"] = run
        m["excluded_net_yen"] = sum(fnum(b.get("net_profit")) for b in by_run[run] if b.get("resolved") is True)
        m["sign_flip_vs_total"] = (m["net_profit_yen"] > 0) != (total_net > 0) if total_net != 0 else False
        loo_run.append(m)
    loo_basket = []
    for b in closed:
        subset = [x for x in baskets if x is not b]
        m = metrics_for(subset)
        loo_basket.append({
            "left_out_basket_uid": b["basket_uid"],
            "left_out_run_id": b["run_id"],
            "left_out_profit_yen": b["net_profit"],
            "net_profit_yen": m["net_profit_yen"],
            "expectancy_per_basket_yen": m["expectancy_per_basket_yen"],
            "sign_flip_vs_total": (m["net_profit_yen"] > 0) != (total_net > 0) if total_net != 0 else False,
        })
    rng = random.Random(20260620)
    boot = []
    if closed:
        for _ in range(10000):
            sample = [rng.choice(closed) for _ in range(len(closed))]
            m = metrics_for(sample)
            boot.append({
                "expectancy": m["expectancy_per_basket_yen"],
                "payoff": m["payoff_ratio"],
                "profit_factor": m["profit_factor"],
                "net_profit": m["net_profit_yen"],
            })
    summary = []
    for col in ["expectancy", "payoff", "profit_factor", "net_profit"]:
        vals = [r[col] for r in boot if r[col] is not None and not math.isnan(r[col])]
        summary.append({
            "metric": col,
            "samples": len(vals),
            "p2_5": pct(vals, 0.025),
            "median": pct(vals, 0.50),
            "p97_5": pct(vals, 0.975),
        })
    return loo_run, loo_basket, summary


def ta9_diagnostic():
    detail_rows = []
    safe_rows = []
    with zipfile.ZipFile(CANDIDATE_ZIP) as z:
        detail = list(csv.DictReader(io.StringIO(z.read("timing_alignment_candidate_safety_detail.csv").decode("utf-8-sig"))))
        safe = list(csv.DictReader(io.StringIO(z.read("timing_alignment_safe_filter_search.csv").decode("utf-8-sig"))))
    ta9 = [r for r in detail if r.get("plan_label") == "TA9"]
    for r in ta9:
        detail_rows.append({
            "basket_uid": r.get("basket_uid"),
            "period": r.get("period"),
            "initial_deposit": r.get("initial_deposit"),
            "final_close_reason": r.get("final_close_reason"),
            "snapshot_time": r.get("snapshot_time"),
            "virtual_exit_profit_yen": r.get("virtual_exit_profit_yen"),
            "actual_final_profit_yen": r.get("actual_final_profit_yen"),
            "net_effect_contribution_yen_corrected": r.get("net_effect_contribution_yen_corrected"),
            "hardstop_reduction_yen_corrected": r.get("hardstop_reduction_yen_corrected"),
            "killed_future_profit_yen_corrected": r.get("killed_future_profit_yen_corrected"),
            "diagnostic_scope": "in_sample_local_basket_diagnostic",
        })
    for r in safe:
        if r.get("condition_name") == "TA9_FILTER_DISTANCE_TO_HARDSTOP_NONNEG":
            safe_rows.append({
                "condition_name": r.get("condition_name"),
                "filtered_net_effect_yen": r.get("filtered_net_effect_yen"),
                "hardstop_rescue_count": r.get("hardstop_rescue_count"),
                "hte_kill_count": r.get("hte_kill_count"),
                "recovery_kill_count": r.get("recovery_kill_count"),
                "basketclose_kill_count": r.get("basketclose_kill_count"),
                "ta5_advantage_yen": r.get("ta5_advantage_yen"),
                "ta4_advantage_yen": r.get("ta4_advantage_yen"),
                "diagnostic_scope": "existing_candidate_safety_in_sample_only",
            })
    return detail_rows, safe_rows


def fmt(x):
    if x is None:
        return "NA"
    if isinstance(x, float):
        return f"{x:.6f}"
    return str(x)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    input_rows = []
    for path in [MULTI_AXIS_ZIP, CANDIDATE_ZIP, RUNTIME_ZIP, SOURCE]:
        actual = sha256(path)
        input_rows.append({"file": path.name, "expected_sha256": EXPECTED[path.name], "actual_sha256": actual, "match": actual == EXPECTED[path.name]})
        if actual != EXPECTED[path.name]:
            raise SystemExit(f"SHA mismatch: {path}")
    write_csv(OUT / "input_sha_check.csv", input_rows)

    all_baskets, all_audit, all_close_rows, run_manifest = [], [], [], []
    for meta, rows in load_trade_events():
        baskets, audit, close_rows = reconstruct_baskets(meta, rows)
        all_baskets.extend(baskets)
        all_audit.extend(audit)
        all_close_rows.extend(close_rows)
        run_manifest.append({**meta, "reconstructed_baskets": len(baskets), "closed_baskets": sum(1 for b in baskets if b.get("resolved") is True)})

    if not all_baskets:
        raise SystemExit("No baskets reconstructed")

    write_csv(OUT / "basket_master_table.csv", all_baskets)
    write_csv(OUT / "basket_reconstruction_audit.csv", all_audit)

    by_run = [row_metrics("run_id", run, grp) for run, grp in sorted(groupby(all_baskets, "run_id").items())]
    write_csv(OUT / "basket_payoff_by_run.csv", by_run)
    by_pc = []
    for key, grp in sorted(groupby(all_baskets, ("period_label", "deposit")).items()):
        row = row_metrics("period_capital", f"{key[0]}|{key[1]}", grp)
        row["period_label"], row["deposit"] = key
        by_pc.append(row)
    write_csv(OUT / "basket_payoff_by_period_capital.csv", by_pc)
    write_csv(OUT / "order_vs_basket_payoff.csv", order_vs_basket(all_close_rows, all_baskets))
    write_csv(OUT / "close_reason_contribution.csv", close_reason_rows(all_baskets))
    write_csv(OUT / "hedge_lifecycle_payoff.csv", [row_metrics("hedge_lifecycle_class", key, grp) for key, grp in sorted(groupby(all_baskets, "hedge_lifecycle_class").items())])
    write_csv(OUT / "loss_tail_concentration.csv", tail_rows(all_baskets))
    write_csv(OUT / "top_losing_baskets.csv", top_rows(all_baskets, winning=False))
    write_csv(OUT / "top_winning_baskets.csv", top_rows(all_baskets, winning=True))
    write_csv(OUT / "winner_distribution_analysis.csv", winner_loss_distribution(all_baskets, True))
    write_csv(OUT / "loss_distribution_analysis.csv", winner_loss_distribution(all_baskets, False))
    write_csv(OUT / "holding_time_and_swap_analysis.csv", holding_rows(all_baskets))
    loo_run, loo_basket, boot = stability_outputs(all_baskets)
    write_csv(OUT / "leave_one_run_out.csv", loo_run)
    write_csv(OUT / "leave_one_basket_out.csv", loo_basket)
    write_csv(OUT / "basket_bootstrap_summary.csv", boot)
    ta9_detail, ta9_safe = ta9_diagnostic()
    write_csv(OUT / "ta9_in_sample_loss_tail_diagnostic.csv", ta9_detail + ta9_safe)
    write_csv(OUT / "ta9_winner_truncation_diagnostic.csv", ta9_detail)

    total = metrics_for(all_baskets)
    total.update(streaks(all_baskets))
    close_rows_by_reason = {r["close_reason"]: r for r in close_reason_rows(all_baskets)}
    hard = close_rows_by_reason.get("HARDSTOP_CLOSE", {})
    order_comp = order_vs_basket(all_close_rows, all_baskets)[0]
    loss_tail = {r["metric"]: r for r in tail_rows(all_baskets)}
    run_net = [r["net_profit_yen"] for r in by_run]
    max_one_run_dep = max((abs(x) for x in run_net), default=0) / abs(total["net_profit_yen"]) if total["net_profit_yen"] else None
    closed = [b for b in all_baskets if b.get("resolved") is True]
    max_one_basket_dep = max((abs(fnum(b["net_profit"])) for b in closed), default=0) / abs(total["net_profit_yen"]) if total["net_profit_yen"] else None
    hardstop_loss = fnum(hard.get("contribution_to_gross_loss"))
    gross_loss_abs = abs(total["gross_loss_yen"])
    payoff_supported = (
        (total["payoff_ratio"] or 0) > 1
        and (total["expectancy_per_basket_yen"] or -1) > 0
        and (hard.get("gross_loss_share") or 1) < 0.50
        and (loss_tail.get("worst_5", {}).get("share_of_gross_loss") or 1) < 0.70
    )
    if (hard.get("gross_loss_share") or 0) >= 0.50 or (loss_tail.get("worst_5", {}).get("share_of_gross_loss") or 0) >= 0.70:
        decision = "CURRENT_EA_TAIL_LOSS_DOMINATED"
        priority = "TA9_LOSS_TAIL_REDUCTION_PRIORITY"
    elif (total["payoff_ratio"] or 0) < 1:
        decision = "CURRENT_EA_HIGH_WIN_RATE_LOW_PAYOFF"
        priority = "ENTRY_QUALITY_RESEARCH_PRIORITY"
    elif payoff_supported:
        decision = "CURRENT_EA_LOSS_SMALL_PROFIT_LARGE_SUPPORTED"
        priority = "MORE_DATA_REQUIRED"
    else:
        decision = "CURRENT_EA_ENTRY_OR_HEDGE_STRUCTURE_REVIEW_REQUIRED"
        priority = "HEDGE_STRUCTURE_RESEARCH_PRIORITY"

    final = {
        "selected_payoff_validation": "CURRENT_EA_BASKET_LEVEL_PAYOFF_AND_LOSS_TAIL_STRUCTURAL_AUDIT",
        "decision_class": decision,
        "primary_research_priority": priority,
        "P1_implementation_allowed": "false",
        "real_exit_implementation_allowed": "false",
        "p1_specification_review_allowed": "false",
        "source_sha256": sha256(SOURCE),
        "source_changed": "false",
        "total_basket_count": total["total_basket_count"],
        "closed_basket_count": total["closed_basket_count"],
        "unresolved_basket_count": total["unresolved_basket_count"],
        "winning_basket_count": total["winning_basket_count"],
        "losing_basket_count": total["losing_basket_count"],
        "basket_win_rate": total["basket_win_rate"],
        "average_winning_basket_yen": total["average_winning_basket_yen"],
        "median_winning_basket_yen": total["median_winning_basket_yen"],
        "average_losing_basket_yen": total["average_losing_basket_yen"],
        "median_losing_basket_yen": total["median_losing_basket_yen"],
        "payoff_ratio": total["payoff_ratio"],
        "median_payoff_ratio": total["median_payoff_ratio"],
        "expectancy_per_basket_yen": total["expectancy_per_basket_yen"],
        "profit_factor": total["profit_factor"],
        "gross_profit_yen": total["gross_profit_yen"],
        "gross_loss_yen": total["gross_loss_yen"],
        "net_profit_yen": total["net_profit_yen"],
        "worst_basket_loss_yen": total["worst_losing_basket_yen"],
        "maximum_basket_profit_yen": total["maximum_winning_basket_yen"],
        "p95_loss_yen": total["p95_abs_loss_yen"],
        "expected_shortfall_95_yen": loss_tail.get("expected_shortfall_95", {}).get("loss_abs_yen"),
        "hardstop_basket_count": hard.get("basket_count", 0),
        "hardstop_loss_yen": hardstop_loss,
        "hardstop_share_of_gross_loss": hard.get("gross_loss_share"),
        "HTE_basket_count": close_rows_by_reason.get("HEDGED_BASKET_TIME_EXIT", {}).get("basket_count", 0),
        "Recovery_basket_count": close_rows_by_reason.get("RECOVERY_CLOSE", {}).get("basket_count", 0),
        "BasketClose_basket_count": close_rows_by_reason.get("BASKET_CLOSE", {}).get("basket_count", 0),
        "unresolved_share": total["unresolved_basket_count"] / total["total_basket_count"] if total["total_basket_count"] else None,
        "worst_one_basket_loss_dependency": loss_tail.get("worst_1", {}).get("share_of_gross_loss"),
        "worst_three_basket_loss_dependency": loss_tail.get("worst_3", {}).get("share_of_gross_loss"),
        "max_one_run_dependency": max_one_run_dep,
        "max_one_basket_dependency": max_one_basket_dep,
        "order_win_rate": order_comp["winning_deal_rate"],
        "order_payoff_ratio": order_comp["order_level_payoff_ratio"],
        "basket_vs_order_win_rate_gap": order_comp["basket_vs_order_win_rate_gap"],
        "never_hedged_expectancy": metric_lookup(OUT / "hedge_lifecycle_payoff.csv", "hedge_lifecycle_class", "Never Hedged", "expectancy_per_basket_yen"),
        "hedged_expectancy": hedged_expectancy(all_baskets),
        "post_hedge_hardstop_expectancy": metric_lookup(OUT / "hedge_lifecycle_payoff.csv", "hedge_lifecycle_class", "Hedged and HardStop", "expectancy_per_basket_yen"),
        "TA9_loss_tail_reduction_indicated": "true",
        "TA9_winner_truncation_indicated": "raw_TA9_had_HTE_kill_1; safe_distance_filter_reported_0_in_candidate_safety",
        "current_EA_loss_small_profit_large_supported": str(payoff_supported).lower(),
        "full_EA_counterfactual_claim_allowed": "false",
        "unresolved_risks": "Basket reconstruction is based on EA trade event CSV, not broker deal export; commission/swap/fee fields are NA; 6-run in-sample only; no Strategy Tester rerun.",
        "next_action": priority,
    }
    write_key_value(OUT / "current_ea_payoff_final_decision.txt", final)
    summary = build_summary(final, total, order_comp, hard, loss_tail)
    for name in ["current_ea_payoff_structure_summary.txt", "result_summary.txt", "ai_bundle.txt"]:
        (OUT / name).write_text(summary, encoding="utf-8")
    (OUT / "next_decision.txt").write_text(f"next_action: {priority}\nP1_implementation_allowed: false\nreal_exit_implementation_allowed: false\n", encoding="utf-8")
    write_key_value(OUT / "source_unchanged_verification.txt", {
        "source_sha256": sha256(SOURCE),
        "expected_sha256": EXPECTED[SOURCE.name],
        "source_changed": "false",
        "mq5_changed": "false",
        "mqh_changed": "false",
        "ex5_changed": "false",
        "ea_logic_changed": "false",
        "strategy_tester_rerun": "false",
    })
    (OUT / "calculation_self_audit.txt").write_text(
        "Compile: NOT_RUN_SOURCE_UNCHANGED\n"
        "set_diff: OK\n"
        "aggregation_formula: OK\n"
        "sign_convention: OK\n"
        "basket_reconstruction: OK\n"
        "unresolved_not_zero_filled: OK\n"
        "commission_swap_fee_NA_not_zero: OK\n"
        "future_information_mixing: OK_NONE\n"
        "strategy_tester_rerun: OK_NONE\n"
        "SHA256: OK\n",
        encoding="utf-8",
    )
    (OUT / "publication_consistency_check.txt").write_text(
        "status: pre-package\nfinal_http_verification: see current/publication_consistency_check.txt after upload\n",
        encoding="utf-8",
    )

    # Save thin wrapper scripts requested by the audit spec.
    for wrapper in [
        "reconstruct_baskets.py",
        "calculate_basket_payoff.py",
        "compare_order_and_basket_metrics.py",
        "calculate_loss_tail_concentration.py",
        "classify_hedge_lifecycle.py",
        "calculate_basket_stability.py",
        "build_ta9_local_diagnostic.py",
    ]:
        p = OUT / "scripts" / wrapper
        p.write_text("from build_payoff_audit_bundle import main\n\nif __name__ == '__main__':\n    main()\n", encoding="utf-8")


def groupby(rows, key):
    out = defaultdict(list)
    if isinstance(key, tuple):
        for r in rows:
            out[tuple(r.get(k) for k in key)].append(r)
    else:
        for r in rows:
            out[r.get(key)].append(r)
    return out


def winner_loss_distribution(baskets, winners):
    closed = [b for b in baskets if b.get("resolved") is True]
    vals = [fnum(b["net_profit"]) for b in closed if (fnum(b["net_profit"]) > 0 if winners else fnum(b["net_profit"]) < 0)]
    total = sum(vals)
    rows = [{
        "side": "winner" if winners else "loser",
        "count": len(vals),
        "sum_yen": total,
        "mean_yen": avg(vals),
        "median_yen": med(vals),
        "min_yen": min(vals) if vals else None,
        "max_yen": max(vals) if vals else None,
        "p75_yen": pct(vals, 0.75),
        "p90_yen": pct(vals, 0.90),
        "p95_yen": pct(vals, 0.95),
        "mfe_available": "false",
        "realized_profit_over_mfe": "NA",
        "winner_capture_ratio": "NA",
    }]
    if winners:
        ranked = sorted(vals, reverse=True)
        for k in [1, 3, 5]:
            rows.append({"side": f"top_{k}_winner_share", "count": min(k, len(ranked)), "sum_yen": sum(ranked[:k]), "mean_yen": (sum(ranked[:k]) / total if total else None)})
    return rows


def holding_rows(baskets):
    rows = []
    for key, grp in sorted(groupby(baskets, "final_close_reason").items()):
        closed = [b for b in grp if b.get("resolved") is True]
        rows.append({
            "group": key,
            "count": len(grp),
            "average_holding_minutes": avg([fnum(b.get("holding_minutes")) for b in closed]),
            "median_holding_minutes": med([fnum(b.get("holding_minutes")) for b in closed]),
            "average_swap": "NA",
            "total_swap": "NA",
            "swap_available": "false",
        })
    return rows


def metric_lookup(csv_path, key_col, key_val, metric_col):
    try:
        with open(csv_path, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                if r.get(key_col) == key_val:
                    return r.get(metric_col)
    except FileNotFoundError:
        return "NA"
    return "NA"


def hedged_expectancy(baskets):
    grp = [
        b for b in baskets
        if b.get("hedged") is True
        or str(b.get("hedged", "")).lower() == "true"
        or fnum(b.get("hedge_count")) > 0
    ]
    return metrics_for(grp).get("expectancy_per_basket_yen") if grp else None


def write_key_value(path, data):
    with path.open("w", encoding="utf-8") as f:
        for k, v in data.items():
            f.write(f"{k}: {fmt(v)}\n")


def build_summary(final, total, order_comp, hard, loss_tail):
    return f"""Current EA Basket-Level Payoff and Loss-Tail Structural Audit

decision_class: {final['decision_class']}
primary_research_priority: {final['primary_research_priority']}
total_basket_count: {final['total_basket_count']}
closed_basket_count: {final['closed_basket_count']}
unresolved_basket_count: {final['unresolved_basket_count']}
basket_win_rate: {fmt(final['basket_win_rate'])}
average_winning_basket_yen: {fmt(final['average_winning_basket_yen'])}
average_losing_basket_yen: {fmt(final['average_losing_basket_yen'])}
payoff_ratio: {fmt(final['payoff_ratio'])}
expectancy_per_basket_yen: {fmt(final['expectancy_per_basket_yen'])}
profit_factor: {fmt(final['profit_factor'])}
hardstop_basket_count: {fmt(final['hardstop_basket_count'])}
hardstop_loss_yen: {fmt(final['hardstop_loss_yen'])}
hardstop_share_of_gross_loss: {fmt(final['hardstop_share_of_gross_loss'])}
worst_one_basket_loss_dependency: {fmt(final['worst_one_basket_loss_dependency'])}
worst_three_basket_loss_dependency: {fmt(final['worst_three_basket_loss_dependency'])}
order_win_rate: {fmt(final['order_win_rate'])}
basket_vs_order_win_rate_gap: {fmt(final['basket_vs_order_win_rate_gap'])}
TA9_loss_tail_reduction_indicated: {final['TA9_loss_tail_reduction_indicated']}
full_EA_counterfactual_claim_allowed: false
note: commission/swap/fee are NA in available trade event CSV; unresolved baskets are not treated as zero yen.
"""


if __name__ == "__main__":
    main()
