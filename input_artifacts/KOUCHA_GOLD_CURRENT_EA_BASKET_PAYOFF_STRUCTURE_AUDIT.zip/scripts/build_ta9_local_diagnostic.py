from build_payoff_audit_bundle import main

if __name__ == '__main__':
    main()
