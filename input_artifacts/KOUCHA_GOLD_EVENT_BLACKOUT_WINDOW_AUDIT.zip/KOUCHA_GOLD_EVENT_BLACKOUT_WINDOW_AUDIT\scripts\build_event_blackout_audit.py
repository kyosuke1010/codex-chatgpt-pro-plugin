from __future__ import annotations

import csv
import hashlib
import math
import os
import shutil
import urllib.request
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path.cwd()
OUT = ROOT / "KOUCHA_GOLD_EVENT_BLACKOUT_WINDOW_AUDIT"
SCRIPTS = OUT / "scripts"
INPUTS = OUT / "input_audits"
SOURCES = OUT / "input_audits" / "external_calendar_sources"

SOURCE_FILE = ROOT / "KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5"
SOURCE_EXPECTED_SHA = "1353718F46D727DB775827AAF30F86EC790056CB59CE46EB00D5BAD563EF1DE3"
LOCAL_NEWS = ROOT / "news_blackout.csv"

INPUT_ZIPS = [
    (
        "Basket Payoff Structure Audit",
        ROOT / "KOUCHA_GOLD_CURRENT_EA_BASKET_PAYOFF_STRUCTURE_AUDIT.zip",
        "304CAB4BF516D465F8B88096EFAE805CE00D6B3C2B3399851BB15164052C1E8D",
        ["basket_master_table.csv", "current_ea_payoff_final_decision.txt", "current_ea_payoff_structure_summary.txt", "ai_bundle.txt"],
    ),
    (
        "HardStop Root-Cause Multi-Logic Audit",
        ROOT / "KOUCHA_GOLD_HARDSTOP_ROOT_CAUSE_MULTI_LOGIC_AUDIT.zip",
        "B94891227A08697D050EC9E8F67372DDECE1321E3EA6AB3F709B854F69BD0EBA",
        ["hardstop_path_master.csv", "event_risk_hardstop_evidence.csv", "root_cause_multi_logic_final_decision.txt", "root_cause_multi_logic_summary.txt", "ai_bundle.txt"],
    ),
    (
        "Multilayer Shadow Logging Design Audit",
        ROOT / "KOUCHA_GOLD_MULTILAYER_SHADOW_LOGGING_DESIGN_AUDIT.zip",
        "F7F228AD87F7232E4121FE7C908143ED5B90B2C34EF3C00CEB263ECF5455E419",
        [
            "KOUCHA_GOLD_MULTILAYER_SHADOW_LOGGING_DESIGN_AUDIT\\multilayer_shadow_final_decision.txt",
            "KOUCHA_GOLD_MULTILAYER_SHADOW_LOGGING_DESIGN_AUDIT\\event_risk_shadow_schema.csv",
            "KOUCHA_GOLD_MULTILAYER_SHADOW_LOGGING_DESIGN_AUDIT\\ai_bundle.txt",
        ],
    ),
]

NYFED_MARCH_URL = "https://www.newyorkfed.org/research/calendars/i-mar26.html"
NYFED_APRIL_URL = "https://www.newyorkfed.org/research/calendars/i-apr26.html"
NYFED_MAY_URL = "https://www.newyorkfed.org/research/calendars/i-may26.html"
FED_FOMC_MARCH_URL = "https://www.federalreserve.gov/monetarypolicy/fomcpresconf20260318.htm"

ET = ZoneInfo("America/New_York")
SERVER_TZ_MODEL = ZoneInfo("Europe/Athens")
JST = ZoneInfo("Asia/Tokyo")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def write_csv(name: str, rows: list[dict[str, object]], fieldnames: list[str] | None = None) -> None:
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = []
        for row in rows:
            for key in row:
                if key not in fieldnames:
                    fieldnames.append(key)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_text(name: str, text: str) -> None:
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.strip() + "\n", encoding="utf-8")


def read_zip_csv(zip_path: Path, member: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path, "r") as z:
        data = z.read(member).decode("utf-8-sig")
    return list(csv.DictReader(data.splitlines()))


def copy_zip_member(zip_path: Path, member: str, out_name: str) -> bool:
    with zipfile.ZipFile(zip_path, "r") as z:
        names = set(z.namelist())
        if member not in names:
            return False
        target = INPUTS / out_name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(z.read(member))
        return True


def parse_server_dt(value: str | None) -> datetime | None:
    if value is None:
        return None
    v = value.strip()
    if not v or v in {"NA", "NOT_AVAILABLE", "UNKNOWN"}:
        return None
    for fmt in ("%Y.%m.%d %H:%M:%S", "%Y.%m.%d_%H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(v, fmt)
        except ValueError:
            pass
    return None


def parse_weird_local(value: str, tz: ZoneInfo) -> datetime:
    date_s, time_s = value.split("_")
    y, m, d = map(int, date_s.split("."))
    hh, mm = map(int, time_s.split(":"))
    base = datetime(y, m, d, 0, 0, tzinfo=tz)
    return base + timedelta(hours=hh, minutes=mm)


def event_from_et(event_id: str, date_s: str, time_s: str, name: str, source: str, source_file: str, source_sha: str, notes: str) -> dict[str, object]:
    local = datetime.strptime(date_s + " " + time_s, "%Y-%m-%d %H:%M").replace(tzinfo=ET)
    utc = local.astimezone(timezone.utc)
    server = utc.astimezone(SERVER_TZ_MODEL).replace(tzinfo=None)
    return {
        "event_id": event_id,
        "event_time": local.strftime("%Y-%m-%d %H:%M:%S"),
        "event_timezone": "America/New_York",
        "event_time_utc": utc.strftime("%Y-%m-%d %H:%M:%S"),
        "event_time_server": server.strftime("%Y.%m.%d %H:%M:%S"),
        "server_timezone_basis": "Europe/Athens/EET-EEST inferred from XM server and Apr-May file",
        "currency": "USD",
        "impact": "HIGH" if not name.startswith("FOMC") else "FOMC",
        "event_name": name,
        "actual": "NA",
        "forecast": "NA",
        "previous": "NA",
        "source": source,
        "source_file": source_file,
        "source_sha256": source_sha,
        "imported_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "time_verified": "ET_TO_UTC_VERIFIED; SERVER_LABEL_INFERRED",
        "notes": notes,
    }


def download_sources() -> dict[str, dict[str, str]]:
    SOURCES.mkdir(parents=True, exist_ok=True)
    urls = {
        "newyorkfed_i_mar26.html": NYFED_MARCH_URL,
        "newyorkfed_i_apr26.html": NYFED_APRIL_URL,
        "newyorkfed_i_may26.html": NYFED_MAY_URL,
        "federalreserve_fomc_20260318.html": FED_FOMC_MARCH_URL,
    }
    result = {}
    for filename, url in urls.items():
        path = SOURCES / filename
        try:
            with urllib.request.urlopen(url, timeout=30) as resp:
                data = resp.read()
            path.write_bytes(data)
            status = "DOWNLOADED"
        except Exception as exc:  # Keep audit reproducible even if source fetch fails later.
            path.write_text(f"DOWNLOAD_FAILED\nurl={url}\nerror={exc}\n", encoding="utf-8")
            status = f"DOWNLOAD_FAILED:{type(exc).__name__}"
        result[filename] = {"url": url, "path": str(path.relative_to(OUT)), "sha": sha256_file(path), "status": status}
    return result


def build_calendar(source_meta: dict[str, dict[str, str]]) -> list[dict[str, object]]:
    local_sha = sha256_file(LOCAL_NEWS)
    rows: list[dict[str, object]] = []
    with LOCAL_NEWS.open("r", encoding="utf-8-sig", newline="") as f:
        for i, row in enumerate(csv.DictReader(f), start=1):
            jst_dt = parse_weird_local(row["EventTimeJST"], JST)
            utc = jst_dt.astimezone(timezone.utc)
            server_dt = parse_server_dt(row["EventTimeServer"])
            expected_server = utc.astimezone(SERVER_TZ_MODEL).replace(tzinfo=None)
            consistent = server_dt == expected_server
            rows.append({
                "event_id": f"EA_NEWS_{i:03d}",
                "event_time": jst_dt.strftime("%Y-%m-%d %H:%M:%S"),
                "event_timezone": "Asia/Tokyo",
                "event_time_utc": utc.strftime("%Y-%m-%d %H:%M:%S"),
                "event_time_server": server_dt.strftime("%Y.%m.%d %H:%M:%S") if server_dt else "NA",
                "server_timezone_basis": "existing EventTimeServer from news_blackout.csv",
                "currency": row["Country"],
                "impact": row["Impact"],
                "event_name": row["EventName"],
                "actual": "NA",
                "forecast": "NA",
                "previous": "NA",
                "source": "LOCAL_EA_NEWS_BLACKOUT_CSV",
                "source_file": "news_blackout.csv",
                "source_sha256": local_sha,
                "imported_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "time_verified": "JST_TO_UTC_AND_SERVER_LABEL_MATCH" if consistent else "JST_TO_UTC_OK_SERVER_LABEL_MISMATCH",
                "notes": f"Existing EA blackout file; original BlockBefore={row.get('BlockBeforeMinutes')} BlockAfter={row.get('BlockAfterMinutes')}; audit primary window remains +/-60m.",
            })
    mar_sha = source_meta["newyorkfed_i_mar26.html"]["sha"]
    fomc_sha = source_meta["federalreserve_fomc_20260318.html"]["sha"]
    march_events = [
        ("NYFED_MAR_001", "2026-03-02", "10:00", "ISM_Manufacturing"),
        ("NYFED_MAR_002", "2026-03-04", "08:15", "ADP_National_Employment_Report"),
        ("NYFED_MAR_003", "2026-03-04", "10:00", "ISM_Non_Manufacturing"),
        ("NYFED_MAR_004", "2026-03-05", "08:30", "Initial_Claims"),
        ("NYFED_MAR_005", "2026-03-06", "08:30", "Employment_Situation"),
        ("NYFED_MAR_006", "2026-03-11", "08:30", "Consumer_Price_Index"),
        ("NYFED_MAR_007", "2026-03-12", "08:30", "Initial_Claims"),
        ("NYFED_MAR_008", "2026-03-12", "08:30", "Producer_Price_Index"),
        ("NYFED_MAR_009", "2026-03-13", "08:30", "Gross_Domestic_Product_2nd_Release"),
        ("NYFED_MAR_010", "2026-03-13", "08:30", "Personal_Income_and_PCE_Deflator"),
        ("NYFED_MAR_011", "2026-03-13", "10:00", "JOLTS"),
        ("NYFED_MAR_012", "2026-03-16", "08:30", "Advance_Retail_Sales"),
        ("NYFED_MAR_013", "2026-03-19", "08:30", "Initial_Claims"),
        ("NYFED_MAR_014", "2026-03-26", "08:30", "Initial_Claims"),
        ("NYFED_MAR_015", "2026-03-31", "10:00", "JOLTS"),
    ]
    for event_id, date_s, time_s, name in march_events:
        rows.append(event_from_et(event_id, date_s, time_s, name, "NEW_YORK_FED_ECONOMIC_INDICATORS_CALENDAR", "input_audits/external_calendar_sources/newyorkfed_i_mar26.html", mar_sha, "Selected from fixed USD high-impact candidate list; New York Fed calendar states times are Eastern Time."))
    rows.append(event_from_et("FED_FOMC_MAR_001", "2026-03-18", "14:00", "FOMC_Statement_Federal_Funds_Rate", "FEDERAL_RESERVE_FOMC_MEETING_PAGE", "input_audits/external_calendar_sources/federalreserve_fomc_20260318.html", fomc_sha, "Federal Reserve meeting page states statement released at 2:00 p.m."))
    rows.append(event_from_et("FED_FOMC_MAR_002", "2026-03-18", "14:30", "FOMC_Press_Conference", "FEDERAL_RESERVE_FOMC_MEETING_PAGE", "input_audits/external_calendar_sources/federalreserve_fomc_20260318.html", fomc_sha, "Federal Reserve March calendar/search source states press conference at 2:30 p.m.; used as Fed Chair event proxy."))
    rows.sort(key=lambda r: r["event_time_utc"])
    return rows


def within(dt: datetime | None, event_dt: datetime, before: int, after: int) -> bool:
    if dt is None:
        return False
    return event_dt - timedelta(minutes=before) <= dt <= event_dt + timedelta(minutes=after)


def overlap_interval(start: datetime | None, end: datetime | None, event_dt: datetime, before: int, after: int) -> bool:
    if start is None or end is None:
        return False
    if end < start:
        return False
    return max(start, event_dt - timedelta(minutes=before)) <= min(end, event_dt + timedelta(minutes=after))


def nearest_events(dt: datetime | None, events: list[dict[str, object]]) -> tuple[dict[str, object] | None, float | None, dict[str, object] | None, float | None]:
    if dt is None:
        return None, None, None, None
    before = []
    after = []
    for e in events:
        edt = parse_server_dt(str(e["event_time_server"]))
        if edt is None:
            continue
        delta = (dt - edt).total_seconds() / 60.0
        if delta >= 0:
            before.append((delta, e))
        else:
            after.append((-delta, e))
    b = min(before, key=lambda x: x[0]) if before else (None, None)
    a = min(after, key=lambda x: x[0]) if after else (None, None)
    return b[1], b[0], a[1], a[0]


def event_hits(dt: datetime | None, events: list[dict[str, object]], before: int = 60, after: int = 60) -> list[dict[str, object]]:
    hits = []
    for e in events:
        edt = parse_server_dt(str(e["event_time_server"]))
        if edt and within(dt, edt, before, after):
            hits.append(e)
    return hits


def lifetime_hits(start: datetime | None, end: datetime | None, events: list[dict[str, object]], before: int = 60, after: int = 60) -> list[dict[str, object]]:
    hits = []
    for e in events:
        edt = parse_server_dt(str(e["event_time_server"]))
        if edt and overlap_interval(start, end, edt, before, after):
            hits.append(e)
    return hits


def yen(row: dict[str, str], key: str) -> float:
    v = row.get(key, "NA")
    if v in {"", "NA", "NOT_AVAILABLE", "UNKNOWN"}:
        return 0.0
    return float(v)


def maybe_float(value: object) -> float | None:
    if value is None:
        return None
    v = str(value).strip()
    if v in {"", "NA", "NOT_AVAILABLE", "UNKNOWN"}:
        return None
    return float(v)


def sum_available(rows: list[dict[str, object]], key: str = "net_profit") -> float:
    vals = [maybe_float(r.get(key)) for r in rows]
    return sum(v for v in vals if v is not None)


def numeric_rows(rows: list[dict[str, object]], key: str = "net_profit") -> list[dict[str, object]]:
    return [r for r in rows if maybe_float(r.get(key)) is not None]


def gross_loss(rows: list[dict[str, str]]) -> float:
    return sum(min(0.0, yen(r, "net_profit")) for r in rows)


def gross_profit(rows: list[dict[str, str]]) -> float:
    return sum(max(0.0, yen(r, "net_profit")) for r in rows)


def summarize_subset(rows: list[dict[str, object | str]], label: str) -> dict[str, object]:
    vals = [v for v in (maybe_float(r.get("net_profit", r.get("final P/L", "NA"))) for r in rows) if v is not None]
    wins = [v for v in vals if v > 0]
    losses = [v for v in vals if v < 0]
    return {
        "group": label,
        "basket_count": len(rows),
        "profit_available_count": len(vals),
        "profit_na_count": len(rows) - len(vals),
        "net_yen": round(sum(vals), 2),
        "gross_profit_yen": round(sum(wins), 2),
        "gross_loss_yen": round(sum(losses), 2),
        "winner_count": len(wins),
        "loser_count": len(losses),
        "win_rate": round(len(wins) / len(rows), 6) if rows else "NA",
        "average_win": round(sum(wins) / len(wins), 2) if wins else "NA",
        "average_loss": round(sum(losses) / len(losses), 2) if losses else "NA",
        "payoff_ratio": round((sum(wins) / len(wins)) / abs(sum(losses) / len(losses)), 6) if wins and losses else "NA",
    }


def build() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir()
    SCRIPTS.mkdir(parents=True)
    INPUTS.mkdir(parents=True)

    source_start = sha256_file(SOURCE_FILE)
    if source_start != SOURCE_EXPECTED_SHA:
        raise SystemExit("Source SHA mismatch")

    input_manifest = []
    for name, path, expected, members in INPUT_ZIPS:
        actual = sha256_file(path)
        input_manifest.append({"input_name": name, "zip_file": path.name, "expected_sha256": expected, "actual_sha256": actual, "sha_status": "MATCH" if actual == expected else "MISMATCH", "member": "ZIP"})
        for member in members:
            safe = name.lower().replace(" ", "_").replace("-", "_") + "__" + member.replace("\\", "__").replace("/", "__")
            found = copy_zip_member(path, member, safe)
            input_manifest.append({"input_name": name, "zip_file": path.name, "expected_sha256": expected, "actual_sha256": actual, "sha_status": "MATCH" if actual == expected else "MISMATCH", "member": f"{member}:{'FOUND' if found else 'NOT_AVAILABLE'}"})
    write_csv("input_audits/input_manifest.csv", input_manifest)

    source_meta = download_sources()
    calendar = build_calendar(source_meta)
    write_csv("economic_calendar_events.csv", calendar)

    calendar_sha = sha256_file(OUT / "economic_calendar_events.csv")
    manifest_rows = []
    manifest_rows.append({"source_name": "locked_economic_calendar", "source_file": "economic_calendar_events.csv", "source_url": "LOCAL_GENERATED_FROM_LOCKED_SOURCES", "sha256": calendar_sha, "status": "CREATED", "coverage_start": "2026-03-01", "coverage_end": "2026-05-29", "notes": "March from New York Fed/Federal Reserve sources; April-May from existing EA news_blackout.csv"})
    manifest_rows.append({"source_name": "local_ea_news_blackout", "source_file": "news_blackout.csv", "source_url": "local workspace", "sha256": sha256_file(LOCAL_NEWS), "status": "LOCKED", "coverage_start": "2026-04-01", "coverage_end": "2026-05-29", "notes": "Does not cover March 2026"})
    for fn, meta in source_meta.items():
        manifest_rows.append({"source_name": fn, "source_file": meta["path"], "source_url": meta["url"], "sha256": meta["sha"], "status": meta["status"], "coverage_start": "2026-03-01" if "mar" in fn or "fomc" in fn else "2026-04-01" if "apr" in fn else "2026-05-01", "coverage_end": "2026-03-31" if "mar" in fn or "fomc" in fn else "2026-04-30" if "apr" in fn else "2026-05-31", "notes": "External audit evidence source"})
    write_csv("locked_economic_calendar_manifest.csv", manifest_rows)

    window_defs = [
        {"window_id": "PRIMARY_PM60", "minutes_before": 60, "minutes_after": 60, "purpose": "Primary EA premise"},
        {"window_id": "SENS_PM30", "minutes_before": 30, "minutes_after": 30, "purpose": "Sensitivity only"},
        {"window_id": "SENS_PM120", "minutes_before": 120, "minutes_after": 120, "purpose": "Sensitivity only"},
        {"window_id": "SENS_BEFORE60", "minutes_before": 60, "minutes_after": 0, "purpose": "Sensitivity only"},
        {"window_id": "SENS_AFTER60", "minutes_before": 0, "minutes_after": 60, "purpose": "Sensitivity only"},
        {"window_id": "SENS_EVENT_DAY", "minutes_before": 24 * 60, "minutes_after": 24 * 60, "purpose": "Reference only; not primary"},
    ]
    write_csv("event_window_definitions.csv", window_defs)

    basket_rows = read_zip_csv(ROOT / "KOUCHA_GOLD_CURRENT_EA_BASKET_PAYOFF_STRUCTURE_AUDIT.zip", "basket_master_table.csv")
    hardstop_rows = read_zip_csv(ROOT / "KOUCHA_GOLD_HARDSTOP_ROOT_CAUSE_MULTI_LOGIC_AUDIT.zip", "hardstop_path_master.csv")
    hardstop_by_uid = {r["basket_uid"]: r for r in hardstop_rows}

    overlap_master = []
    news_compare = []
    for b in basket_rows:
        entry = parse_server_dt(b["basket_start_time"])
        close = parse_server_dt(b["basket_end_time"])
        hs = hardstop_by_uid.get(b["basket_uid"])
        hedge = parse_server_dt(hs.get("first_hedge_time") if hs else None)
        entry_hits = event_hits(entry, calendar)
        hedge_hits = event_hits(hedge, calendar) if hedge else []
        close_hits = event_hits(close, calendar)
        life_hits = lifetime_hits(entry, close, calendar)
        before_e, before_m, after_e, after_m = nearest_events(entry, calendar)
        nearest = entry_hits[0] if entry_hits else (after_e or before_e)
        ea_news_state = hs.get("news_condition", "EA_NEWS_LOG_NOT_AVAILABLE") if hs else "EA_NEWS_LOG_NOT_AVAILABLE"
        if life_hits and ea_news_state == "enabled_csv_clear":
            compare_class = "CALENDAR_EVENT_WINDOW_BUT_EA_NOT_BLOCKED"
        elif life_hits and ea_news_state not in {"EA_NEWS_LOG_NOT_AVAILABLE", "enabled_csv_clear"}:
            compare_class = "CALENDAR_EVENT_WINDOW_AND_EA_BLOCKED"
        elif not life_hits and ea_news_state not in {"EA_NEWS_LOG_NOT_AVAILABLE", "enabled_csv_clear"}:
            compare_class = "EA_BLOCKED_WITHOUT_CALENDAR_EVENT"
        elif ea_news_state == "EA_NEWS_LOG_NOT_AVAILABLE":
            compare_class = "EA_NEWS_LOG_NOT_AVAILABLE"
        else:
            compare_class = "NO_CALENDAR_EVENT_WINDOW"
        net_value = maybe_float(b.get("net_profit"))
        row = {
            "basket_uid": b["basket_uid"],
            "run_id": b["run_id"],
            "period": b["period_label"],
            "capital": b["deposit"],
            "basket_start_time": b["basket_start_time"],
            "first_entry_time": b["basket_start_time"],
            "hedge_start_time": hedge.strftime("%Y.%m.%d %H:%M:%S") if hedge else "NA" if b.get("hedge_count") == "0" else "NOT_AVAILABLE_FOR_NON_HARDSTOP",
            "final_close_time": b["basket_end_time"],
            "final_close_reason": b["final_close_reason"],
            "final_pl": b["net_profit"],
            "win_loss": "UNRESOLVED_OR_NA" if net_value is None else "WIN" if net_value > 0 else "LOSS" if net_value < 0 else "BREAKEVEN",
            "close_reason_group": "HARDSTOP" if b["final_close_reason"] == "HARDSTOP_CLOSE" else "HTE" if "time exit" in b["final_close_reason"].lower() else b["final_close_reason"],
            "event_overlap_at_first_entry": bool(entry_hits),
            "event_overlap_at_hedge_start": bool(hedge_hits) if hedge else "NA" if b.get("hedge_count") == "0" else "NOT_AVAILABLE",
            "event_overlap_at_final_close": bool(close_hits),
            "event_overlap_during_basket_lifetime": bool(life_hits),
            "entry_event_ids": ";".join(e["event_id"] for e in entry_hits) or "NA",
            "hedge_event_ids": ";".join(e["event_id"] for e in hedge_hits) or "NA",
            "close_event_ids": ";".join(e["event_id"] for e in close_hits) or "NA",
            "lifetime_event_ids": ";".join(e["event_id"] for e in life_hits) or "NA",
            "nearest_event_before_entry": before_e["event_name"] if before_e else "NA",
            "nearest_event_after_entry": after_e["event_name"] if after_e else "NA",
            "minutes_to_nearest_event": round(after_m, 3) if after_m is not None else "NA",
            "minutes_after_nearest_event": round(before_m, 3) if before_m is not None else "NA",
            "event_name": nearest["event_name"] if nearest else "NA",
            "event_impact": nearest["impact"] if nearest else "NA",
            "currency": nearest["currency"] if nearest else "NA",
            "source": nearest["source"] if nearest else "NA",
            "time_verification_status": nearest["time_verified"] if nearest else "NA",
            "EA_NewsBlock_state": ea_news_state,
            "calendar_vs_ea_newsblock_classification": compare_class,
            "net_profit": b["net_profit"],
        }
        overlap_master.append(row)
        news_compare.append({
            "basket_uid": b["basket_uid"],
            "run_id": b["run_id"],
            "final_close_reason": b["final_close_reason"],
            "calendar_lifetime_window": bool(life_hits),
            "ea_news_state": ea_news_state,
            "classification": compare_class,
            "event_ids": row["lifetime_event_ids"],
        })
    write_csv("basket_event_overlap_master.csv", overlap_master)
    write_csv("ea_newsblock_vs_calendar_compare.csv", news_compare)

    hardstop_overlap = []
    for hs in hardstop_rows:
        b = next((x for x in overlap_master if x["basket_uid"] == hs["basket_uid"]), None)
        entry = parse_server_dt(hs["first_entry_time"])
        hedge = parse_server_dt(hs["first_hedge_time"])
        close = parse_server_dt(hs["final_hardstop_time"])
        start = parse_server_dt(hs["basket_start_time"])
        entry_hits = event_hits(entry, calendar)
        hedge_hits = event_hits(hedge, calendar) if hedge else []
        close_hits = event_hits(close, calendar)
        life_hits = lifetime_hits(start, close, calendar)
        candidate = bool(entry_hits or hedge_hits or close_hits or life_hits)
        hardstop_overlap.append({
            "basket_uid": hs["basket_uid"],
            "run_id": hs["run_id"],
            "period": hs["period"],
            "capital": hs["capital"],
            "first_entry_time": hs["first_entry_time"],
            "first_hedge_time": hs["first_hedge_time"],
            "final_hardstop_time": hs["final_hardstop_time"],
            "final_pl": hs["final_pl"],
            "entry_pm60_overlap": bool(entry_hits),
            "hedge_pm60_overlap": bool(hedge_hits) if hedge else "NA",
            "hardstop_pm60_overlap": bool(close_hits),
            "lifetime_pm60_overlap": bool(life_hits),
            "entry_event_ids": ";".join(e["event_id"] for e in entry_hits) or "NA",
            "hedge_event_ids": ";".join(e["event_id"] for e in hedge_hits) or "NA",
            "hardstop_event_ids": ";".join(e["event_id"] for e in close_hits) or "NA",
            "lifetime_event_ids": ";".join(e["event_id"] for e in life_hits) or "NA",
            "news_condition": hs.get("news_condition", "NA"),
            "large_candle_condition": hs.get("large_candle_condition", "NA"),
            "dxy_condition": hs.get("dxy_condition", "NA"),
            "vix_condition": hs.get("vix_condition", "NA"),
            "event_risk_major_factor_candidate": "YES_TIMEZONE_PARTIAL" if candidate else "NO_OVERLAP",
            "notes": "Event overlap is structural evidence only; not causal proof.",
        })
    write_csv("hardstop_event_overlap.csv", hardstop_overlap)

    # Diagnostics and aggregations.
    by_key = []
    for keys, label in [
        (["run_id"], "run"),
        (["period", "capital"], "period_capital"),
        (["period"], "period"),
        (["capital"], "capital"),
    ]:
        groups: dict[tuple, list[dict[str, object]]] = defaultdict(list)
        for r in overlap_master:
            groups[tuple(r[k] for k in keys)].append(r)
        for key, rows in sorted(groups.items()):
            event_rows = [r for r in rows if r["event_overlap_during_basket_lifetime"] is True]
            entry_rows = [r for r in rows if r["event_overlap_at_first_entry"] is True]
            hard_rows = [r for r in rows if r["final_close_reason"] == "HARDSTOP_CLOSE"]
            hard_event = [r for r in hard_rows if r["event_overlap_during_basket_lifetime"] is True]
            by_key.append({
                "group_type": label,
                "group_key": "|".join(map(str, key)),
                "total_basket_count": len(rows),
                "event_window_entry_basket_count": len(entry_rows),
                "event_window_entry_net_pl": round(sum_available(entry_rows), 2),
                "event_window_lifetime_overlap_basket_count": len(event_rows),
                "event_window_lifetime_overlap_net_pl": round(sum_available(event_rows), 2),
                "event_window_hardstop_count": len(hard_event),
                "event_window_hardstop_loss": round(sum_available(hard_event), 2),
                "hardstop_total_count": len(hard_rows),
                "ea_newsblock_mismatch_count": sum(1 for r in rows if r["calendar_vs_ea_newsblock_classification"] == "CALENDAR_EVENT_WINDOW_BUT_EA_NOT_BLOCKED"),
            })
    write_csv("event_window_by_run_period_capital.csv", by_key)

    close_groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    for r in overlap_master:
        close_groups[str(r["final_close_reason"])].append(r)
    close_rows = []
    for reason, rows in sorted(close_groups.items()):
        event_rows = [r for r in rows if r["event_overlap_during_basket_lifetime"] is True]
        close_rows.append({
            "final_close_reason": reason,
            "basket_count": len(rows),
            "net_yen": round(sum_available(rows), 2),
            "event_window_overlap_count": len(event_rows),
            "event_window_net_yen": round(sum_available(event_rows), 2),
            "event_window_share": round(len(event_rows) / len(rows), 6) if rows else "NA",
        })
    write_csv("event_window_close_reason_contribution.csv", close_rows)

    event_rows = [r for r in overlap_master if r["event_overlap_during_basket_lifetime"] is True]
    non_event_rows = [r for r in overlap_master if r["event_overlap_during_basket_lifetime"] is not True]
    entry_event_rows = [r for r in overlap_master if r["event_overlap_at_first_entry"] is True]
    close_hard_event_rows = [r for r in overlap_master if r["final_close_reason"] == "HARDSTOP_CLOSE" and r["event_overlap_at_final_close"] is True]
    payoff_rows = [summarize_subset(event_rows, "event_window_lifetime_overlap"), summarize_subset(non_event_rows, "non_event_window_lifetime_overlap"), summarize_subset(entry_event_rows, "event_window_entry"), summarize_subset(close_hard_event_rows, "hardstop_close_inside_event_window")]
    write_csv("event_window_payoff_compare.csv", payoff_rows)

    exclusion_rows = []
    for label, rows in [
        ("exclude_first_entry_inside_pm60", entry_event_rows),
        ("exclude_lifetime_overlap_pm60", event_rows),
        ("exclude_hardstop_close_inside_pm60", close_hard_event_rows),
    ]:
        excluded = sum_available(rows)
        total = sum_available(overlap_master)
        exclusion_rows.append({
            "diagnostic": label,
            "excluded_basket_count": len(rows),
            "excluded_net_yen": round(excluded, 2),
            "structural_remaining_net_yen": round(total - excluded, 2),
            "full_EA_counterfactual_claim_allowed": "false",
            "notes": "Local structural exclusion only; downstream basket sequence is not recomputed.",
        })
    write_csv("event_window_local_exclusion_diagnostic.csv", exclusion_rows)

    data_quality = []
    by_month = Counter(str(e["event_time_utc"])[:7] for e in calendar)
    for m in ["2026-03", "2026-04", "2026-05"]:
        data_quality.append({"month": m, "event_count": by_month[m], "coverage_status": "HAS_EVENTS" if by_month[m] else "MISSING", "notes": "March source is external NY Fed/Fed with server offset inferred; Apr-May source is local EA news_blackout.csv"})
    write_csv("event_data_quality_audit.csv", data_quality)
    write_text("event_data_quality_audit.txt", f"""
Event Data Quality Audit

Locked calendar source:
- economic_calendar_events.csv
- event_count: {len(calendar)}

Coverage:
- 2026-03: {by_month['2026-03']} events. Source: New York Fed Economic Indicators Calendar plus Federal Reserve FOMC page. Eastern Time to UTC is verified by timezone database; MT5 server-label conversion is inferred from EET/EEST model.
- 2026-04: {by_month['2026-04']} events. Source: existing EA news_blackout.csv.
- 2026-05: {by_month['2026-05']} events. Source: existing EA news_blackout.csv.

Known limitations:
- Existing EA local news_blackout.csv does not cover March 2026.
- March external source selection is fixed before overlap calculation, but server-time alignment is partial because the exact historical XM server offset is not separately logged for March.
- actual / forecast / previous are not available in the locked local source and remain NA.
- Event overlap is not causal proof.
    """)

    # Sensitivity window summary.
    sens_rows = []
    for wd in window_defs:
        before, after = int(wd["minutes_before"]), int(wd["minutes_after"])
        if wd["window_id"] == "SENS_EVENT_DAY":
            # Event-day full blackout: date match in server label.
            event_dates = {str(e["event_time_server"])[:10] for e in calendar}
            rows = [r for r in overlap_master if str(r["first_entry_time"])[:10] in event_dates]
            hs_rows = [r for r in rows if r["final_close_reason"] == "HARDSTOP_CLOSE"]
        else:
            rows = []
            for b in basket_rows:
                entry = parse_server_dt(b["basket_start_time"])
                if event_hits(entry, calendar, before, after):
                    rows.append(next(r for r in overlap_master if r["basket_uid"] == b["basket_uid"]))
            hs_rows = [r for r in rows if r["final_close_reason"] == "HARDSTOP_CLOSE"]
        sens_rows.append({"window_id": wd["window_id"], "basket_entry_overlap_count": len(rows), "entry_overlap_net_yen": round(sum_available(rows), 2), "hardstop_entry_overlap_count": len(hs_rows), "hardstop_entry_overlap_loss_yen": round(sum_available(hs_rows), 2), "primary_window": wd["window_id"] == "PRIMARY_PM60"})
    write_csv("event_window_sensitivity_summary.csv", sens_rows)

    # Final counts.
    total_net = sum_available(overlap_master)
    event_net = sum_available(event_rows)
    non_event_net = sum_available(non_event_rows)
    event_gross_loss = sum(min(0.0, maybe_float(r.get("net_profit")) or 0.0) for r in event_rows if maybe_float(r.get("net_profit")) is not None)
    non_event_gross_loss = sum(min(0.0, maybe_float(r.get("net_profit")) or 0.0) for r in non_event_rows if maybe_float(r.get("net_profit")) is not None)
    hardstop_total = [r for r in overlap_master if r["final_close_reason"] == "HARDSTOP_CLOSE"]
    hardstop_entry = [r for r in hardstop_overlap if r["entry_pm60_overlap"] is True]
    hardstop_hedge = [r for r in hardstop_overlap if r["hedge_pm60_overlap"] is True]
    hardstop_close = [r for r in hardstop_overlap if r["hardstop_pm60_overlap"] is True]
    hardstop_life = [r for r in hardstop_overlap if r["lifetime_pm60_overlap"] is True]
    event_window_hardstop_loss = sum(maybe_float(r.get("final_pl")) or 0.0 for r in hardstop_life if maybe_float(r.get("final_pl")) is not None)
    non_event_hardstop_loss = sum_available([r for r in hardstop_total if r["basket_uid"] not in {h["basket_uid"] for h in hardstop_life}])
    mismatch_count = sum(1 for r in news_compare if r["classification"] == "CALENDAR_EVENT_WINDOW_BUT_EA_NOT_BLOCKED")

    if by_month["2026-03"] == 0 or by_month["2026-04"] == 0 or by_month["2026-05"] == 0:
        decision = "EVENT_DATA_INSUFFICIENT"
    elif len(hardstop_life) >= max(10, math.ceil(len(hardstop_total) * 0.5)) and mismatch_count > 0:
        decision = "EVENT_BLACKOUT_GAP_STRONG"
    elif len(hardstop_life) > 0 and mismatch_count > 0:
        decision = "EVENT_BLACKOUT_GAP_POSSIBLE"
    elif len(hardstop_life) == 0:
        decision = "EVENT_BLACKOUT_NOT_PRIMARY"
    else:
        decision = "EVENT_DATA_INSUFFICIENT"
    # Due to server offset and incomplete EA news logs, cap at possible/insufficient rather than strong causal proof.
    if decision == "EVENT_BLACKOUT_GAP_STRONG":
        decision = "EVENT_BLACKOUT_GAP_POSSIBLE"
    if "SERVER_LABEL_INFERRED" in ";".join(str(e["time_verified"]) for e in calendar):
        timezone_verified = "PARTIAL"
    else:
        timezone_verified = "true"
    if decision == "EVENT_BLACKOUT_GAP_POSSIBLE" and timezone_verified == "PARTIAL":
        selected = "EVENT_WINDOW_OVERLAP_PRESENT_TIMEZONE_PARTIAL"
    else:
        selected = decision

    event_blackout_logic_required = "true_candidate" if decision in {"EVENT_BLACKOUT_GAP_POSSIBLE", "EVENT_BLACKOUT_GAP_STRONG"} else "false_or_unproven"
    event_calendar_integration_required = "true"
    event_shadow_logging_required = "true"
    event_backtest_rerun_required = "false_current_audit; future controlled rerun only after design"

    final_text = f"""
selected_event_blackout_validation: {selected}
decision_class: {decision}
P1_implementation_allowed: false
real_exit_implementation_allowed: false
p1_specification_review_allowed: false
source_sha256: {source_start}
source_changed: false
calendar_source: LOCAL_EA_NEWS_BLACKOUT_CSV_PLUS_NEW_YORK_FED_AND_FEDERAL_RESERVE_MARCH_COMPLETION
calendar_source_sha256: {calendar_sha}
calendar_coverage_complete: true_for_locked_structural_calendar; EA_local_news_blackout_covers_only_2026-04-01_to_2026-05-29
timezone_verified: {timezone_verified}
high_impact_usd_event_count: {len(calendar)}
primary_window_minutes_before: 60
primary_window_minutes_after: 60
total_basket_count: {len(overlap_master)}
hardstop_basket_count: {len(hardstop_total)}
hardstop_entry_window_overlap_count: {len(hardstop_entry)}
hardstop_hedge_window_overlap_count: {len(hardstop_hedge)}
hardstop_close_window_overlap_count: {len(hardstop_close)}
hardstop_lifetime_window_overlap_count: {len(hardstop_life)}
event_window_hardstop_loss_yen: {round(event_window_hardstop_loss, 2)}
event_window_gross_loss_yen: {round(event_gross_loss, 2)}
non_event_window_hardstop_loss_yen: {round(non_event_hardstop_loss, 2)}
event_window_net_yen: {round(event_net, 2)}
non_event_window_net_yen: {round(non_event_net, 2)}
ea_newsblock_mismatch_count: {mismatch_count}
event_blackout_logic_required: {event_blackout_logic_required}
event_calendar_integration_required: {event_calendar_integration_required}
event_shadow_logging_required: {event_shadow_logging_required}
event_backtest_rerun_required: {event_backtest_rerun_required}
prehedge_shadow_phase1_still_required: true
market_structure_shadow_still_required: true
TA9_still_required: true
full_EA_counterfactual_claim_allowed: false
unresolved_risks: March server-time conversion is inferred; EA NewsBlock state is unavailable for most non-HardStop baskets; external calendar selection is fixed but actual/forecast/previous are NA; overlap is not causality.
next_action: Add minimal Event Risk fields to Phase 1 Multilayer Shadow Logging, or run Event Calendar Integration Design Freeze before any Event Stop implementation.
    """
    write_text("event_blackout_final_decision.txt", final_text)

    required_logic = f"""
Event Blackout Required Logic Assessment

Decision: {decision}

Interpretation:
- The audit found {len(hardstop_life)} HardStop baskets with lifetime overlap against the fixed primary +/-60 minute high-impact USD event window.
- HardStop entry-overlap count: {len(hardstop_entry)}.
- HardStop hedge-overlap count: {len(hardstop_hedge)}.
- HardStop close-overlap count: {len(hardstop_close)}.
- Event-window HardStop structural loss: {round(event_window_hardstop_loss, 2)} yen.
- EA NewsBlock mismatch count: {mismatch_count}.

This is structural evidence only. It does not prove that adding an Event Stop would reproduce the local exclusion values.

Required next logic:
- event_calendar_integration_required: true.
- event_shadow_logging_required: true.
- event_blackout_logic_required: {event_blackout_logic_required}.
- prehedge_shadow_phase1_still_required: true.
- market_structure_shadow_still_required: true.
- TA9_still_required: true.
    """
    write_text("event_blackout_required_logic_assessment.txt", required_logic)

    summary = f"""
High Impact Event Blackout Window Structural Audit

Conclusion:
- decision_class: {decision}
- selected_event_blackout_validation: {selected}
- The existing EA local news file covers April-May only. March was completed with fixed external New York Fed / Federal Reserve sources, but March server-label conversion remains inferred.
- Primary window is fixed at +/-60 minutes.
- Full EA counterfactual is not claimed.

Main counts:
- total Basket count: {len(overlap_master)}
- HardStop Basket count: {len(hardstop_total)}
- HardStop entry +/-60m overlap: {len(hardstop_entry)}
- HardStop hedge +/-60m overlap: {len(hardstop_hedge)}
- HardStop close +/-60m overlap: {len(hardstop_close)}
- HardStop lifetime +/-60m overlap: {len(hardstop_life)}
- event-window HardStop structural loss: {round(event_window_hardstop_loss, 2)} yen
- event-window gross loss: {round(event_gross_loss, 2)} yen
- non-event-window HardStop loss: {round(non_event_hardstop_loss, 2)} yen
- EA NewsBlock mismatch count: {mismatch_count}

Effect on plan:
- Pre-Hedge Phase 1 Shadow remains required.
- Market Structure Shadow remains required.
- TA9 remains required.
- Minimal Event Risk fields should be included in Phase 1 logging or preceded by a dedicated Event Calendar Integration Design Freeze.
    """
    write_text("event_blackout_audit_summary.txt", summary)
    write_text("result_summary.txt", summary)
    write_text("next_decision.txt", "Next Decision\n\nRecommended next step: Phase 1 Multilayer Shadow Logging Implementation with minimal Event Risk availability/proxy fields, or Event Calendar Integration Design Freeze if calendar ingestion must be formalized first.\n\nStill forbidden: EA logic implementation, Event Stop, TA9 actual exit, Pre-Hedge Exit, Hedge Gate, Market Structure Filter, Strategy Tester rerun, and P1 implementation.\n")
    write_text("timezone_verification_audit.txt", f"""
Timezone Verification Audit

Basket timestamps:
- Existing Basket logs use MT5 server label timestamps.

Local EA news_blackout.csv:
- EventTimeJST and EventTimeServer are both present.
- April-May rows are internally consistent with JST -> UTC -> Europe/Athens/EEST server labels.
- This confirms the April-May server label alignment used by the EA file.

March external source:
- New York Fed calendar states event times are Eastern Time.
- Federal Reserve FOMC page states March 18 statement release at 2:00 p.m.
- March event UTC conversion uses America/New_York with DST rules.
- March MT5 server label uses Europe/Athens EET/EEST model inferred from XM server behavior and the April-May file.

Result:
- timezone_verified: {timezone_verified}
- Strong causal conclusions are not made from March-only overlap because server-label offset is inferred.
    """)
    write_text("calculation_self_audit.txt", """
Calculation Self Audit

- Input ZIP SHA256 values were checked before calculation.
- EA source SHA256 was checked before and after calculation.
- Primary event window fixed at +/-60 minutes before calculation.
- Sensitivity windows were calculated separately and were not used to select the final primary result.
- Missing actual/forecast/previous values remain NA.
- Non-HardStop hedge start times are NOT_AVAILABLE when absent from basket source data.
- Local exclusion diagnostics subtract existing basket outcomes only and are not a full EA counterfactual.
- Strategy Tester was not executed.
- EA source was not modified.
    """)
    write_text("source_unchanged_verification.txt", f"""
Source Unchanged Verification

source_file: KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5
expected_sha256: {SOURCE_EXPECTED_SHA}
start_sha256: {source_start}
end_sha256: {sha256_file(SOURCE_FILE)}
source_changed: false
mq5_changed: false
mqh_changed: false
EX5_changed: false
Strategy_Tester_executed: false
Compile_executed: false
EA_logic_changed: false
    """)
    write_text("publication_consistency_check.txt", """
Publication Consistency Check

Status at bundle build:
- PUBLICATION_TARGETS_DEFINED

Expected publication:
- named ZIP: KOUCHA_GOLD_EVENT_BLACKOUT_WINDOW_AUDIT.zip
- archive ZIP: archive/KOUCHA_GOLD_EVENT_BLACKOUT_WINDOW_AUDIT_LOCKED_<timestamp>.zip
- current final decision: current/event_blackout_final_decision.txt
- current summary: current/event_blackout_audit_summary.txt

Final HTTP/R2 verification is recorded after publication.
    """)
    write_text("ai_bundle.txt", f"""
AI Bundle

Audit: High Impact Event Blackout Window Structural Audit
Decision: {decision}

Calendar:
- locked economic_calendar_events.csv SHA256: {calendar_sha}
- primary window: +/-60 minutes
- event count: {len(calendar)}
- timezone_verified: {timezone_verified}

Counts:
- total baskets: {len(overlap_master)}
- hardstops: {len(hardstop_total)}
- hardstop entry overlap: {len(hardstop_entry)}
- hardstop hedge overlap: {len(hardstop_hedge)}
- hardstop close overlap: {len(hardstop_close)}
- hardstop lifetime overlap: {len(hardstop_life)}
- ea_newsblock_mismatch_count: {mismatch_count}

Fixed flags:
- P1_implementation_allowed=false
- real_exit_implementation_allowed=false
- p1_specification_review_allowed=false
- full_EA_counterfactual_claim_allowed=false
    """)

    # Copy script into artifact.
    shutil.copy2(ROOT / "build_event_blackout_audit.py", SCRIPTS / "build_event_blackout_audit.py")
    # Required script aliases.
    for script_name in [
        "build_locked_economic_calendar.py",
        "verify_event_timezones.py",
        "join_baskets_to_event_windows.py",
        "compare_ea_newsblock_to_calendar.py",
        "calculate_event_window_diagnostics.py",
        "build_event_blackout_audit_bundle.py",
    ]:
        (SCRIPTS / script_name).write_text(
            "# Wrapper: logic is centralized in build_event_blackout_audit.py for reproducibility.\n"
            "from build_event_blackout_audit import build\n"
            "if __name__ == '__main__':\n"
            "    build()\n",
            encoding="utf-8",
        )

    if sha256_file(SOURCE_FILE) != SOURCE_EXPECTED_SHA:
        raise SystemExit("Source SHA changed")


if __name__ == "__main__":
    build()
