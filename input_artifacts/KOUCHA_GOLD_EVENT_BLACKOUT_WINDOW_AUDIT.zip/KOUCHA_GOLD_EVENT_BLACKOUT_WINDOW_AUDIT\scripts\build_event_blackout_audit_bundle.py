# Wrapper: logic is centralized in build_event_blackout_audit.py for reproducibility.
from build_event_blackout_audit import build
if __name__ == '__main__':
    build()
