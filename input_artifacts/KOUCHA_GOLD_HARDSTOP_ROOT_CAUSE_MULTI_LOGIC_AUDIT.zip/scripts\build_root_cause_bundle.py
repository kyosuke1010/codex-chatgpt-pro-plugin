#!/usr/bin/env python3
"""Build HardStop root-cause and multi-logic audit artifacts.

This script is intentionally read-only against EA source and prior audit inputs.
It consumes the existing payoff basket table and runtime A-series trade events,
then writes diagnostic CSV/TXT artifacts into the current audit directory.
"""

from __future__ import annotations

import csv
import hashlib
import math
import os
import statistics
import sys
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "KOUCHA_GOLD_HARDSTOP_ROOT_CAUSE_MULTI_LOGIC_AUDIT"
PAYOFF = ROOT / "KOUCHA_GOLD_CURRENT_EA_BASKET_PAYOFF_STRUCTURE_AUDIT"
RUNTIME = ROOT / "KOUCHA_GOLD_TA9_SHADOW_RUNTIME_REGRESSION_AUDIT"
CANDIDATE = ROOT / "KOUCHA_GOLD_TIMING_ALIGNMENT_CANDIDATE_SAFETY_AUDIT"
MULTI_AXIS = ROOT / "KOUCHA_GOLD_TIMING_ALIGNMENT_MULTI_AXIS_AUDIT"
SOURCE = ROOT / "KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5"

EXPECTED = {
    "KOUCHA_GOLD_CURRENT_EA_BASKET_PAYOFF_STRUCTURE_AUDIT.zip": "304CAB4BF516D465F8B88096EFAE805CE00D6B3C2B3399851BB15164052C1E8D",
    "KOUCHA_GOLD_TIMING_ALIGNMENT_CANDIDATE_SAFETY_AUDIT.zip": "7A8008A27F20184188423E18193F27BD918D0003B404A814092BB7FEF5DC1C24",
    "KOUCHA_GOLD_TA9_SHADOW_RUNTIME_REGRESSION_AUDIT.zip": "07E61AE4ED26AFAE4041CF9F9B93BD8D103299D98580EA42BF647B9024532423",
    "KOUCHA_GOLD_TIMING_ALIGNMENT_MULTI_AXIS_AUDIT.zip": "01574CC3481878A15B11B54ECC866E8618C33E9715D36AA22E8B1F6058F037D4",
    "KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5": "1353718F46D727DB775827AAF30F86EC790056CB59CE46EB00D5BAD563EF1DE3",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    rows = list(rows)
    if fieldnames is None:
        names: list[str] = []
        for row in rows:
            for key in row:
                if key not in names:
                    names.append(key)
        fieldnames = names
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: fmt(row.get(k, "")) for k in fieldnames})


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.replace("\r\n", "\n"), encoding="utf-8")


def fmt(value: Any) -> str:
    if value is None:
        return "NA"
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return "NA"
        return f"{value:.6f}".rstrip("0").rstrip(".")
    if isinstance(value, bool):
        return "true" if value else "false"
    value = str(value)
    return value if value != "" else "NA"


def to_float(value: Any, default: float | None = None) -> float | None:
    if value is None:
        return default
    s = str(value).strip()
    if s == "" or s.upper() == "NA":
        return default
    try:
        return float(s.replace(",", ""))
    except ValueError:
        return default


def to_int(value: Any, default: int = 0) -> int:
    f = to_float(value, None)
    return default if f is None else int(f)


def to_bool(value: Any) -> bool | None:
    s = str(value).strip().lower()
    if s in {"true", "1", "yes"}:
        return True
    if s in {"false", "0", "no"}:
        return False
    return None


def parse_time(value: str) -> datetime | None:
    value = (value or "").strip()
    if not value or value.upper() == "NA":
        return None
    for pattern in ("%Y.%m.%d %H:%M:%S", "%Y.%m.%d", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value, pattern)
        except ValueError:
            pass
    return None


def td_seconds(start: datetime | None, end: datetime | None) -> int | None:
    if not start or not end:
        return None
    return int((end - start).total_seconds())


def is_entry(row: dict[str, str]) -> bool:
    return row.get("EventType", "").startswith("ENTRY_")


def is_hedge(row: dict[str, str]) -> bool:
    et = row.get("EventType", "")
    return et.startswith("DEFENSE_HEDGE_")


def is_close(row: dict[str, str]) -> bool:
    return row.get("EventType", "") in {"BASKET_CLOSE", "HARDSTOP_CLOSE", "HEDGED_BASKET_TIME_EXIT"}


def normalize_direction(value: str) -> str:
    s = (value or "").strip().upper()
    if "BUY" in s or "BULL" in s:
        return "BUY"
    if "SELL" in s or "BEAR" in s:
        return "SELL"
    return "UNKNOWN"


def direction_aligned(entry_direction: str, trend_text: str) -> str:
    entry = normalize_direction(entry_direction)
    trend = normalize_direction(trend_text)
    if entry == "UNKNOWN" or trend == "UNKNOWN":
        return "UNKNOWN"
    return "TRUE" if entry == trend else "FALSE"


def rowval(row: dict[str, str] | None, key: str) -> str:
    if row is None:
        return "NA"
    return row.get(key, "") or "NA"


def severity_from_counts(total: int, positives: int, data_known: bool = True) -> str:
    if not data_known:
        return "DATA_INSUFFICIENT"
    if total <= 0:
        return "NO_SAMPLE"
    ratio = positives / total
    if ratio >= 0.65:
        return "STRONG"
    if ratio >= 0.35:
        return "MEDIUM"
    if ratio > 0:
        return "WEAK"
    return "NO_EVIDENCE"


@dataclass
class BasketEvidence:
    master: dict[str, str]
    events: list[dict[str, str]]
    entry: dict[str, str] | None
    hedge: dict[str, str] | None
    close: dict[str, str] | None

    @property
    def run_id(self) -> str:
        return self.master["run_id"]

    @property
    def basket_uid(self) -> str:
        return self.master["basket_uid"]


def load_inputs() -> tuple[list[dict[str, str]], dict[str, list[dict[str, str]]]]:
    baskets = read_csv(PAYOFF / "basket_master_table.csv")
    events_by_run: dict[str, list[dict[str, str]]] = {}
    for path in sorted(RUNTIME.rglob("*TRADE_EVENTS.csv")):
        if "TA9_A_FRESH_BASELINE" not in str(path):
            continue
        run_id = path.parent.name
        rows = read_csv(path)
        for row in rows:
            row["_server_dt"] = parse_time(row.get("ServerTime", ""))  # type: ignore[assignment]
            row["_source_file"] = str(path.relative_to(ROOT))
        events_by_run[run_id] = rows
    return baskets, events_by_run


def attach_events(baskets: list[dict[str, str]], events_by_run: dict[str, list[dict[str, str]]]) -> list[BasketEvidence]:
    by_run_baskets: dict[str, list[dict[str, str]]] = defaultdict(list)
    for basket in baskets:
        by_run_baskets[basket["run_id"]].append(basket)
    evidence: list[BasketEvidence] = []
    for run_id, run_baskets in by_run_baskets.items():
        run_events = [r for r in events_by_run.get(run_id, []) if isinstance(r.get("_server_dt"), datetime)]
        run_events.sort(key=lambda r: r["_server_dt"])  # type: ignore[index]
        run_baskets.sort(key=lambda b: to_int(b.get("basket_sequence")))
        for idx, basket in enumerate(run_baskets):
            start = parse_time(basket.get("basket_start_time", ""))
            end = parse_time(basket.get("basket_end_time", ""))
            if end is None and idx + 1 < len(run_baskets):
                end = parse_time(run_baskets[idx + 1].get("basket_start_time", ""))
            selected = []
            for row in run_events:
                dt = row.get("_server_dt")
                if not isinstance(dt, datetime) or start is None:
                    continue
                if dt < start:
                    continue
                if end is not None and dt > end:
                    continue
                selected.append(row)
            entry = next((r for r in selected if is_entry(r)), None)
            hedge = next((r for r in selected if is_hedge(r)), None)
            close_rows = [r for r in selected if is_close(r)]
            close = close_rows[-1] if close_rows else None
            evidence.append(BasketEvidence(basket, selected, entry, hedge, close))
    return evidence


def hardstop_class(ev: BasketEvidence) -> list[str]:
    m = ev.master
    classes: list[str] = []
    hedged = to_int(m.get("hedge_count")) > 0
    if hedged:
        classes.append("HEDGED_HARDSTOP")
    else:
        classes.append("NEVER_HEDGED_HARDSTOP")
    entry_count = to_int(m.get("entry_count"))
    if entry_count > 1:
        classes.append("MULTI_ENTRY_ACCUMULATION")
    if hedged and ev.hedge is not None:
        hp = to_float(ev.hedge.get("FloatingProfitYen"), None)
        fp = to_float(m.get("net_profit"), None)
        if hp is not None and fp is not None:
            if abs(hp) >= abs(fp) * 0.65:
                classes.append("LOSS_ALREADY_DOMINANT_BEFORE_HEDGE")
            else:
                classes.append("LOSS_MAINLY_ACCUMULATED_AFTER_HEDGE")
        dist = distance_to_hardstop_at_row(ev.hedge, ev.master)
        if dist != "NA":
            try:
                d = float(dist)
                threshold = abs(to_float(m.get("net_profit"), 0.0) or 0.0)
                if threshold and d / threshold < 0.25:
                    classes.append("HEDGE_STARTED_NEAR_HARDSTOP")
            except ValueError:
                pass
    vix = rowval(ev.close, "VixState").lower()
    tech = rowval(ev.close, "TechnicalDangerBlockReason")
    if vix in {"stop", "extreme"} or "ATR expansion" in tech:
        classes.append("RAPID_PRICE_SHOCK")
    if rowval(ev.close, "NewsState").lower().endswith("blackout"):
        classes.append("EVENT_RISK_EXPOSED")
    if rowval(ev.entry, "PriceTooFarFromMa").lower() == "true" or "near current" in tech:
        classes.append("MARKET_STRUCTURE_MISMATCH")
    if not classes:
        classes.append("DATA_INSUFFICIENT")
    return sorted(set(classes))


def distance_to_hardstop_at_row(row: dict[str, str] | None, basket: dict[str, str]) -> str:
    if row is None:
        return "NA"
    floating = to_float(row.get("FloatingProfitYen"), None)
    final_loss = abs(to_float(basket.get("net_profit"), 0.0) or 0.0)
    if floating is None or final_loss <= 0:
        return "NA"
    return fmt(final_loss - abs(min(floating, 0.0)))


def build_hardstop_path(evidence: list[BasketEvidence]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for ev in evidence:
        if ev.master.get("final_close_reason") != "HARDSTOP_CLOSE":
            continue
        start = parse_time(ev.master.get("basket_start_time", ""))
        end = parse_time(ev.master.get("basket_end_time", ""))
        hedge_dt = parse_time(rowval(ev.hedge, "ServerTime"))
        entry_dt = parse_time(rowval(ev.entry, "ServerTime"))
        net = to_float(ev.master.get("net_profit"), 0.0) or 0.0
        hedge_pl = to_float(rowval(ev.hedge, "FloatingProfitYen"), None)
        loss_before = ""
        loss_after = ""
        if hedge_pl is not None:
            loss_before = min(0.0, hedge_pl)
            loss_after = net - loss_before
        rows.append(
            {
                "basket_uid": ev.basket_uid,
                "run_id": ev.run_id,
                "period": ev.master.get("period_label"),
                "capital": ev.master.get("deposit"),
                "symbol": ev.master.get("symbol"),
                "basket_start_time": ev.master.get("basket_start_time"),
                "first_entry_time": rowval(ev.entry, "ServerTime"),
                "final_hardstop_time": ev.master.get("basket_end_time"),
                "holding_duration_minutes": ev.master.get("holding_minutes"),
                "entry_count": ev.master.get("entry_count"),
                "additional_entry_count": max(0, to_int(ev.master.get("entry_count")) - 1),
                "hedge_count": ev.master.get("hedge_count"),
                "first_hedge_time": rowval(ev.hedge, "ServerTime"),
                "never_hedged_or_hedged": "HEDGED" if to_int(ev.master.get("hedge_count")) else "NEVER_HEDGED",
                "pl_at_first_hedge": fmt(hedge_pl),
                "final_pl": fmt(net),
                "loss_before_hedge": fmt(loss_before),
                "loss_after_hedge": fmt(loss_after),
                "final_close_reason": ev.master.get("final_close_reason"),
                "hardstop_basis": "floating_loss_proxy_from_runtime_fields",
                "margin_level_at_hardstop": rowval(ev.close, "MarginLevel"),
                "floating_loss_percent_at_hardstop": rowval(ev.close, "FloatingLossPercent"),
                "spread_price_at_hardstop": rowval(ev.close, "SpreadPrice"),
                "large_candle_condition": rowval(ev.close, "LargeCandleDetected"),
                "candle_danger_reason": rowval(ev.close, "CandleDangerReason"),
                "dxy_condition": rowval(ev.close, "DxyState"),
                "vix_condition": rowval(ev.close, "VixState"),
                "news_condition": rowval(ev.close, "NewsState"),
                "market_session": "NOT_AVAILABLE",
                "weekday": end.strftime("%A") if end else "NA",
                "month_boundary": month_boundary(end),
                "friday_close_proximity": friday_close_proximity(end),
                "entry_direction": ev.master.get("first_entry_direction"),
                "entry_vs_ma_trend_aligned": direction_aligned(ev.master.get("first_entry_direction", ""), rowval(ev.entry, "MaTrendDirection")),
                "entry_ma_trend": rowval(ev.entry, "MaTrendDirection"),
                "entry_htf_state": rowval(ev.entry, "HTFState"),
                "entry_higher_tf_direction": rowval(ev.entry, "HigherTimeframeDirection"),
                "entry_price_too_far_from_ma": rowval(ev.entry, "PriceTooFarFromMa"),
                "entry_price_near_ma_pullback": rowval(ev.entry, "PriceNearMaPullback"),
                "entry_ma_block_buy": rowval(ev.entry, "MaStructureBlockReasonBuy"),
                "entry_ma_block_sell": rowval(ev.entry, "MaStructureBlockReasonSell"),
                "entry_pullback_block_buy": rowval(ev.entry, "PullbackBlockReasonBuy"),
                "entry_pullback_block_sell": rowval(ev.entry, "PullbackBlockReasonSell"),
                "hardstop_technical_danger": rowval(ev.close, "TechnicalDangerBlockReason"),
                "root_cause_classes": ";".join(hardstop_class(ev)),
            }
        )
    return rows


def month_boundary(dt: datetime | None) -> str:
    if not dt:
        return "NA"
    if dt.day <= 3:
        return "MONTH_START"
    if dt.day >= 27:
        return "MONTH_END"
    return "MID_MONTH"


def friday_close_proximity(dt: datetime | None) -> str:
    if not dt:
        return "NA"
    if dt.weekday() == 4 and dt.hour >= 18:
        return "FRIDAY_LATE"
    return "NO"


def build_event_risk(hardstops: list[BasketEvidence]) -> tuple[list[dict[str, Any]], str]:
    rows = []
    event_evidence = 0
    for ev in hardstops:
        entry_news = rowval(ev.entry, "NewsState")
        close_news = rowval(ev.close, "NewsState")
        entry_block = rowval(ev.entry, "NewsBlockActive")
        close_block = rowval(ev.close, "NewsBlockActive")
        vix = rowval(ev.close, "VixState")
        dxy = rowval(ev.close, "DxyState")
        classification = "NO_EVENT_EVIDENCE"
        if "blackout" in entry_news.lower() or "blackout" in close_news.lower() or entry_block.lower() == "true" or close_block.lower() == "true":
            classification = "EVENT_STOP_MISSED_POSSIBLE"
            event_evidence += 1
        elif not entry_news or entry_news == "NA":
            classification = "EVENT_DATA_NOT_AVAILABLE"
        rows.append(
            {
                "basket_uid": ev.basket_uid,
                "entry_time": rowval(ev.entry, "ServerTime"),
                "hardstop_time": ev.master.get("basket_end_time"),
                "event_within_30m": "NOT_AVAILABLE",
                "event_within_60m": "NOT_AVAILABLE",
                "event_within_120m": "NOT_AVAILABLE",
                "event_currency": "NOT_AVAILABLE",
                "event_impact": "NOT_AVAILABLE",
                "actual": "NOT_AVAILABLE",
                "forecast": "NOT_AVAILABLE",
                "previous": "NOT_AVAILABLE",
                "entry_news_state": entry_news,
                "hardstop_news_state": close_news,
                "entry_news_block_active": entry_block,
                "hardstop_news_block_active": close_block,
                "news_block_event_name": rowval(ev.close, "NewsBlockEventName"),
                "spread_price_at_hardstop": rowval(ev.close, "SpreadPrice"),
                "large_candle_detected": rowval(ev.close, "LargeCandleDetected"),
                "technical_danger": rowval(ev.close, "TechnicalDangerBlockReason"),
                "dxy_state": dxy,
                "vix_state": vix,
                "classification": classification,
            }
        )
    text = f"""Event Risk / News Stop Gap Analysis

Scope: 37 HardStop baskets from existing six in-sample P0_A2_BASE_D4 runs.
External economic-calendar data: NOT_AVAILABLE in supplied artifacts.
Internet backfill: not used by audit rule.

Result:
- Direct high-impact event attribution is not possible from current evidence.
- Runtime fields show NewsState and NewsBlockActive, but do not include verified CPI/FOMC/NFP/PCE event windows for each Basket.
- HardStop baskets with runtime news blackout evidence: {event_evidence}
- Therefore Event Risk Stop is a required research/logging layer, but not proven as the dominant root cause from available logs.

Design implication:
- Add future non-intervening event-window logging before changing entry or close logic.
- Do not infer missing events as false or zero.
"""
    return rows, text


def field_distribution(evs: Iterable[BasketEvidence], field: str, row_kind: str) -> Counter:
    counter: Counter[str] = Counter()
    for ev in evs:
        source = ev.entry if row_kind == "entry" else ev.close
        counter[rowval(source, field)] += 1
    return counter


def build_market_structure(hardstops: list[BasketEvidence], winners: list[BasketEvidence]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    hs_rows = []
    for ev in hardstops:
        entry = ev.entry
        close = ev.close
        entry_dir = ev.master.get("first_entry_direction", "")
        aligned = direction_aligned(entry_dir, rowval(entry, "MaTrendDirection"))
        cls = "DATA_INSUFFICIENT"
        if rowval(entry, "PriceTooFarFromMa").lower() == "true":
            cls = "EXHAUSTION_ENTRY"
        elif aligned == "FALSE":
            cls = "STRUCTURE_MISMATCH_ENTRY"
        elif "near current" in rowval(close, "TechnicalDangerBlockReason"):
            cls = "FAILED_BREAKOUT_ENTRY"
        elif aligned == "TRUE":
            cls = "STRUCTURE_ALIGNED_ENTRY"
        hs_rows.append(
            {
                "basket_uid": ev.basket_uid,
                "entry_time": rowval(entry, "ServerTime"),
                "entry_direction": entry_dir,
                "htf_state": rowval(entry, "HTFState"),
                "higher_timeframe_direction": rowval(entry, "HigherTimeframeDirection"),
                "ma_trend_direction": rowval(entry, "MaTrendDirection"),
                "entry_vs_ma_trend_aligned": aligned,
                "distance_from_recent_high": rowval(entry, "DistanceFromRecentHigh"),
                "distance_from_recent_low": rowval(entry, "DistanceFromRecentLow"),
                "recent_high": rowval(entry, "RecentHigh"),
                "recent_low": rowval(entry, "RecentLow"),
                "price_too_far_from_ma": rowval(entry, "PriceTooFarFromMa"),
                "price_near_ma_pullback": rowval(entry, "PriceNearMaPullback"),
                "technical_danger_at_hardstop": rowval(close, "TechnicalDangerBlockReason"),
                "classification": cls,
                "evidence_basis": "runtime MA/HTF/recent-high-low proxy; full swing series not available",
            }
        )
    compare_rows = []
    for name, group in [("hardstop", hardstops), ("winner_basketclose", winners)]:
        total = len(group)
        for field in [
            "HTFState",
            "HigherTimeframeDirection",
            "MaTrendDirection",
            "PriceTooFarFromMa",
            "PriceNearMaPullback",
            "CounterTrendBlocked",
            "SpikeUpBlocked",
            "SpikeDownBlocked",
        ]:
            dist = field_distribution(group, field, "entry")
            for value, count in sorted(dist.items()):
                compare_rows.append({"group": name, "field": field, "value": value, "count": count, "share": count / total if total else "NA"})
    return hs_rows, compare_rows


def build_fib(hardstops: list[BasketEvidence], winners: list[BasketEvidence]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    def make(ev: BasketEvidence, group: str) -> dict[str, Any]:
        entry = ev.entry
        present = rowval(entry, "IsPriceInFibZone")
        aligned = rowval(entry, "FibTrendAligned")
        conflict = "UNKNOWN"
        if present.lower() == "true" and aligned.lower() == "false":
            conflict = "PRZ_CONFLICT_WITH_ENTRY"
        elif present.lower() == "true" and aligned.lower() == "true":
            conflict = "FIB_PRZ_ALIGNMENT_OK"
        elif present.lower() == "false":
            conflict = "NO_PRZ_EVIDENCE"
        return {
            "group": group,
            "basket_uid": ev.basket_uid,
            "entry_time": rowval(entry, "ServerTime"),
            "macro_fib_direction": rowval(entry, "MacroFibDirection"),
            "day_fib_direction": rowval(entry, "DayFibDirection"),
            "entry_fib_direction": rowval(entry, "EntryFibDirection"),
            "current_fib_zone": rowval(entry, "CurrentFibZone"),
            "is_price_in_fib_zone": present,
            "fib_trend_aligned": aligned,
            "macro_day_fib_aligned": rowval(entry, "MacroDayFibAligned"),
            "fib_structure_broken": rowval(entry, "FibStructureBroken"),
            "nearest_fib_level": "NOT_AVAILABLE",
            "distance_to_fib": "NOT_AVAILABLE",
            "fib_cluster_count": "NOT_AVAILABLE",
            "classification": conflict if present != "NA" else "DATA_INSUFFICIENT",
            "evidence_basis": "runtime fib context fields only; no full pre-entry swing reconstruction supplied",
        }
    return [make(ev, "hardstop") for ev in hardstops], [make(ev, "winner_basketclose") for ev in winners]


def build_harmonic_elliott(hardstops: list[BasketEvidence]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    harmonic = []
    elliott = []
    for ev in hardstops:
        harmonic.append(
            {
                "basket_uid": ev.basket_uid,
                "entry_time": rowval(ev.entry, "ServerTime"),
                "abcd_ratio": "NOT_AVAILABLE",
                "gartley_zone": "NOT_AVAILABLE",
                "bat_zone": "NOT_AVAILABLE",
                "butterfly_zone": "NOT_AVAILABLE",
                "crab_zone": "NOT_AVAILABLE",
                "classification": "DATA_INSUFFICIENT",
                "reason": "No objective swing sequence or ratio matrix is present in supplied runtime logs.",
            }
        )
        elliott_cls = "ELLIOTT_PROXY_INCONCLUSIVE"
        if rowval(ev.entry, "PriceTooFarFromMa").lower() == "true":
            elliott_cls = "EXHAUSTION_RISK_ENTRY"
        elliott.append(
            {
                "basket_uid": ev.basket_uid,
                "entry_time": rowval(ev.entry, "ServerTime"),
                "last_3_swing_direction": "NOT_AVAILABLE",
                "last_5_swing_direction": "NOT_AVAILABLE",
                "extended_impulse_proxy": rowval(ev.entry, "PriceTooFarFromMa"),
                "corrective_pullback_proxy": rowval(ev.entry, "PriceNearMaPullback"),
                "structure_break_after_entry": "NOT_AVAILABLE",
                "time_to_structure_break_after_entry": "NOT_AVAILABLE",
                "classification": elliott_cls,
                "reason": "MA distance/pullback fields provide only a weak proxy; no Elliott wave claim is made.",
            }
        )
    return harmonic, elliott


def build_ma(hardstops: list[BasketEvidence], winners: list[BasketEvidence]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str]:
    rows = []
    retest = []
    mismatch_count = 0
    nonhedged_warning = 0
    for ev in hardstops:
        entry = ev.entry
        close = ev.close
        direction = ev.master.get("first_entry_direction", "")
        aligned = direction_aligned(direction, rowval(entry, "MaTrendDirection"))
        mismatch = aligned == "FALSE" or rowval(entry, "PriceTooFarFromMa").lower() == "true"
        if mismatch:
            mismatch_count += 1
        if to_int(ev.master.get("hedge_count")) == 0 and mismatch:
            nonhedged_warning += 1
        cls = "MA_REGIME_ALIGNED"
        if mismatch:
            cls = "MA_REGIME_MISMATCH"
        elif rowval(entry, "PriceNearMaPullback").lower() == "true":
            cls = "MA_PULLBACK_ENTRY_SUPPORTED"
        rows.append(
            {
                "basket_uid": ev.basket_uid,
                "stage": "entry",
                "time": rowval(entry, "ServerTime"),
                "entry_direction": direction,
                "ma_trend_direction": rowval(entry, "MaTrendDirection"),
                "ma_fast": rowval(entry, "MaFastValue"),
                "ma_middle": rowval(entry, "MaMiddleValue"),
                "ma_long": rowval(entry, "MaLongValue"),
                "ma_fast_slope": rowval(entry, "MaFastSlope"),
                "ma_middle_slope": rowval(entry, "MaMiddleSlope"),
                "ma_long_slope": rowval(entry, "MaLongSlope"),
                "distance_to_ma_fast": rowval(entry, "DistanceToMaFast"),
                "distance_to_ma_middle": rowval(entry, "DistanceToMaMiddle"),
                "price_too_far_from_ma": rowval(entry, "PriceTooFarFromMa"),
                "price_near_ma_pullback": rowval(entry, "PriceNearMaPullback"),
                "entry_vs_ma_trend_aligned": aligned,
                "classification": cls,
            }
        )
        if to_int(ev.master.get("hedge_count")) == 0:
            retest.append(
                {
                    "basket_uid": ev.basket_uid,
                    "hardstop_time": ev.master.get("basket_end_time"),
                    "hedge_state": "NEVER_HEDGED",
                    "ma_warning_at_entry": mismatch,
                    "ma_retest_exit_opportunity": "POSSIBLE_LOG_PROXY" if mismatch else "NOT_OBSERVED",
                    "evidence_basis": "entry MA alignment and distance only; no intra-basket MA retest timeline in supplied logs",
                }
            )
    winner_align = Counter()
    for ev in winners:
        winner_align[direction_aligned(ev.master.get("first_entry_direction", ""), rowval(ev.entry, "MaTrendDirection"))] += 1
    text = f"""M5 MA Pullback / Retest Logic Feasibility

HardStop sample: {len(hardstops)} baskets.
HardStop baskets with MA mismatch or over-extension proxy at entry: {mismatch_count}
Never-hedged HardStops with entry MA warning proxy: {nonhedged_warning}
Winner entry alignment distribution: {dict(winner_align)}

Assessment:
- MA/pullback runtime fields exist and are usable for non-intervening diagnosis.
- Available logs do not contain a continuous intra-basket MA retest timeline, so a literal "break MA then exit on retest" opportunity cannot be verified basket-by-basket.
- The evidence supports M5 MA pullback/retest logic as a research candidate, especially for never-hedged HardStops, but requires additional shadow logging before implementation.
"""
    return rows, retest, text


def build_exposure(hardstops: list[BasketEvidence]) -> list[dict[str, Any]]:
    rows = []
    for ev in hardstops:
        entry_count = to_int(ev.master.get("entry_count"))
        hedge_count = to_int(ev.master.get("hedge_count"))
        classification = "ADDITIONAL_ENTRY_NEUTRAL"
        if entry_count > 1:
            classification = "ADDITIONAL_ENTRY_AMPLIFIED_LOSS"
        rows.append(
            {
                "basket_uid": ev.basket_uid,
                "initial_entry_side": ev.master.get("first_entry_direction"),
                "additional_entry_count": max(0, entry_count - 1),
                "max_total_positions": ev.master.get("max_simultaneous_positions"),
                "max_net_exposure": "NOT_AVAILABLE",
                "lot_sum": "NOT_AVAILABLE",
                "add_entry_timing": "NOT_APPLICABLE" if entry_count <= 1 else "NOT_AVAILABLE",
                "add_entry_direction_vs_structure": "NOT_APPLICABLE" if entry_count <= 1 else "NOT_AVAILABLE",
                "add_entry_direction_vs_ma_regime": "NOT_APPLICABLE" if entry_count <= 1 else "NOT_AVAILABLE",
                "add_entry_after_loss": "NOT_APPLICABLE" if entry_count <= 1 else "NOT_AVAILABLE",
                "add_entry_before_after_news": "NOT_APPLICABLE" if entry_count <= 1 else "NOT_AVAILABLE",
                "add_entry_before_after_dxy_vix": "NOT_APPLICABLE" if entry_count <= 1 else "NOT_AVAILABLE",
                "add_entry_before_hardstop_distance_shrink": "NOT_APPLICABLE" if entry_count <= 1 else "NOT_AVAILABLE",
                "hedge_count": hedge_count,
                "classification": classification,
            }
        )
    return rows


def build_hedge_transition(evidence: list[BasketEvidence]) -> tuple[list[dict[str, Any]], str]:
    rows = []
    hedged = [ev for ev in evidence if to_int(ev.master.get("hedge_count")) > 0]
    class_counter: Counter[str] = Counter()
    for ev in hedged:
        final_pl = to_float(ev.master.get("net_profit"), 0.0) or 0.0
        pl_at_hedge = to_float(rowval(ev.hedge, "FloatingProfitYen"), None)
        age = td_seconds(parse_time(ev.master.get("basket_start_time", "")), parse_time(rowval(ev.hedge, "ServerTime")))
        worst = rowval(ev.close, "BasketRecoveryWorstProfit")
        initial = rowval(ev.close, "BasketRecoveryInitialProfit")
        classification = "HEDGE_IS_LOSS_MARKER"
        if pl_at_hedge is not None and final_pl < 0:
            if abs(pl_at_hedge) >= abs(final_pl) * 0.65:
                classification = "HEDGE_IS_LOSS_MARKER"
            elif abs(pl_at_hedge) < abs(final_pl) * 0.35:
                classification = "HEDGE_STABILIZED_BUT_FAILED_TO_RECOVER"
            else:
                classification = "HEDGE_TOO_LATE"
        if ev.master.get("final_close_reason") == "UNRESOLVED_OR_END_OPEN":
            classification = "DATA_INSUFFICIENT"
        class_counter[classification] += 1
        rows.append(
            {
                "basket_uid": ev.basket_uid,
                "final_close_reason": ev.master.get("final_close_reason"),
                "pl_at_hedge": fmt(pl_at_hedge),
                "distance_to_hardstop_at_hedge_proxy": distance_to_hardstop_at_row(ev.hedge, ev.master),
                "basket_age_seconds_at_hedge": fmt(age),
                "entry_count_before_hedge": ev.master.get("entry_count"),
                "exposure_before_hedge": "NOT_AVAILABLE",
                "best_recovery_after_hedge": "NOT_AVAILABLE",
                "worst_deterioration_after_hedge": worst,
                "recovery_initial_profit": initial,
                "recovery_then_giveback": "NOT_VERIFIABLE_WITH_AVAILABLE_FIELDS",
                "actual_final_pl": fmt(final_pl),
                "classification": classification,
            }
        )
    text = f"""Hedge Admission Gate Feasibility

Hedged basket count: {len(hedged)}
Hedge transition classes: {dict(class_counter)}

Interpretation:
- Hedge being present does not prove hedge caused the loss.
- In this evidence set, every closed hedged Basket ended negative: 26 HardStop and 11 HTE.
- Hedge is therefore supported as a strong loss-marker and transition-control problem.
- Hedge removal is not supported by this audit. Required next work is admission/unwind shadow logging: P/L at hedge, distance to HardStop, post-hedge best recovery, giveback, and current HTE/Recovery eligibility.
"""
    return rows, text


def build_winner_ceiling(evidence: list[BasketEvidence]) -> tuple[list[dict[str, Any]], str]:
    winners = [ev for ev in evidence if (to_float(ev.master.get("net_profit"), 0.0) or 0.0) > 0]
    rows = []
    cap_count = 0
    for ev in winners:
        profit = to_float(ev.master.get("net_profit"), 0.0) or 0.0
        if 390 <= profit <= 420:
            cap_count += 1
        rows.append(
            {
                "basket_uid": ev.basket_uid,
                "realized_profit": fmt(profit),
                "final_close_reason": ev.master.get("final_close_reason"),
                "holding_minutes": ev.master.get("holding_minutes"),
                "hedged": ev.master.get("hedged"),
                "entry_count": ev.master.get("entry_count"),
                "profit_bucket": profit_bucket(profit),
                "near_390_420_cap": 390 <= profit <= 420,
                "mfe": "NA",
                "realized_over_mfe": "NA",
                "giveback": "NA",
                "capture_ratio": "NA",
                "classification": "FIXED_WINNER_CAP_CONFIRMED" if ev.master.get("final_close_reason") == "BASKET_CLOSE" and profit <= 420 else "WINNER_EXTENSION_DATA_REQUIRED",
            }
        )
    text = f"""Winner Extension Feasibility

Winning basket count: {len(winners)}
Winners in +390 to +420 yen band: {cap_count}
Maximum winning basket: {max((to_float(ev.master.get('net_profit'), 0.0) or 0.0) for ev in winners):.2f}
MFE fields: NOT_AVAILABLE

Assessment:
- Fixed winner ceiling is confirmed at the Basket level.
- Winner extension is a valid future research family, but it does not address the dominant HardStop left-tail first.
- Without MFE/giveback logs, winner extension design cannot be safely specified.
"""
    return rows, text


def profit_bucket(value: float) -> str:
    if value < 0:
        return "negative"
    if value < 200:
        return "0_199"
    if value < 300:
        return "200_299"
    if value < 390:
        return "300_389"
    if value <= 420:
        return "390_420"
    return "gt_420"


def build_logic_family_compare(
    hardstops: list[BasketEvidence],
    hardstop_path: list[dict[str, Any]],
    ta9_rows: list[dict[str, str]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], str, str]:
    total_loss = sum(abs(to_float(ev.master.get("net_profit"), 0.0) or 0.0) for ev in hardstops)
    hedged_hs = [ev for ev in hardstops if to_int(ev.master.get("hedge_count")) > 0]
    nonhedged_hs = [ev for ev in hardstops if to_int(ev.master.get("hedge_count")) == 0]
    ta9_effect = next(
        (
            to_float(r.get("filtered_net_effect_yen"), None)
            for r in ta9_rows
            if r.get("condition_name") == "TA9_FILTER_DISTANCE_TO_HARDSTOP_NONNEG"
        ),
        None,
    )
    if ta9_effect is None:
        ta9_effect = sum(to_float(r.get("hardstop_reduction_yen_corrected"), 0.0) or 0.0 for r in ta9_rows if r.get("final_close_reason") == "HARDSTOP_CLOSE")
    ma_mismatch = sum(1 for r in hardstop_path if r.get("entry_vs_ma_trend_aligned") == "FALSE" or str(r.get("entry_price_too_far_from_ma")).lower() == "true")
    ma_pullback_aligned = sum(1 for r in hardstop_path if str(r.get("entry_price_near_ma_pullback")).lower() == "true")
    event_possible = sum(1 for r in hardstop_path if "blackout" in str(r.get("news_condition", "")).lower())
    tech_danger = sum(1 for r in hardstop_path if str(r.get("hardstop_technical_danger", "NA")) not in {"NA", ""})
    families = [
        ("EVENT_RISK_STOP", event_possible, "UNKNOWN_WITH_LOG_GAP", "SECONDARY"),
        ("MARKET_STRUCTURE_REGIME_FILTER", tech_danger, "MEDIUM_LOG_PROXY", "PRIMARY"),
        ("FIB_PRZ_RISK_FILTER", 0, "DATA_INSUFFICIENT", "SUPPORT"),
        ("M5_MA_REGIME_PULLBACK_ENTRY_AND_RETEST_EXIT", ma_pullback_aligned, "ENTRY_PULLBACK_ALREADY_PRESENT_RETEST_EXIT_DATA_REQUIRED", "SUPPORT"),
        ("ADDITIONAL_ENTRY_EXPOSURE_CAP", 0, "NOT_SUPPORTED_BY_6RUN_ENTRY_COUNT", "DEFER"),
        ("PRE_HEDGE_DAMAGE_CONTROL", len(nonhedged_hs) + ma_mismatch, "STRONG_FOR_SCOPE", "PRIMARY"),
        ("HEDGE_ADMISSION_GATE", len(hedged_hs), "STRONG_LOSS_MARKER", "PRIMARY"),
        ("POST_HEDGE_RECOVERY_UNWIND", len(hedged_hs), "MEDIUM", "SECONDARY"),
        ("TA9_POST_HEDGE_TAIL_REDUCTION", len(hedged_hs), "SUPPORTED_IN_SAMPLE_LOCAL_DIAGNOSTIC", "SECONDARY"),
        ("WINNER_EXTENSION", 391, "FIXED_CAP_CONFIRMED_BUT_NOT_TAIL_ROOT", "DEFER"),
    ]
    rows = []
    for family, target_count, strength, role in families:
        overlap_ta9 = "HIGH" if family in {"HEDGE_ADMISSION_GATE", "POST_HEDGE_RECOVERY_UNWIND", "TA9_POST_HEDGE_TAIL_REDUCTION"} else "LOW"
        if family == "PRE_HEDGE_DAMAGE_CONTROL":
            target_loss = sum(abs(to_float(ev.master.get("net_profit"), 0.0) or 0.0) for ev in nonhedged_hs)
        elif family in {"HEDGE_ADMISSION_GATE", "POST_HEDGE_RECOVERY_UNWIND", "TA9_POST_HEDGE_TAIL_REDUCTION"}:
            target_loss = sum(abs(to_float(ev.master.get("net_profit"), 0.0) or 0.0) for ev in hedged_hs)
        else:
            target_loss = ""
        rows.append(
            {
                "logic_family": family,
                "target_basket_count": target_count,
                "target_hardstop_count": target_count if family != "WINNER_EXTENSION" else 0,
                "target_gross_loss": target_loss,
                "overlap_with_TA9": overlap_ta9,
                "protects_winners_or_kills_winners": "winner_kill_risk_requires_guard" if family != "WINNER_EXTENSION" else "protects_or_extents_winners",
                "current_evidence_strength": strength,
                "data_sufficiency": "partial" if "DATA" not in strength and "UNKNOWN" not in strength else "insufficient",
                "additional_logging_required": True,
                "implementation_complexity": "medium" if family != "WINNER_EXTENSION" else "high",
                "OOS_requirement": "native_tick_required",
                "likely_role": role,
            }
        )
    overlap = []
    names = [r["logic_family"] for r in rows]
    for a in names:
        for b in names:
            if a == b:
                rel = "SELF"
            elif "TA9" in (a, b) and ("HEDGE" in a or "HEDGE" in b or "RECOVERY" in a or "RECOVERY" in b):
                rel = "HIGH_OVERLAP"
            elif a.startswith("M5_MA") and b in {"PRE_HEDGE_DAMAGE_CONTROL", "MARKET_STRUCTURE_REGIME_FILTER"}:
                rel = "MEDIUM_OVERLAP"
            elif b.startswith("M5_MA") and a in {"PRE_HEDGE_DAMAGE_CONTROL", "MARKET_STRUCTURE_REGIME_FILTER"}:
                rel = "MEDIUM_OVERLAP"
            else:
                rel = "LOW_OR_UNKNOWN"
            overlap.append({"logic_family_a": a, "logic_family_b": b, "overlap_class": rel})
    layers = build_layers()
    text_layers = render_layers(layers)
    matrix = []
    for i, layer in enumerate(layers):
        layer = dict(layer)
        layer["priority_rank"] = i + 1
        matrix.append(layer)
    return rows, overlap, matrix, text_layers, render_summary_decision(total_loss, ta9_effect, len(hedged_hs), len(nonhedged_hs), ma_mismatch, ma_pullback_aligned, tech_danger)


def build_layers() -> list[dict[str, Any]]:
    return [
        {"layer": "Layer 0", "name": "Data / News / Event Availability Guard", "purpose": "prevent missing-data false confidence", "target_basket": "all", "target_loss": "unknown", "required_fields": "calendar event id, source, timestamp, sync status", "current_logs_available": "partial", "additional_logging_required": True, "runtime_stage": "pre-entry and per-basket snapshot", "conflict_risk": "low", "winner_kill_risk": "low", "testability": "high", "OOS_native_tick_requirement": "yes", "implementation_priority": "high"},
        {"layer": "Layer 1", "name": "Event Risk Stop", "purpose": "stop entry/add/hedge around verified high-impact events", "target_basket": "event-exposed baskets", "target_loss": "unknown", "required_fields": "event windows, NewsBlock reason, spread, DXY, VIX", "current_logs_available": "runtime news state only", "additional_logging_required": True, "runtime_stage": "entry/add/hedge admission", "conflict_risk": "medium", "winner_kill_risk": "medium", "testability": "medium", "OOS_native_tick_requirement": "yes", "implementation_priority": "medium"},
        {"layer": "Layer 2", "name": "Market Structure Regime Filter", "purpose": "avoid entries into structural mismatch or danger zones", "target_basket": "hardstop and high-risk entries", "target_loss": "hardstop left tail", "required_fields": "M5/M15/H1/H4 swing state, BOS/CHOCH/range, support/resistance", "current_logs_available": "MA/HTF/recent high-low proxies", "additional_logging_required": True, "runtime_stage": "pre-entry", "conflict_risk": "medium", "winner_kill_risk": "medium", "testability": "medium", "OOS_native_tick_requirement": "yes", "implementation_priority": "high"},
        {"layer": "Layer 3", "name": "Pullback Entry Quality Gate", "purpose": "require pullback quality and avoid MA over-extension", "target_basket": "non-hedged and pre-hedge damage baskets", "target_loss": "pre-hedge hardstop damage", "required_fields": "MA distance, slope, retest state, pullback confirmation", "current_logs_available": "partial", "additional_logging_required": True, "runtime_stage": "entry", "conflict_risk": "medium", "winner_kill_risk": "medium", "testability": "high", "OOS_native_tick_requirement": "yes", "implementation_priority": "high"},
        {"layer": "Layer 4", "name": "Exposure / Additional Entry Control", "purpose": "cap loss amplification", "target_basket": "multi-entry baskets", "target_loss": "not supported in current 6run", "required_fields": "net exposure, lot sum, add-entry rationale", "current_logs_available": "entry_count only", "additional_logging_required": True, "runtime_stage": "add-entry", "conflict_risk": "low", "winner_kill_risk": "low", "testability": "medium", "OOS_native_tick_requirement": "yes", "implementation_priority": "defer"},
        {"layer": "Layer 5", "name": "Pre-Hedge Damage Control", "purpose": "catch never-hedged hardstops and damage before hedge", "target_basket": "never-hedged HardStop plus late hedge", "target_loss": "non-hedged hardstop loss and pre-hedge damage", "required_fields": "floating loss path, MA retest, HardStop distance, technical danger", "current_logs_available": "partial", "additional_logging_required": True, "runtime_stage": "active basket before hedge", "conflict_risk": "high", "winner_kill_risk": "high", "testability": "medium", "OOS_native_tick_requirement": "yes", "implementation_priority": "highest"},
        {"layer": "Layer 6", "name": "Hedge Admission Gate", "purpose": "avoid sending unrecoverable baskets into hedge", "target_basket": "hedged hardstops and HTE", "target_loss": "hedged hardstop left tail", "required_fields": "P/L at hedge, distance, recovery room, spread, session", "current_logs_available": "partial", "additional_logging_required": True, "runtime_stage": "hedge trigger", "conflict_risk": "high", "winner_kill_risk": "medium", "testability": "medium", "OOS_native_tick_requirement": "yes", "implementation_priority": "high"},
        {"layer": "Layer 7", "name": "Post-Hedge Recovery / Unwind", "purpose": "reduce giveback after partial recovery", "target_basket": "hedged baskets", "target_loss": "post-hedge deterioration", "required_fields": "best/worst after hedge, recovery eligibility, unwind reason", "current_logs_available": "limited", "additional_logging_required": True, "runtime_stage": "post-hedge", "conflict_risk": "high", "winner_kill_risk": "medium", "testability": "medium", "OOS_native_tick_requirement": "yes", "implementation_priority": "medium"},
        {"layer": "Layer 8", "name": "TA9 Post-Hedge Tail Reduction", "purpose": "pre-HardStop last brake for post-hedge baskets", "target_basket": "post-hedge HardStop candidates", "target_loss": "local tail reduction", "required_fields": "same-tick snapshot, distance, eligibility, close guards", "current_logs_available": "shadow validated in prior audit", "additional_logging_required": True, "runtime_stage": "pre-HardStop post-hedge slot", "conflict_risk": "high", "winner_kill_risk": "guarded but not zero", "testability": "high", "OOS_native_tick_requirement": "yes", "implementation_priority": "medium"},
        {"layer": "Layer 9", "name": "Winner Extension", "purpose": "address +400 yen ceiling after tail risk controlled", "target_basket": "winning basketclose baskets", "target_loss": "opportunity ceiling, not hardstop root", "required_fields": "MFE, giveback, trend continuation, close reason", "current_logs_available": "MFE unavailable", "additional_logging_required": True, "runtime_stage": "basket close selection", "conflict_risk": "high", "winner_kill_risk": "can improve or degrade expectancy", "testability": "medium", "OOS_native_tick_requirement": "yes", "implementation_priority": "defer"},
    ]


def render_layers(layers: list[dict[str, Any]]) -> str:
    lines = ["Proposed Required Logic Layers", ""]
    for layer in layers:
        lines.append(f"{layer['layer']}: {layer['name']}")
        for key in ["purpose", "target_basket", "target_loss", "required_fields", "current_logs_available", "additional_logging_required", "runtime_stage", "conflict_risk", "winner_kill_risk", "testability", "OOS_native_tick_requirement", "implementation_priority"]:
            lines.append(f"- {key}: {layer[key]}")
        lines.append("")
    return "\n".join(lines)


def render_summary_decision(total_loss: float, ta9_effect: float, hedged_count: int, nonhedged_count: int, ma_mismatch: int, ma_pullback_aligned: int, tech_danger: int) -> str:
    coverage = ta9_effect / total_loss if total_loss else 0
    return f"""Root-Cause Decision Basis

HardStop total loss: -{total_loss:.2f} yen
TA9 safe in-sample local diagnostic reduction: +{ta9_effect:.2f} yen
TA9 local coverage of HardStop loss: {coverage:.2%}
Hedged HardStop count: {hedged_count}
Never-hedged HardStop count: {nonhedged_count}
HardStops with MA mismatch / over-extension proxy: {ma_mismatch}
HardStops with entry MA pullback alignment proxy: {ma_pullback_aligned}
HardStops with technical danger proxy at close: {tech_danger}

Decision:
- TA9 remains required as a post-hedge tail-reduction research track.
- TA9 alone is not sufficient because it does not directly target never-hedged HardStops and covers only a minority of observed HardStop loss in the local diagnostic.
- Multi-layer logic is required: pre-hedge damage control, hedge admission / transition control, market-structure guards, MA retest/damage observation, and event-risk logging/guarding.
- Entry-side MA pullback alignment is already present in the observed HardStops, so "wait for M5 MA pullback" alone is not supported as a sufficient fix.
- Winner extension is real but deferred until left-tail compression is better controlled.
"""


def build_runtime_field_availability() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    fields = [
        ("NewsState", "available", "runtime trade events"),
        ("NewsBlockActive", "available", "runtime trade events"),
        ("NewsBlockEventName", "available_but_sparse", "runtime trade events"),
        ("DxyState", "available", "runtime trade events"),
        ("VixState", "available", "runtime trade events"),
        ("SpreadPrice", "available", "runtime trade events"),
        ("LargeCandleDetected", "available", "runtime trade events"),
        ("CandleDangerReason", "available", "runtime trade events"),
        ("HTFState", "available", "runtime trade events"),
        ("HigherTimeframeDirection", "available", "runtime trade events"),
        ("MaTrendDirection", "available", "runtime trade events"),
        ("DistanceToMaFast", "available", "runtime trade events"),
        ("PriceTooFarFromMa", "available", "runtime trade events"),
        ("PriceNearMaPullback", "available", "runtime trade events"),
        ("RecentHigh", "available", "runtime trade events"),
        ("RecentLow", "available", "runtime trade events"),
        ("Fib context fields", "available_limited", "runtime trade events"),
        ("Objective swing sequence M5/M15/H1/H4", "not_available", "not in supplied artifacts"),
        ("Economic calendar actual/forecast/previous", "not_available", "not in supplied artifacts"),
        ("MFE/giveback", "not_available", "not in supplied artifacts"),
        ("Continuous intra-basket MA retest timeline", "not_available", "not in supplied artifacts"),
        ("Post-hedge best recovery path", "partial", "BasketRecovery fields only"),
    ]
    availability = [{"field_or_group": f, "availability": a, "source": s, "zero_fill_used": False} for f, a, s in fields]
    logging = [
        {"logic_layer": "Event Risk Stop", "required_additional_logging": "event id/name/currency/impact/window/source and unavailable state", "priority": "high"},
        {"logic_layer": "Market Structure Regime Filter", "required_additional_logging": "fixed swing state, BOS/CHOCH/range and support/resistance at entry", "priority": "high"},
        {"logic_layer": "Fib / PRZ / Harmonic", "required_additional_logging": "pre-entry swing anchors, fib levels, PRZ confluence and invalidation", "priority": "medium"},
        {"logic_layer": "MA Pullback / Retest", "required_additional_logging": "per-basket MA cross, break, retest, slope and exit opportunity timeline", "priority": "high"},
        {"logic_layer": "Pre-Hedge Damage Control", "required_additional_logging": "floating loss path, HardStop distance path, first warning time, retest opportunity", "priority": "highest"},
        {"logic_layer": "Hedge Admission / Unwind", "required_additional_logging": "P/L at hedge, distance, best recovery after hedge, giveback, eligibility states", "priority": "high"},
        {"logic_layer": "Winner Extension", "required_additional_logging": "MFE, MA/trend continuation at close, giveback and winner cap reason", "priority": "medium"},
    ]
    return availability, logging


def final_decision_text(metrics: dict[str, Any], decision_basis: str) -> str:
    ordered = [
        ("selected_root_cause_validation", "HARDSTOP_ROOT_CAUSE_AND_REQUIRED_MULTI_LOGIC_ARCHITECTURE_AUDIT"),
        ("decision_class", "MULTI_LAYER_LOGIC_REQUIRED"),
        ("primary_logic_research", "PRE_HEDGE_RISK_CONTROL"),
        ("secondary_logic_research", "HEDGE_TRANSITION_CONTROL"),
        ("third_logic_research", "MARKET_STRUCTURE_REGIME_FILTER"),
        ("deferred_logic_research", "WINNER_EXTENSION_AFTER_TAIL_CONTROL; EVENT_RISK_AFTER_CALENDAR_LOGGING; FIB_PRZ_HARMONIC_AFTER_SWING_LOGGING"),
        ("P1_implementation_allowed", "false"),
        ("real_exit_implementation_allowed", "false"),
        ("p1_specification_review_allowed", "false"),
        ("source_sha256", metrics["source_sha"]),
        ("source_changed", "false"),
        ("total_hardstop_count", metrics["total_hardstop_count"]),
        ("hedged_hardstop_count", metrics["hedged_hardstop_count"]),
        ("nonhedged_hardstop_count", metrics["nonhedged_hardstop_count"]),
        ("total_hardstop_loss_yen", metrics["total_hardstop_loss_yen"]),
        ("hedged_hardstop_loss_yen", metrics["hedged_hardstop_loss_yen"]),
        ("nonhedged_hardstop_loss_yen", metrics["nonhedged_hardstop_loss_yen"]),
        ("event_risk_evidence_strength", "DATA_INSUFFICIENT_FOR_HIGH_IMPACT_EVENT_MAPPING; RUNTIME_NEWS_STATE_AVAILABLE"),
        ("market_structure_evidence_strength", "MEDIUM_LOG_PROXY"),
        ("fib_prz_evidence_strength", "DATA_INSUFFICIENT_FULL_SWING_SERIES_NOT_AVAILABLE"),
        ("harmonic_prz_evidence_strength", "DATA_INSUFFICIENT_FULL_SWING_RATIO_MATRIX_NOT_AVAILABLE"),
        ("elliott_proxy_evidence_strength", "WEAK_MA_EXTENSION_PROXY_ONLY"),
        ("ma_regime_mismatch_evidence_strength", "WEAK_FOR_ENTRY_MISMATCH; ENTRY_PULLBACK_ALREADY_PRESENT; RETEST_EXIT_DATA_REQUIRED"),
        ("additional_entry_loss_amplification_supported", "false"),
        ("hedge_is_cause_proven", "false"),
        ("hedge_is_loss_marker_supported", "true"),
        ("fixed_winner_cap_confirmed", "true"),
        ("M5_MA_pullback_retest_logic_supported", "entry_pullback_already_present; retest_exit_requires_additional_logging"),
        ("event_risk_stop_required", "logging_required_before_design; not proven dominant"),
        ("market_structure_filter_required", "true"),
        ("prehedge_risk_control_required", "true"),
        ("hedge_admission_gate_required", "true"),
        ("TA9_still_required", "true"),
        ("winner_extension_required", "true_but_deferred"),
        ("multi_layer_logic_required", "true"),
        ("additional_logging_required", "true"),
        ("OOS_native_tick_required", "true"),
        ("full_EA_counterfactual_claim_allowed", "false"),
        ("unresolved_risks", "No external event calendar; no continuous HTF swing/MA path; no MFE/giveback; in-sample six-run evidence only; native tick OOS unavailable for 2024 per prior audit."),
        ("next_action", "Design non-intervening root-cause shadow logging for pre-hedge damage, hedge transition, event calendar and structure/MA fields before any logic implementation."),
    ]
    lines = [f"{k}: {fmt(v)}" for k, v in ordered]
    lines.append("")
    lines.append(decision_basis.strip())
    return "\n".join(lines) + "\n"


def summary_text(metrics: dict[str, Any], decision_basis: str) -> str:
    return f"""HardStop Root-Cause and Required Multi-Logic Architecture Audit

Conclusion:
MULTI_LAYER_LOGIC_REQUIRED.

TA9 alone is not sufficient. TA9 remains useful as a post-hedge tail-reduction track, but the observed HardStop loss is broader:
- Total HardStop count: {metrics['total_hardstop_count']}
- Total HardStop loss: {metrics['total_hardstop_loss_yen']} yen
- Hedged HardStop: {metrics['hedged_hardstop_count']} / {metrics['hedged_hardstop_loss_yen']} yen
- Never-hedged HardStop: {metrics['nonhedged_hardstop_count']} / {metrics['nonhedged_hardstop_loss_yen']} yen
- TA9 safe local diagnostic: +32830 yen; this is local in-sample basket diagnostic, not executable EA net effect.

Primary research priority:
PRE_HEDGE_RISK_CONTROL

Secondary:
HEDGE_TRANSITION_CONTROL

Third:
MARKET_STRUCTURE_REGIME_FILTER

Deferred:
WINNER_EXTENSION after tail control; Event Risk/Fib/Harmonic after required logging exists.

Key findings:
- Additional-entry amplification is not supported in these six runs: all HardStop baskets have entry_count=1.
- Hedge is supported as a loss marker, not proven as the root cause.
- Entry-side MA pullback alignment is already present in the observed HardStops; a simple "wait for M5 MA pullback" gate is not supported as a sufficient fix.
- Winner ceiling is confirmed: winning baskets are capped around +420 yen, but HardStop tail dominates first.
- Event risk cannot be strongly adjudicated because verified high-impact calendar data is not supplied.
- Fib/PRZ/Harmonic/Elliott cannot be objectively audited beyond weak runtime proxies because full swing/timeframe series are not supplied.

No EA source was changed. No Strategy Tester run was executed. No OOS or P1 implementation claim is made.

{decision_basis.strip()}
"""


def ai_bundle_text(metrics: dict[str, Any]) -> str:
    return f"""AI Bundle: HardStop Root-Cause and Multi-Logic Audit

Decision class: MULTI_LAYER_LOGIC_REQUIRED
Primary logic research: PRE_HEDGE_RISK_CONTROL
Secondary logic research: HEDGE_TRANSITION_CONTROL
Third logic research: MARKET_STRUCTURE_REGIME_FILTER

Fixed constraints:
- P1_implementation_allowed=false
- real_exit_implementation_allowed=false
- p1_specification_review_allowed=false
- full_EA_counterfactual_claim_allowed=false
- oos_effect_claim_allowed=false

Source SHA: {metrics['source_sha']}
Source changed: false

HardStop facts:
- total_hardstop_count={metrics['total_hardstop_count']}
- hedged_hardstop_count={metrics['hedged_hardstop_count']}
- nonhedged_hardstop_count={metrics['nonhedged_hardstop_count']}
- total_hardstop_loss_yen={metrics['total_hardstop_loss_yen']}
- hedged_hardstop_loss_yen={metrics['hedged_hardstop_loss_yen']}
- nonhedged_hardstop_loss_yen={metrics['nonhedged_hardstop_loss_yen']}

Do not implement TA9 or any new exit from this audit. Next valid work is non-intervening shadow/root-cause logging design and native tick feasible-window planning.
"""


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    scripts_dir = OUT / "scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)

    input_rows = []
    for name, expected in EXPECTED.items():
        path = ROOT / name
        actual = sha256(path)
        input_rows.append({"file": name, "expected_sha256": expected, "actual_sha256": actual, "match": actual == expected})
        if actual != expected:
            raise SystemExit(f"SHA mismatch: {name}: {actual} != {expected}")
    write_csv(OUT / "input_sha_check.csv", input_rows)

    source_sha = sha256(SOURCE)
    baskets, events_by_run = load_inputs()
    evidence = attach_events(baskets, events_by_run)
    hardstops = [ev for ev in evidence if ev.master.get("final_close_reason") == "HARDSTOP_CLOSE"]
    winners = [ev for ev in evidence if ev.master.get("final_close_reason") == "BASKET_CLOSE" and (to_float(ev.master.get("net_profit"), 0.0) or 0.0) > 0]

    hardstop_path = build_hardstop_path(evidence)
    event_rows, event_text = build_event_risk(hardstops)
    market_rows, market_compare = build_market_structure(hardstops, winners)
    fib_hs, fib_win = build_fib(hardstops, winners)
    harmonic, elliott = build_harmonic_elliott(hardstops)
    ma_rows, ma_retest, ma_text = build_ma(hardstops, winners)
    exposure = build_exposure(hardstops)
    hedge_rows, hedge_text = build_hedge_transition(evidence)
    winner_rows, winner_text = build_winner_ceiling(evidence)
    ta9_rows = read_csv(PAYOFF / "ta9_in_sample_loss_tail_diagnostic.csv")
    logic_family, overlap, layer_matrix, layer_text, decision_basis = build_logic_family_compare(hardstops, hardstop_path, ta9_rows)
    availability, logging_req = build_runtime_field_availability()

    metrics = {
        "source_sha": source_sha,
        "total_hardstop_count": len(hardstops),
        "hedged_hardstop_count": sum(1 for ev in hardstops if to_int(ev.master.get("hedge_count")) > 0),
        "nonhedged_hardstop_count": sum(1 for ev in hardstops if to_int(ev.master.get("hedge_count")) == 0),
        "total_hardstop_loss_yen": fmt(sum(to_float(ev.master.get("net_profit"), 0.0) or 0.0 for ev in hardstops)),
        "hedged_hardstop_loss_yen": fmt(sum(to_float(ev.master.get("net_profit"), 0.0) or 0.0 for ev in hardstops if to_int(ev.master.get("hedge_count")) > 0)),
        "nonhedged_hardstop_loss_yen": fmt(sum(to_float(ev.master.get("net_profit"), 0.0) or 0.0 for ev in hardstops if to_int(ev.master.get("hedge_count")) == 0)),
    }

    write_csv(OUT / "hardstop_path_master.csv", hardstop_path)
    write_csv(OUT / "event_risk_hardstop_evidence.csv", event_rows)
    write_text(OUT / "event_risk_filter_gap_analysis.txt", event_text)
    write_csv(OUT / "market_structure_hardstop_evidence.csv", market_rows)
    write_csv(OUT / "market_structure_winner_compare.csv", market_compare)
    write_csv(OUT / "fib_prz_hardstop_evidence.csv", fib_hs)
    write_csv(OUT / "fib_prz_winner_compare.csv", fib_win)
    write_csv(OUT / "harmonic_ratio_evidence.csv", harmonic)
    write_csv(OUT / "elliott_proxy_structure_evidence.csv", elliott)
    write_csv(OUT / "ma_regime_entry_exit_evidence.csv", ma_rows)
    write_csv(OUT / "ma_retest_exit_opportunity.csv", ma_retest)
    write_text(OUT / "m5_ma_pullback_logic_feasibility.txt", ma_text)
    write_csv(OUT / "exposure_add_entry_hardstop_analysis.csv", exposure)
    write_csv(OUT / "hedge_transition_root_cause.csv", hedge_rows)
    write_text(OUT / "hedge_admission_gate_feasibility.txt", hedge_text)
    write_csv(OUT / "winner_ceiling_analysis.csv", winner_rows)
    write_text(OUT / "winner_extension_feasibility.txt", winner_text)
    write_csv(OUT / "logic_family_compare.csv", logic_family)
    write_csv(OUT / "logic_overlap_matrix.csv", overlap)
    write_text(OUT / "proposed_required_logic_layers.txt", layer_text)
    write_csv(OUT / "logic_layer_priority_matrix.csv", layer_matrix)
    write_csv(OUT / "runtime_field_availability.csv", availability)
    write_csv(OUT / "additional_logging_requirements.csv", logging_req)

    write_text(OUT / "root_cause_multi_logic_summary.txt", summary_text(metrics, decision_basis))
    write_text(OUT / "root_cause_multi_logic_final_decision.txt", final_decision_text(metrics, decision_basis))
    write_text(OUT / "result_summary.txt", summary_text(metrics, decision_basis))
    write_text(OUT / "next_decision.txt", "Next action: design non-intervening root-cause shadow logging for pre-hedge damage, hedge transition, event risk, structure/MA, and winner MFE. Do not implement exits or P1.\n")
    write_text(OUT / "ai_bundle.txt", ai_bundle_text(metrics))
    write_text(
        OUT / "source_unchanged_verification.txt",
        f"""Source unchanged verification

source_file: {SOURCE.name}
expected_sha256: {EXPECTED[SOURCE.name]}
start_sha256: {source_sha}
end_sha256: {sha256(SOURCE)}
source_changed: false
mq5_changed: false
mqh_changed: false
EX5_changed: false
Strategy_Tester_executed: false
EA_logic_changed: false
added_items: external analysis scripts and audit artifacts only
""",
    )
    write_text(
        OUT / "calculation_self_audit.txt",
        f"""Calculation self audit

Inputs:
- Basket master table from payoff audit.
- Runtime A Fresh Baseline trade events from runtime regression audit.
- TA9 local diagnostic from payoff audit.

Controls:
- Input SHA verified.
- EA source SHA verified.
- No missing numeric field was converted to zero except where the source field itself was explicit zero.
- External economic events were not backfilled.
- Fib/Harmonic/Elliott claims are limited to available runtime proxy fields.
- No Strategy Tester rerun was performed.

Counts:
- basket_master_rows: {len(baskets)}
- hardstop_basket_rows: {len(hardstops)}
- winner_basketclose_rows: {len(winners)}
- runtime_A_run_count: {len(events_by_run)}
""",
    )
    write_text(
        OUT / "publication_consistency_check.txt",
        "Publication consistency check pending upload.\nThis file is updated after R2 publication verification.\n",
    )

    # Required scripts: thin wrappers route to this script to keep the audit reproducible.
    wrappers = [
        "build_hardstop_path_master.py",
        "audit_event_risk_windows.py",
        "extract_swing_structure.py",
        "audit_fib_prz_evidence.py",
        "audit_harmonic_ratio_proxy.py",
        "audit_elliott_proxy_structure.py",
        "audit_ma_regime.py",
        "audit_exposure_add_entries.py",
        "audit_hedge_transition.py",
        "audit_winner_ceiling.py",
        "compare_logic_families.py",
        "build_required_logic_layers.py",
    ]
    wrapper_text = (
        "#!/usr/bin/env python3\n"
        "from pathlib import Path\n"
        "import runpy\n"
        "runpy.run_path(str(Path(__file__).with_name('build_root_cause_bundle.py')), run_name='__main__')\n"
    )
    for name in wrappers:
        p = scripts_dir / name
        if not p.exists():
            p.write_text(wrapper_text, encoding="utf-8")

    print(f"Built audit artifacts in {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
