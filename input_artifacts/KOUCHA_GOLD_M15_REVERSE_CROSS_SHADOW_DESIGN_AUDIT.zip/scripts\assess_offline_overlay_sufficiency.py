from build_ma_shadow_design_bundle import main

if __name__ == '__main__':
    main()
