from __future__ import annotations

import csv
import hashlib
import json
import shutil
import textwrap
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path


ROOT = Path(r"C:\Users\user\Documents\New project")
OUT = ROOT / "KOUCHA_GOLD_M15_REVERSE_CROSS_SHADOW_DESIGN_AUDIT"
SCRIPTS = OUT / "scripts"
INPUT_AUDITS = OUT / "input_audits"
EVIDENCE = OUT / "evidence"
PUBLICATION = OUT / "publication"

OVERLAY = ROOT / "KOUCHA_GOLD_PHASE1_RUNTIME_MA_CROSS_OVERLAY_AUDIT"
PHASE1_FIX = ROOT / "KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT"
MA = ROOT / "KOUCHA_GOLD_MA_CROSS_10EMA20SMA_AUDIT"
MA_ZIP = ROOT / "KOUCHA_GOLD_MA_CROSS_10EMA20SMA_AUDIT.zip"
EVENT_ZIP = ROOT / "KOUCHA_GOLD_EVENT_BLACKOUT_WINDOW_AUDIT.zip"
OVERLAY_ZIP = ROOT / "KOUCHA_GOLD_PHASE1_RUNTIME_MA_CROSS_OVERLAY_AUDIT.zip"
PHASE1_FIX_ZIP = ROOT / "KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT.zip"

TERMINAL_SOURCE = Path(
    r"C:\Users\user\AppData\Roaming\MetaQuotes\Terminal\2FA8A7E69CED7DC259B1AD86A247F675\MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5"
)
TERMINAL_EX5 = TERMINAL_SOURCE.with_suffix(".ex5")

EXPECTED = {
    "overlay_zip": "A249E9EBDF68ABE35231B26C4D4B317AFA55BED7AE4074B284EA51ABD50D2D58",
    "phase1_fix_zip": "ADFE914A9673B8D6558A1C502BE5398E5F208222E8D28D7D0467E4E7443433AC",
    "ma_cross_zip": "FE05EACB3F03D4551C0F6638ACE97BAA7AD68316B0DA1C77157999B6DEA8BAEE",
    "event_blackout_zip": "885C05A57AC6D4E2F4E61AAD26AA8BDE5FDE08561DB0B4AFC06BDCDC294A3B74",
    "source": "E57BE0039E54FA605ADAFE582B4B273381059166C9964000FFBFC033DE40F03A",
    "ex5": "49B3140292F614723D37FB8B8AF3DABAA83AD4A61C15FD328E9A201D7C9A6CDB",
}


def ensure_dirs() -> None:
    for path in (OUT, SCRIPTS, INPUT_AUDITS, EVIDENCE, PUBLICATION):
        path.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str] | None = None) -> None:
    if fieldnames is None:
        keys: list[str] = []
        for row in rows:
            for key in row:
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_text(path: Path, text: str) -> None:
    path.write_text(textwrap.dedent(text).strip() + "\n", encoding="utf-8")


def download(url: str, dest: Path) -> tuple[str, int, str]:
    try:
        req = urllib.request.Request(url, headers={"Cache-Control": "no-cache", "User-Agent": "koucha-design-audit"})
        with urllib.request.urlopen(req, timeout=60) as res:
            data = res.read()
            status = str(res.status)
        dest.write_bytes(data)
        digest = hashlib.sha256(data).hexdigest().upper() if dest.suffix.lower() == ".zip" else ""
        return status, len(data), digest
    except Exception as exc:  # publication preflight must record, not fake success
        dest.write_text(f"ERROR: {exc}\n", encoding="utf-8")
        return "ERROR", 0, ""


def audit_inputs() -> list[dict[str, object]]:
    items = [
        ("overlay_local_zip", OVERLAY_ZIP, EXPECTED["overlay_zip"]),
        ("phase1_fix_local_zip", PHASE1_FIX_ZIP, EXPECTED["phase1_fix_zip"]),
        ("ma_cross_local_zip", MA_ZIP, EXPECTED["ma_cross_zip"]),
        ("event_blackout_local_zip", EVENT_ZIP, EXPECTED["event_blackout_zip"]),
        ("terminal_source", TERMINAL_SOURCE, EXPECTED["source"]),
        ("terminal_ex5", TERMINAL_EX5, EXPECTED["ex5"]),
    ]
    rows: list[dict[str, object]] = []
    for name, path, expected in items:
        exists = path.exists()
        digest = sha256(path) if exists else ""
        rows.append(
            {
                "name": name,
                "path": str(path),
                "exists": exists,
                "bytes": path.stat().st_size if exists else "NA",
                "sha256": digest,
                "expected_sha256": expected,
                "sha_match": digest == expected,
            }
        )
    write_csv(INPUT_AUDITS / "design_input_manifest.csv", rows)
    return rows


def publication_preflight() -> list[dict[str, object]]:
    urls = [
        ("overlay_named_cache_busted", "https://zip.koucha-lab.com/KOUCHA_GOLD_PHASE1_RUNTIME_MA_CROSS_OVERLAY_AUDIT.zip?cache_buster=20260621205742", "zip", EXPECTED["overlay_zip"]),
        ("overlay_archive", "https://zip.koucha-lab.com/archive/KOUCHA_GOLD_PHASE1_RUNTIME_MA_CROSS_OVERLAY_AUDIT_LOCKED_20260621205506.zip", "zip", EXPECTED["overlay_zip"]),
        ("current_bare", "https://zip.koucha-lab.com/current/", "text", ""),
        ("current_index", "https://zip.koucha-lab.com/current/index.html?cache_buster=ma_design_preflight", "text", ""),
        ("current_final_decision", "https://zip.koucha-lab.com/current/ma_runtime_overlay_final_decision.txt?cache_buster=ma_design_preflight", "text", ""),
        ("current_result_summary", "https://zip.koucha-lab.com/current/result_summary.txt?cache_buster=ma_design_preflight", "text", ""),
        ("current_next_decision", "https://zip.koucha-lab.com/current/next_decision.txt?cache_buster=ma_design_preflight", "text", ""),
        ("current_ai_bundle", "https://zip.koucha-lab.com/current/ai_bundle.txt?cache_buster=ma_design_preflight", "text", ""),
        ("current_publication_consistency", "https://zip.koucha-lab.com/current/publication_consistency_check.txt?cache_buster=ma_design_preflight", "text", ""),
    ]
    rows: list[dict[str, object]] = []
    for idx, (label, url, kind, expected) in enumerate(urls, start=1):
        suffix = ".zip" if kind == "zip" else ".txt"
        dest = INPUT_AUDITS / f"preflight_{idx:02d}_{label}{suffix}"
        status, size, digest = download(url, dest)
        content = dest.read_text(encoding="utf-8", errors="ignore") if kind == "text" and dest.exists() else ""
        rows.append(
            {
                "label": label,
                "url": url,
                "status": status,
                "bytes": size,
                "sha256": digest,
                "expected_sha256": expected,
                "sha_match": (digest == expected) if expected else "NA",
                "contains_overlay_decision": "MA_M15_REVERSE_CROSS_OBSERVATION_READY" in content or kind == "zip",
                "source_of_truth_allowed": label in {"overlay_named_cache_busted", "overlay_archive"},
            }
        )
    write_csv(OUT / "ma_shadow_design_publication_preflight.csv", rows)
    lines = ["MA Shadow Design Publication Preflight", f"generated_at: {datetime.now().isoformat(timespec='seconds')}"]
    for row in rows:
        lines.append(
            f"{row['label']}: status={row['status']} bytes={row['bytes']} sha_match={row['sha_match']} contains_overlay_decision={row['contains_overlay_decision']}"
        )
    lines.append("input_source_of_truth: overlay cache-busted named ZIP and archive ZIP only; bare named/latest/current not used as authoritative input")
    write_text(OUT / "ma_shadow_design_publication_preflight.txt", "\n".join(lines))
    return rows


def extract_ma_script() -> Path:
    dest = EVIDENCE / "ma_cross_run_ma_cross_audit.py"
    with zipfile.ZipFile(MA_ZIP, "r") as zf:
        with zf.open("scripts/run_ma_cross_audit.py") as src, dest.open("wb") as out:
            shutil.copyfileobj(src, out)
    return dest


def count_phase1_runtime() -> dict[str, int]:
    counts = {"root_snapshots": 0, "basket_summaries": 0, "run_summaries": 0, "shadow_csv_files": 0}
    for path in sorted((PHASE1_FIX / "shadow_logs").glob("*.csv")):
        counts["shadow_csv_files"] += 1
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                event_type = row.get("event_type", "")
                if event_type == "MULTILAYER_ROOT_SNAPSHOT":
                    counts["root_snapshots"] += 1
                elif event_type == "MULTILAYER_BASKET_SUMMARY":
                    counts["basket_summaries"] += 1
                elif event_type == "MULTILAYER_RUN_SUMMARY":
                    counts["run_summaries"] += 1
    return counts


def get_overlay_fields() -> dict[str, str]:
    fields: dict[str, str] = {}
    with (OVERLAY / "ma_runtime_overlay_final_decision.txt").open("r", encoding="utf-8") as f:
        for line in f:
            if ":" in line:
                key, value = line.split(":", 1)
                fields[key.strip()] = value.strip()
    return fields


def make_definition_outputs() -> None:
    rows = [
        {"field": "symbol", "value": "GOLD", "source": "MA Cross script SYMBOL constant"},
        {"field": "fast_ma_type", "value": "EMA", "source": "pandas close.ewm(span=10, adjust=False).mean()"},
        {"field": "fast_ma_period", "value": "10", "source": "MA Cross script add_indicators"},
        {"field": "slow_ma_type", "value": "SMA", "source": "pandas close.rolling(20, min_periods=20).mean()"},
        {"field": "slow_ma_period", "value": "20", "source": "MA Cross script add_indicators"},
        {"field": "applied_price", "value": "close", "source": "MA Cross script uses close column"},
        {"field": "shift", "value": "0 on closed source bar; signal usable after bar close", "source": "Overlay closed-bar contract"},
        {"field": "timeframes", "value": "M5,M15,M30", "source": "MA Cross script tf_map"},
        {"field": "warm_up_bars", "value": "slow SMA requires 20 bars; ATR requires 14 for atr column", "source": "rolling min_periods"},
        {"field": "missing_bar_handling", "value": "no interpolation; missing bars remain unavailable", "source": "design lock"},
        {"field": "equal_value_handling", "value": "NEUTRAL state when ema10 == sma20; cross allows prior equality only", "source": "MA Cross formula"},
        {"field": "floating_point_comparison", "value": "strict > and <, prior <=/>= for cross; no epsilon", "source": "MA Cross script"},
        {"field": "timestamp_basis", "value": "broker/server-label bar datetime from MT5 rates; UTC historical offset not reinterpreted", "source": "MA Cross + Overlay artifacts"},
        {"field": "bar_open_time", "value": "CSV datetime", "source": "MA Cross rates"},
        {"field": "bar_close_time", "value": "bar_open_time + timeframe minutes", "source": "Overlay time alignment"},
        {"field": "signal_available_time", "value": "source_bar_close_time; first runtime snapshot at/after this time", "source": "Overlay time alignment"},
        {"field": "weekend_session_handling", "value": "only available broker bars; no synthetic session filling", "source": "design lock"},
    ]
    write_csv(OUT / "ma_exact_definition_lock.csv", rows, ["field", "value", "source"])
    write_text(
        OUT / "ma_exact_definition_lock.txt",
        """
        MA Exact Definition Lock

        Fast MA is EMA 10 on close, implemented in the MA Cross Audit script as
        close.ewm(span=10, adjust=False).mean().

        Slow MA is SMA 20 on close, implemented as
        close.rolling(20, min_periods=20).mean().

        Timeframes are M5, M15 and M30. The source timestamp is the MT5 rates bar
        datetime. For runtime usage, a signal is not available until the source
        bar is closed. No epsilon, asymmetric BUY/SELL thresholds, alternate MA
        periods, alternate applied price, or optimized condition is allowed.
        """,
    )
    write_text(
        OUT / "ma_cross_formula_self_audit.txt",
        """
        Cross Formula Self Audit

        MA Cross Audit source uses ema_sma_gap = ema10 - sma20.

        BULL_CROSS:
          previous confirmed bar ema_sma_gap <= 0
          current confirmed bar ema_sma_gap > 0

        BEAR_CROSS:
          previous confirmed bar ema_sma_gap >= 0
          current confirmed bar ema_sma_gap < 0

        State:
          BULL when ema10 > sma20
          BEAR when ema10 < sma20
          NEUTRAL when equal

        This matches the requested formula. No epsilon is used.
        """,
    )


def make_signal_contracts() -> None:
    write_text(
        OUT / "ma_signal_availability_contract.txt",
        """
        Signal Availability Contract

        M5 signal is usable only from the first Phase 1 root snapshot whose
        server_time_msc is at or after M5 source_bar_close_time.

        M15 signal is usable only from the first Phase 1 root snapshot whose
        server_time_msc is at or after M15 source_bar_close_time.

        M30 regime is usable only from the first Phase 1 root snapshot whose
        server_time_msc is at or after M30 source_bar_close_time.

        Required fields:
        source_timeframe, source_bar_open_time, source_bar_close_time,
        signal_computed_time, signal_available_time,
        first_runtime_snapshot_after_signal, first_eligible_root_snapshot_id,
        first_eligible_server_time_msc, alignment_delay_milliseconds,
        alignment_status.

        Prohibited:
        forming bar signal, retroactive assignment to a pre-close snapshot,
        timestamp rounding that moves a signal earlier, HardStop-nearest
        snapshot selection, UTC/server-label mixing without verification.

        Millisecond alignment is required because the minimum observed
        signal-to-HardStop lead time is about 25 seconds.
        """,
    )
    write_text(
        OUT / "ma_first_signal_contract.txt",
        """
        First-Signal Contract

        Primary signal family:
          FIRST_M15_REVERSE_CROSS

        Context fields attached to the primary signal:
          M30_ADVERSE_REGIME_AT_FIRST_M15_CROSS
          M5_REVERSE_FOLLOWTHROUGH_PROXY_AFTER_FIRST_M15_CROSS
          EVENT_WINDOW_AT_FIRST_M15_CROSS
          PREHEDGE_STATE_AT_FIRST_M15_CROSS

        For each basket and signal family, only the first runtime-eligible signal
        is primary. Later recrosses are diagnostic only and may not replace the
        primary signal. Multiple signal hits cannot be counted as multiple
        Basket effects.

        Stored at first signal:
        root_snapshot_id, lifecycle, hedge state, current Basket P/L, distance
        to HardStop, HardStopNow, HTE/Recovery/BasketClose eligibility,
        ClosePriority state, pending close state, Event Window, MA separation,
        bars since cross.
        """,
    )


def make_direction_mapping() -> None:
    rows = [
        {"basket_direction": "BUY", "adverse_m15_reverse_cross": "BEAR_CROSS", "adverse_m30_regime": "BEAR_REGIME", "source_of_truth": "original Basket direction from overlay canonical basket"},
        {"basket_direction": "SELL", "adverse_m15_reverse_cross": "BULL_CROSS", "adverse_m30_regime": "BULL_REGIME", "source_of_truth": "original Basket direction from overlay canonical basket"},
        {"basket_direction": "DIRECTION_UNKNOWN", "adverse_m15_reverse_cross": "UNKNOWN", "adverse_m30_regime": "UNKNOWN", "source_of_truth": "do not treat unknown as false"},
    ]
    write_csv(OUT / "ma_direction_mapping.csv", rows)


def make_state_machine() -> None:
    rows = [
        ("MA_STATE_UNKNOWN", "MA data unavailable or direction unknown", "valid MA state observed", "NA", "yes", "no", "diagnostic", "no"),
        ("MA_ALIGNED", "MA state supports original Basket direction", "adverse reverse cross confirmed", "bar close", "yes", "no", "context", "no"),
        ("M5_REVERSE_WARNING", "first adverse M5 closed-bar cross", "recross or basket close", "M5 bar close", "yes", "no", "diagnostic", "no"),
        ("M15_REVERSE_CONFIRMED", "first adverse M15 closed-bar cross", "recross or basket close", "M15 bar close", "yes", "no", "primary", "no"),
        ("M15_REVERSE_WITH_M30_ADVERSE", "M15 reverse plus M30 adverse regime at eligible snapshot", "recross or basket close", "M15/M30 closed bars", "yes", "no", "context", "no"),
        ("M15_REVERSE_WITH_M5_RETEST_PROXY", "M15 reverse followed by fixed M5 reverse/follow-through proxy", "recross or basket close", "closed bars", "yes", "no", "context", "no"),
        ("RECROSS_TO_ORIGINAL_DIRECTION", "later cross returns to original Basket direction", "basket close", "bar close", "yes", "no", "diagnostic", "no"),
        ("SIGNAL_PERSISTED_1_BAR", "M15 adverse state persists one closed M15 bar", "state fails or basket close", "closed bars", "yes", "no", "diagnostic", "no"),
        ("SIGNAL_PERSISTED_2_BARS", "M15 adverse state persists two closed M15 bars", "state fails or basket close", "closed bars", "yes", "no", "diagnostic", "no"),
        ("SIGNAL_PERSISTED_3_BARS", "M15 adverse state persists three closed M15 bars", "state fails or basket close", "closed bars", "yes", "no", "diagnostic", "no"),
        ("BASKET_CLOSED", "Basket summary/final close observed", "terminal state", "runtime close", "NA", "no", "terminal", "no"),
        ("SIGNAL_CENSORED", "Basket unresolved or join incomplete", "terminal state", "NA", "NA", "no", "diagnostic", "no"),
    ]
    out_rows = [
        {
            "state": s,
            "entry_condition": e,
            "exit_condition": x,
            "timestamp_basis": t,
            "bar_close_required": b,
            "future_information_used": f,
            "role": r,
            "runtime_implementation_required": impl,
        }
        for s, e, x, t, b, f, r, impl in rows
    ]
    write_csv(OUT / "ma_signal_state_machine.csv", out_rows)
    write_text(
        OUT / "ma_signal_state_machine.txt",
        "\n".join(f"{r['state']}: {r['entry_condition']} -> {r['exit_condition']} ({r['role']})" for r in out_rows),
    )
    write_text(
        OUT / "ma_signal_state_machine.mmd",
        """
        stateDiagram-v2
          [*] --> MA_STATE_UNKNOWN
          MA_STATE_UNKNOWN --> MA_ALIGNED: MA available
          MA_ALIGNED --> M5_REVERSE_WARNING: adverse M5 closed cross
          MA_ALIGNED --> M15_REVERSE_CONFIRMED: adverse M15 closed cross
          M15_REVERSE_CONFIRMED --> M15_REVERSE_WITH_M30_ADVERSE: M30 adverse context
          M15_REVERSE_CONFIRMED --> M15_REVERSE_WITH_M5_RETEST_PROXY: M5 proxy context
          M15_REVERSE_CONFIRMED --> RECROSS_TO_ORIGINAL_DIRECTION: recross
          M15_REVERSE_CONFIRMED --> SIGNAL_PERSISTED_1_BAR
          SIGNAL_PERSISTED_1_BAR --> SIGNAL_PERSISTED_2_BARS
          SIGNAL_PERSISTED_2_BARS --> SIGNAL_PERSISTED_3_BARS
          M5_REVERSE_WARNING --> RECROSS_TO_ORIGINAL_DIRECTION
          RECROSS_TO_ORIGINAL_DIRECTION --> BASKET_CLOSED
          SIGNAL_PERSISTED_3_BARS --> BASKET_CLOSED
          MA_STATE_UNKNOWN --> SIGNAL_CENSORED
          BASKET_CLOSED --> [*]
          SIGNAL_CENSORED --> [*]
        """,
    )


def make_close_protection() -> None:
    write_text(
        OUT / "ma_existing_close_protection_contract.txt",
        """
        Existing Close Protection Contract

        Future executable classification is allowed only when all are known:
          M15 reverse cross confirmed on a closed bar
          HardStopNow = FALSE
          ClosePriorityOK = TRUE
          ClosePriorityBlocked = FALSE
          pending close = FALSE
          market state valid
          HTE eligibility = FALSE and known
          RecoveryClose eligibility = FALSE and known
          BasketClose eligibility = FALSE and known

        TRUE / FALSE / UNKNOWN must be preserved. UNKNOWN is not false.

        This is a Shadow classification contract only. It is not an Exit
        implementation contract.
        """,
    )
    rows = [
        {"field": "HardStopNow", "required_for_future_candidate": "FALSE_KNOWN"},
        {"field": "HTE eligibility", "required_for_future_candidate": "FALSE_KNOWN"},
        {"field": "RecoveryClose eligibility", "required_for_future_candidate": "FALSE_KNOWN"},
        {"field": "BasketClose eligibility", "required_for_future_candidate": "FALSE_KNOWN"},
        {"field": "ClosePriorityOK", "required_for_future_candidate": "TRUE_KNOWN"},
        {"field": "ClosePriorityBlocked", "required_for_future_candidate": "FALSE_KNOWN"},
        {"field": "pending close", "required_for_future_candidate": "FALSE_KNOWN"},
        {"field": "market state", "required_for_future_candidate": "VALID_KNOWN"},
    ]
    write_csv(OUT / "ma_future_candidate_decision_table.csv", rows)


def make_hte_trace() -> dict[str, str]:
    hte_rows = [
        r
        for r in read_csv(OVERLAY / "ma_first_signal_by_basket.csv")
        if r.get("candidate_name") == "M15_REVERSE_CROSS" and r.get("kill_harm_class") == "HTE_KILL"
    ]
    row = hte_rows[0] if hte_rows else {}
    trace = {
        "basket_uid": row.get("basket_uid", "NA"),
        "canonical_basket_key": row.get("canonical_basket_key", "NA"),
        "run": row.get("run_label", "NA"),
        "period": row.get("period", "NA"),
        "capital": row.get("capital", "NA"),
        "basket_direction": row.get("basket_direction", "NA"),
        "basket_start": row.get("basket_start_time", "NA"),
        "hedge_start": row.get("first_hedge_time", "NA"),
        "M15_source_bar": row.get("source_bar_open_time", "NA"),
        "M15_cross_available_time": row.get("signal_available_time", "NA"),
        "first_root_snapshot": row.get("first_signal_root_snapshot_id", "NA"),
        "pl_at_signal": row.get("current_pl_at_signal_yen", "NA"),
        "distance_to_hardstop": row.get("distance_to_hardstop_at_signal_yen", "NA"),
        "HTE_eligibility_at_signal": row.get("HTE_eligibility_at_signal", "NA"),
        "HTE_actual_eligibility_time": "NOT_LOGGED",
        "actual_HTE_close_time": row.get("basket_end_time", "NA"),
        "actual_HTE_PL": row.get("actual_final_pl_yen", "NA"),
        "one_step_candidate_PL": row.get("current_pl_at_signal_yen", "NA"),
        "difference": row.get("one_step_effect_ex_commission_yen", "NA"),
        "lead_time": "signal at 2026-04-21 12:45:00; close at 2026-04-21 14:43:30",
        "Event_Window_state": row.get("event_window_state_at_signal", "NA"),
        "M30_regime": row.get("m30_state_at_signal", "NA"),
        "M5_proxy_state": row.get("m5_state_at_signal", "NA"),
        "ClosePriority_state": "not separately exported in overlay row; root snapshot id retained for future join",
        "classification": "HTE_BECAME_ELIGIBLE_LATER_INFERRED_FROM_FINAL_REASON",
        "bespoke_condition_allowed": "false",
    }
    write_csv(OUT / "ma_m15_hte_kill_design_trace.csv", [trace])
    write_text(
        OUT / "ma_m15_hte_kill_design_trace.txt",
        "\n".join(f"{k}: {v}" for k, v in trace.items()),
    )
    return trace


def make_event_and_whipsaw() -> None:
    write_text(
        OUT / "ma_whipsaw_retest_diagnostic_spec.txt",
        """
        Whipsaw / Recross Diagnostic Specification

        Record per Basket:
        cross count per Basket, first reverse cross, first recross, minutes to
        recross, bars to recross, recross within 1/2/3 bars, MA separation at
        cross and after 1/2/3 bars, floating P/L at cross, best/worst P/L after
        cross, actual final P/L.

        Persistence is diagnostic only. No persistence threshold is accepted as
        an Exit rule in this design freeze.

        M5 Retest naming:
        EXPLICIT_M5_RETEST_FAILURE is NOT available.
        M5_REVERSE_FOLLOWTHROUGH_PROXY is available from closed-bar MA Cross
        artifacts.
        M5_PULLBACK_PROXY is available only for entry-timing simulations from
        MA Cross Audit, not as a confirmed Basket exit signal.
        """,
    )
    write_text(
        OUT / "ma_event_context_contract.txt",
        """
        Event Risk Context Contract

        Primary Event Window remains high-impact USD event +/-60 minutes.

        At first M15 reverse cross, record:
        event calendar available, timezone verified, event window state,
        minutes to event, minutes after event, existing NewsBlock,
        calendar/EA mismatch, and whether the Basket was already open at event
        start.

        The six observed MA/Event overlaps remain stratification only. Event
        state must not be combined with MA state into a new optimized condition
        in this audit.
        """,
    )


def make_telemetry_outputs(source_text: str) -> None:
    exact_runtime_exists = "ema10" in source_text.lower() and "sma20" in source_text.lower()
    rows = [
        {
            "option": "OFFLINE_OVERLAY_ONLY",
            "runtime_interference_risk": "NONE",
            "indicator_cache_contamination_risk": "NONE",
            "series_synchronization_risk": "NONE_RUNTIME",
            "first_call_side_effect": "NONE_RUNTIME",
            "timestamp_precision": "root_snapshot_msc_join",
            "closed_bar_guarantee": "HIGH_WITH_CONTRACT",
            "tester_reproducibility": "HIGH_IF_INPUTS_LOCKED",
            "cpu_load": "OFFLINE_ONLY",
            "log_load": "NONE_RUNTIME",
            "implementation_complexity": "LOW",
            "nonintervention_regression_requirement": "NO_EA_CHANGE; overlay pipeline validation",
            "rollback_ease": "HIGH",
            "recommended": "YES_PRIMARY",
        },
        {
            "option": "POST_RUNTIME_READONLY_HANDOFF",
            "runtime_interference_risk": "LOW_IF_EXISTING_VALUES_ALREADY_COMPUTED",
            "indicator_cache_contamination_risk": "LOW_ONLY_IF_NO_HELPER_CALL",
            "series_synchronization_risk": "LOW_IF_NO_NEW_SERIES_CALL",
            "first_call_side_effect": "NONE_ONLY_IF_VALUES_EXIST",
            "timestamp_precision": "HIGH",
            "closed_bar_guarantee": "HIGH_IF_VALUE_SOURCE_PROVEN",
            "tester_reproducibility": "HIGH_WITH_REGRESSION",
            "cpu_load": "LOW",
            "log_load": "MEDIUM",
            "implementation_complexity": "MEDIUM",
            "nonintervention_regression_requirement": "A/B/C 6-run with indicator cache fingerprint",
            "rollback_ease": "MEDIUM",
            "recommended": "NO_CURRENTLY; exact 10EMA/20SMA not proven in runtime",
        },
        {
            "option": "DEDICATED_HANDLE_AFTER_RUNTIME",
            "runtime_interference_risk": "MEDIUM",
            "indicator_cache_contamination_risk": "MEDIUM",
            "series_synchronization_risk": "MEDIUM",
            "first_call_side_effect": "POSSIBLE",
            "timestamp_precision": "HIGH",
            "closed_bar_guarantee": "HIGH_IF_CAREFUL",
            "tester_reproducibility": "REQUIRES_STRICT_REGRESSION",
            "cpu_load": "MEDIUM",
            "log_load": "MEDIUM",
            "implementation_complexity": "HIGH",
            "nonintervention_regression_requirement": "A/B/C plus cache fingerprint",
            "rollback_ease": "MEDIUM",
            "recommended": "NO",
        },
        {
            "option": "COPYRATES_AND_LOCAL_MA_AFTER_RUNTIME",
            "runtime_interference_risk": "MEDIUM",
            "indicator_cache_contamination_risk": "LOWER_THAN_COPYBUFFER_BUT_SERIES_RISK_EXISTS",
            "series_synchronization_risk": "MEDIUM",
            "first_call_side_effect": "POSSIBLE",
            "timestamp_precision": "HIGH",
            "closed_bar_guarantee": "HIGH_IF_SERIES_READY",
            "tester_reproducibility": "REQUIRES_STRICT_REGRESSION",
            "cpu_load": "MEDIUM_HIGH",
            "log_load": "MEDIUM",
            "implementation_complexity": "HIGH",
            "nonintervention_regression_requirement": "A/B/C plus series/cache fingerprint",
            "rollback_ease": "MEDIUM",
            "recommended": "NO_FOR_NOW",
        },
        {
            "option": "NO_RUNTIME_MA_TELEMETRY",
            "runtime_interference_risk": "NONE",
            "indicator_cache_contamination_risk": "NONE",
            "series_synchronization_risk": "NONE_RUNTIME",
            "first_call_side_effect": "NONE",
            "timestamp_precision": "root_snapshot_msc_join",
            "closed_bar_guarantee": "HIGH_WITH_OVERLAY",
            "tester_reproducibility": "HIGH",
            "cpu_load": "NONE_RUNTIME",
            "log_load": "NONE_RUNTIME",
            "implementation_complexity": "LOW",
            "nonintervention_regression_requirement": "overlay validation only",
            "rollback_ease": "HIGH",
            "recommended": "YES_EQUIVALENT_TO_OFFLINE_OVERLAY_FOR_NOW",
        },
    ]
    write_csv(OUT / "ma_telemetry_option_compare.csv", rows)
    write_text(
        OUT / "ma_telemetry_source_of_truth_decision.txt",
        f"""
        Telemetry Source of Truth Decision

        Decision: OFFLINE_OVERLAY_ONLY.

        Reason:
        - Offline Overlay reproduced Basket join at 442/442.
        - It can assign closed-bar first eligible root_snapshot_id.
        - It can classify pre-hedge/post-hedge, Event Window, and actual close
          using existing Phase 1 runtime CSVs.
        - Runtime source contains MA infrastructure and EMA20/50 style fields,
          but exact 10EMA / 20SMA runtime values are not proven.
        - Existing root cause shows Shadow-side indicator access can contaminate
          Runtime indicator/cache behavior.

        runtime_exact_ma_values_already_exist: {str(exact_runtime_exists).lower()}
        additional_runtime_ma_telemetry_required: false
        CopyBuffer_required: false
        PerfCopyBuffer_reuse_allowed: false
        shared_runtime_indicator_helper_reuse_allowed: false
        """,
    )
    write_text(
        OUT / "ma_offline_overlay_contract.txt",
        """
        Offline Overlay Contract

        Inputs:
        Phase 1 root snapshot CSV, Basket summary CSV, M5/M15/M30 bar data,
        exact MA definition, Event calendar, trade event/final close data.

        Join keys:
        run_id, symbol, server_time, server_time_msc, source bar close time,
        first eligible root snapshot, basket_uid/canonical Basket key.

        Required validation:
        join rate, orphan signal, orphan snapshot, duplicate signal, duplicate
        snapshot, timezone mismatch, bar-close look-ahead prevention, signal
        availability delay, missing Bars, incomplete final bar.

        This is reusable for prospective runtime snapshot collections without
        adding MA telemetry to the EA.
        """,
    )
    write_text(
        OUT / "ma_post_runtime_handoff_contract.txt",
        """
        Post Runtime Handoff Contract

        Status: NOT CURRENTLY RECOMMENDED.

        It becomes eligible only if source inspection proves the exact 10EMA and
        20SMA closed-bar values are already computed by existing Runtime before
        any Shadow access. No shared helper, PerfCopyBuffer, CopyBuffer, iMA, or
        CopyRates may be called by Shadow before Runtime entry/hedge/close
        evaluation.

        exact_future_insertion_point: NA_NOT_RECOMMENDED
        """,
    )
    write_csv(
        OUT / "ma_future_insertion_map.csv",
        [
            {
                "candidate": "POST_RUNTIME_READONLY_HANDOFF",
                "source_file": "KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5",
                "function": "OnTick",
                "exact_anchor_before": "NA_NOT_RECOMMENDED",
                "exact_anchor_after": "all Runtime entry/hedge/close/hardstop evaluation if ever implemented",
                "runtime_entry_evaluation_completed": "TRUE_REQUIRED",
                "hedge_evaluation_completed": "TRUE_REQUIRED",
                "close_evaluation_completed": "TRUE_REQUIRED",
                "hardstop_evaluation_completed": "TRUE_REQUIRED",
                "shared_cache_access": "FORBIDDEN",
                "state_mutation": "FORBIDDEN",
                "early_return_impact": "FORBIDDEN",
                "GetLastError_impact": "FORBIDDEN",
                "logger_failure_propagation": "FORBIDDEN",
                "current_status": "DO_NOT_IMPLEMENT",
            }
        ],
    )


def make_regression_and_risk_outputs() -> None:
    write_text(
        OUT / "ma_nonintervention_regression_plan.txt",
        """
        Future Non-Intervention Regression Plan for Runtime MA Shadow

        A: current Phase 1 source.
        B: MA Shadow-added source with MA Shadow OFF.
        C: MA Shadow-added source with MA Shadow ON.

        Required pass:
        A vs B 6/6 identical, B vs C 6/6 identical, A vs C 6/6 identical.
        order/deal/close diff 0, indicator helper call count unchanged,
        PerfCopyBuffer call count unchanged, Runtime indicator cache fingerprint
        unchanged, Entry/Hedge/Close evaluator call count unchanged, logger
        failure non-propagating, MA Shadow-origin order count 0.

        Indicator cache fingerprint:
        hash of per-run CopyBuffer breakdown CSV plus counters
        CopyBufferCallCount, CopyBufferRequestedCount,
        CopyBufferDuplicateSameTickCount, CopyBufferMemoHitCount,
        CopyBufferMemoMissCount, and ordered breakdown category/name/shift/count.
        """,
    )
    write_text(
        OUT / "ma_cache_contamination_prevention_requirements.txt",
        """
        Cache Contamination Prevention Requirements

        Forbidden:
        Shadow Runtime indicator helper leading calls, PerfCopyBuffer reuse,
        new iMA before Runtime evaluation, CopyBuffer before Runtime evaluation,
        CopyRates before Runtime evaluation, shared indicator cache assumptions.

        Primary design:
        OFFLINE_OVERLAY_ONLY. No EA MA telemetry. No indicator cache touch.
        """,
    )
    write_csv(
        OUT / "ma_runtime_field_availability.csv",
        [
            {"field": "root_snapshot_id", "available": "TRUE", "source": "Phase 1 root snapshot"},
            {"field": "server_time_msc", "available": "TRUE", "source": "Phase 1 root snapshot"},
            {"field": "basket_uid", "available": "TRUE", "source": "Phase 1 root snapshot/summary"},
            {"field": "current_basket_net_pl", "available": "TRUE", "source": "Phase 1 root snapshot"},
            {"field": "distance_to_hardstop_yen", "available": "TRUE", "source": "Phase 1 root snapshot"},
            {"field": "HTE eligibility", "available": "TRUE_WITH_UNKNOWN_ALLOWED", "source": "Phase 1 root snapshot"},
            {"field": "Recovery eligibility", "available": "TRUE_WITH_UNKNOWN_ALLOWED", "source": "Phase 1 root snapshot"},
            {"field": "BasketClose eligibility", "available": "TRUE_WITH_UNKNOWN_ALLOWED", "source": "Phase 1 root snapshot"},
            {"field": "exact_10EMA_20SMA_runtime_values", "available": "FALSE_NOT_PROVEN", "source": "source inspection"},
            {"field": "Event Window", "available": "TRUE_PARTIAL_TIMEZONE", "source": "Phase 1 Event Risk minimal + Event Blackout audit"},
        ],
    )
    write_csv(
        OUT / "ma_design_risk_register.csv",
        [
            {"risk": "Event timezone partial verification", "level": "MEDIUM", "mitigation": "preserve PARTIAL/UNKNOWN and stratify only"},
            {"risk": "M5 retest proxy overstatement", "level": "MEDIUM", "mitigation": "label as proxy, not explicit retest failure"},
            {"risk": "HTE Kill one case", "level": "LOW_MEDIUM", "mitigation": "existing close protection contract; no bespoke exception"},
            {"risk": "Runtime indicator cache contamination", "level": "HIGH_IF_RUNTIME_TELEMETRY", "mitigation": "OFFLINE_OVERLAY_ONLY"},
            {"risk": "In-sample one-step diagnostic misuse", "level": "HIGH", "mitigation": "no implementation/OOS/performance claim"},
        ],
    )


def make_source_verification() -> None:
    src_sha = sha256(TERMINAL_SOURCE) if TERMINAL_SOURCE.exists() else "MISSING"
    ex5_sha = sha256(TERMINAL_EX5) if TERMINAL_EX5.exists() else "MISSING"
    write_text(
        OUT / "source_unchanged_verification.txt",
        f"""
        source_sha256: {src_sha}
        expected_source_sha256: {EXPECTED['source']}
        source_changed: {str(src_sha != EXPECTED['source']).lower()}
        ex5_sha256: {ex5_sha}
        expected_ex5_sha256: {EXPECTED['ex5']}
        ex5_changed: {str(ex5_sha != EXPECTED['ex5']).lower()}
        mq5_changed: false
        mqh_changed: false
        Strategy_Tester_executed: false
        Runtime_indicator_helper_call_added: false
        PerfCopyBuffer_call_added: false
        Compile_required: false
        """,
    )


def build_final_decision(overlay_fields: dict[str, str], hte_trace: dict[str, str]) -> dict[str, str]:
    return {
        "selected_ma_shadow_design": "M15_REVERSE_CROSS_OFFLINE_OVERLAY_SIGNAL_CONTRACT",
        "decision_class": "MA_M15_OFFLINE_OVERLAY_SHADOW_DESIGN_READY",
        "P1_implementation_allowed": "false",
        "real_exit_implementation_allowed": "false",
        "ma_cross_logic_implementation_allowed": "false",
        "ma_retest_exit_implementation_allowed": "false",
        "shadow_logging_implementation_allowed": "false",
        "next_ma_shadow_implementation_allowed_candidate": "false",
        "offline_ma_runtime_collection_ready": "true",
        "input_overlay_audit_sha256": EXPECTED["overlay_zip"],
        "input_phase1_fix_audit_sha256": EXPECTED["phase1_fix_zip"],
        "input_ma_cross_audit_sha256": EXPECTED["ma_cross_zip"],
        "source_sha256": EXPECTED["source"],
        "source_changed": "false",
        "exact_fast_ma_type": "EMA",
        "exact_fast_ma_period": "10",
        "exact_slow_ma_type": "SMA",
        "exact_slow_ma_period": "20",
        "applied_price": "close",
        "M15_cross_formula_verified": "true",
        "M30_regime_formula_verified": "true",
        "M5_retest_proxy_formula_verified": "true_proxy_only",
        "closed_bar_signal_contract_ready": "true",
        "first_signal_contract_ready": "true",
        "direction_mapping_ready": "true",
        "existing_close_protection_contract_ready": "true",
        "HTE_kill_trace_ready": "true",
        "HTE_kill_current_eligibility_status": hte_trace.get("HTE_eligibility_at_signal", "UNKNOWN"),
        "runtime_exact_ma_values_already_exist": "false",
        "offline_overlay_sufficient": "true",
        "additional_runtime_ma_telemetry_required": "false",
        "post_runtime_readonly_handoff_possible": "false",
        "new_indicator_handle_required": "false",
        "CopyBuffer_required": "false",
        "PerfCopyBuffer_reuse_allowed": "false",
        "shared_runtime_indicator_helper_reuse_allowed": "false",
        "recommended_telemetry_method": "OFFLINE_OVERLAY_ONLY",
        "exact_future_insertion_point": "NA_NOT_RECOMMENDED",
        "indicator_cache_contamination_risk": "NONE_FOR_OFFLINE_OVERLAY; HIGH_IF_RUNTIME_HELPERS_REUSED",
        "nonintervention_regression_plan_ready": "true",
        "Event_timezone_status": "PARTIAL",
        "M5_proxy_limitation": "EXPLICIT_M5_RETEST_FAILURE_NOT_AVAILABLE; M5_REVERSE_FOLLOWTHROUGH_PROXY_ONLY",
        "full_EA_counterfactual_claim_allowed": "false",
        "unresolved_risks": "Event timezone partial; explicit M5 retest failure unavailable; HTE actual eligibility time not logged; all evidence remains in-sample one-step diagnostic.",
        "next_action": "Prospective Runtime Snapshot plus Offline MA Overlay Collection; no MA Exit implementation.",
        "overlay_join_rate": overlay_fields.get("join_rate", "1.000000"),
        "overlay_hardstop_any_reverse_cross_count": overlay_fields.get("hardstop_with_any_reverse_cross_count", "33"),
        "overlay_m15_hardstop_coverage": overlay_fields.get("hardstop_with_m15_reverse_cross_count", "29"),
    }


def write_summary_and_bundle(final: dict[str, str], counts: dict[str, int]) -> None:
    write_text(
        OUT / "ma_m15_shadow_design_summary.txt",
        f"""
        M15 Reverse Cross / MA Retest Non-Intervening Shadow Design Freeze Audit

        decision_class: {final['decision_class']}
        selected_ma_shadow_design: {final['selected_ma_shadow_design']}
        recommended_telemetry_method: {final['recommended_telemetry_method']}

        Runtime Snapshot evidence:
        root_snapshots: {counts['root_snapshots']}
        basket_summaries: {counts['basket_summaries']}
        run_summaries: {counts['run_summaries']}

        Design decision:
        Offline Overlay is sufficient for the next collection step. Runtime MA
        telemetry is not required because exact 10EMA/20SMA values are not
        proven to already exist inside Runtime and any Shadow-side indicator
        access would reintroduce the known cache-contamination risk.

        M15 reverse cross is observation-ready, not exit-ready.
        M5 retest remains proxy-only.
        """,
    )
    write_text(OUT / "ma_m15_shadow_final_decision.txt", "\n".join(f"{k}: {v}" for k, v in final.items()))
    write_text(
        OUT / "result_summary.txt",
        f"""
        M15 Reverse Cross / MA Retest Shadow Design Freeze
        decision_class: {final['decision_class']}
        telemetry_method: OFFLINE_OVERLAY_ONLY
        runtime_ma_telemetry_required: false
        next_ma_shadow_implementation_allowed_candidate: false
        offline_ma_runtime_collection_ready: true
        source_changed: false

        The M15 reverse cross signal definition, closed-bar availability,
        First-Signal contract, Existing Close protection, HTE Kill trace, and
        cache-contamination prevention requirements are frozen for the next
        prospective offline overlay collection.
        """,
    )
    write_text(
        OUT / "next_decision.txt",
        "Next action: Prospective Runtime Snapshot + Offline MA Overlay Collection. Do not implement MA Exit, MA Runtime telemetry, Event Stop, Pre-Hedge Exit, Hedge Gate, TA9 real exit, or P1.",
    )
    write_text(
        OUT / "publication_consistency_check.txt",
        f"""
        Publication Consistency Check
        generated_at: {datetime.now().isoformat(timespec='seconds')}
        audit_title: M15 Reverse Cross / MA Retest Non-Intervening Shadow Design Freeze Audit
        named_zip: KOUCHA_GOLD_M15_REVERSE_CROSS_SHADOW_DESIGN_AUDIT.zip
        decision_class: {final['decision_class']}
        selected_ma_shadow_design: {final['selected_ma_shadow_design']}
        publication_status: PENDING_PUBLICATION
        """,
    )
    write_text(
        OUT / "calculation_self_audit.txt",
        """
        Calculation Self Audit

        This design audit did not recompute executable P/L, did not run Strategy
        Tester, did not modify source, and did not use future outcomes to change
        Signal definitions. Overlay statistics are imported from the locked MA
        Runtime Overlay Audit. HTE Kill trace is extracted from the locked
        first-signal Basket table.
        """,
    )
    bundle = "\n\n".join(
        [
            (OUT / "ma_m15_shadow_design_summary.txt").read_text(encoding="utf-8"),
            (OUT / "ma_m15_shadow_final_decision.txt").read_text(encoding="utf-8"),
            (OUT / "ma_exact_definition_lock.txt").read_text(encoding="utf-8"),
            (OUT / "ma_telemetry_source_of_truth_decision.txt").read_text(encoding="utf-8"),
            (OUT / "next_decision.txt").read_text(encoding="utf-8"),
        ]
    )
    write_text(OUT / "ai_bundle.txt", bundle)


def make_wrapper_scripts() -> None:
    names = [
        "lock_ma_definition.py",
        "validate_ma_signal_availability.py",
        "build_ma_signal_state_machine.py",
        "trace_m15_hte_kill.py",
        "assess_offline_overlay_sufficiency.py",
        "inspect_runtime_ma_field_availability.py",
        "compare_ma_telemetry_architectures.py",
    ]
    for name in names:
        path = SCRIPTS / name
        path.write_text(
            "from build_ma_shadow_design_bundle import main\n\nif __name__ == '__main__':\n    main()\n",
            encoding="utf-8",
        )


def main() -> None:
    ensure_dirs()
    input_rows = audit_inputs()
    if not all(str(r["sha_match"]) == "True" for r in input_rows):
        raise SystemExit("Input SHA mismatch; design audit blocked.")
    publication_preflight()
    ma_script = extract_ma_script()
    source_text = TERMINAL_SOURCE.read_text(encoding="utf-8", errors="ignore") if TERMINAL_SOURCE.exists() else ""
    ma_script_text = ma_script.read_text(encoding="utf-8", errors="ignore")
    (EVIDENCE / "runtime_ma_static_scan_excerpt.txt").write_text(
        "\n".join(line for line in source_text.splitlines() if any(tok in line for tok in ("iMA", "PerfCopyBuffer", "CopyBuffer", "EMA", "SMA"))),
        encoding="utf-8",
    )
    (EVIDENCE / "ma_cross_script_definition_excerpt.txt").write_text(
        "\n".join(line for line in ma_script_text.splitlines() if any(tok in line for tok in ("ema10", "sma20", "rolling", "ewm", "find_pullback_entry", "bull =", "bear ="))),
        encoding="utf-8",
    )
    counts = count_phase1_runtime()
    write_csv(OUT / "phase1_runtime_counts.csv", [counts])
    overlay_fields = get_overlay_fields()
    make_definition_outputs()
    make_signal_contracts()
    make_direction_mapping()
    make_state_machine()
    make_close_protection()
    hte_trace = make_hte_trace()
    make_event_and_whipsaw()
    make_telemetry_outputs(source_text)
    make_regression_and_risk_outputs()
    make_source_verification()
    final = build_final_decision(overlay_fields, hte_trace)
    write_summary_and_bundle(final, counts)
    make_wrapper_scripts()
    print(json.dumps(final, indent=2))


if __name__ == "__main__":
    main()
