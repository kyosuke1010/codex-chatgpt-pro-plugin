from __future__ import annotations

import csv
import hashlib
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import MetaTrader5 as mt5
import numpy as np
import pandas as pd


ROOT = Path(r"C:\Users\user\Documents\New project")
AUDIT = ROOT / "KOUCHA_GOLD_MA_CROSS_10EMA20SMA_AUDIT"
DATA = AUDIT / "data"
REPORTS = AUDIT / "reports"

TERMINAL = r"C:\Program Files\XMTrading MT5\terminal64.exe"
SYMBOL = "GOLD"
POINT = 0.01
THRESHOLDS_POINTS = [300, 500, 800]
LOOKAHEADS = [3, 5, 10, 20]
FIXED_EXIT_MAX_BARS = 80
PULLBACK_WAIT_BARS = 10
M5_PULLBACK_WAIT_BARS = 12
FETCH_FROM = datetime(2026, 3, 1, tzinfo=timezone.utc)
FETCH_TO = datetime(2026, 5, 30, tzinfo=timezone.utc)

BASKET_MASTER = ROOT / "KOUCHA_GOLD_CURRENT_EA_BASKET_PAYOFF_STRUCTURE_AUDIT" / "basket_master_table.csv"
HARDSTOP_PATH = ROOT / "KOUCHA_GOLD_HARDSTOP_ROOT_CAUSE_MULTI_LOGIC_AUDIT" / "hardstop_path_master.csv"
EA_SOURCE = ROOT / "KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def ensure_dirs() -> None:
    for p in (AUDIT, DATA, REPORTS, AUDIT / "scripts"):
        p.mkdir(parents=True, exist_ok=True)


def parse_dt(value: str) -> Optional[pd.Timestamp]:
    if value is None:
        return None
    value = str(value).strip()
    if not value or value.upper() == "NA":
        return None
    for fmt in ("%Y.%m.%d %H:%M:%S", "%Y.%m.%d", "%Y-%m-%d %H:%M:%S"):
        try:
            return pd.Timestamp(datetime.strptime(value, fmt))
        except ValueError:
            continue
    try:
        return pd.Timestamp(value)
    except Exception:
        return None


def fetch_rates() -> Dict[str, pd.DataFrame]:
    tf_map = {"M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30}
    if not mt5.initialize(path=TERMINAL):
        raise RuntimeError(f"MetaTrader5 initialize failed: {mt5.last_error()}")
    try:
        info = mt5.terminal_info()
        account = mt5.account_info()
        if not info or not account:
            raise RuntimeError("MT5 terminal/account info unavailable")
        if account.server != "XMTrading-MT5 2":
            raise RuntimeError(f"Unexpected account server: {account.server}")
        if not mt5.symbol_select(SYMBOL, True):
            raise RuntimeError(f"symbol_select failed for {SYMBOL}: {mt5.last_error()}")

        manifest_rows = []
        frames: Dict[str, pd.DataFrame] = {}
        for name, tf in tf_map.items():
            rates = mt5.copy_rates_range(SYMBOL, tf, FETCH_FROM, FETCH_TO)
            err = mt5.last_error()
            if rates is None or len(rates) == 0:
                raise RuntimeError(f"No rates for {SYMBOL} {name}: {err}")
            df = pd.DataFrame(rates)
            df["datetime"] = pd.to_datetime(df["time"], unit="s")
            df = df.rename(
                columns={
                    "tick_volume": "tick_volume",
                    "real_volume": "real_volume",
                }
            )
            df = df[
                [
                    "datetime",
                    "time",
                    "open",
                    "high",
                    "low",
                    "close",
                    "tick_volume",
                    "spread",
                    "real_volume",
                ]
            ].copy()
            df["timeframe"] = name
            df.to_csv(DATA / f"gold_rates_{name}.csv", index=False)
            frames[name] = df
            manifest_rows.append(
                {
                    "symbol": SYMBOL,
                    "timeframe": name,
                    "rows": len(df),
                    "first_datetime": df["datetime"].iloc[0],
                    "last_datetime": df["datetime"].iloc[-1],
                    "terminal_path": info.path,
                    "terminal_data_path": info.data_path,
                    "terminal_build": info.build,
                    "account_server": account.server,
                    "account_currency": account.currency,
                    "account_leverage": account.leverage,
                    "last_error": str(err),
                    "source_method": "MetaTrader5.copy_rates_range_read_only",
                }
            )
        pd.DataFrame(manifest_rows).to_csv(AUDIT / "data_source_manifest.csv", index=False)
        return frames
    finally:
        mt5.shutdown()


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.sort_values("datetime").reset_index(drop=True).copy()
    out["ema10"] = out["close"].ewm(span=10, adjust=False).mean()
    out["sma20"] = out["close"].rolling(20, min_periods=20).mean()
    prev_close = out["close"].shift(1)
    tr = pd.concat(
        [
            out["high"] - out["low"],
            (out["high"] - prev_close).abs(),
            (out["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    out["atr"] = tr.rolling(14, min_periods=14).mean()
    out["ema_sma_gap"] = out["ema10"] - out["sma20"]
    out["ma_state"] = np.where(out["ema10"] > out["sma20"], "BULL", np.where(out["ema10"] < out["sma20"], "BEAR", "NEUTRAL"))
    both_high = out[["ema10", "sma20"]].max(axis=1)
    both_low = out[["ema10", "sma20"]].min(axis=1)
    out["price_position"] = np.where(
        out["close"] > both_high,
        "close_above_both",
        np.where(out["close"] < both_low, "close_below_both", "close_between"),
    )
    return out


def asof_state(state_df: pd.DataFrame, t: pd.Timestamp) -> str:
    idx = state_df["datetime"].searchsorted(t, side="right") - 1
    if idx < 0:
        return "UNKNOWN"
    return str(state_df.iloc[idx]["ma_state"])


def mtf_alignment(m5: str, m15: str, m30: str) -> str:
    if m5 == m15 == m30 == "BULL":
        return "ALL_BULL"
    if m5 == m15 == m30 == "BEAR":
        return "ALL_BEAR"
    return "MIXED"


def build_cross_events(frames: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    state_frames = {k: v[["datetime", "ma_state"]].copy() for k, v in frames.items()}
    rows = []
    for tf, df in frames.items():
        prev_gap = df["ema_sma_gap"].shift(1)
        bull = (prev_gap <= 0) & (df["ema_sma_gap"] > 0)
        bear = (prev_gap >= 0) & (df["ema_sma_gap"] < 0)
        event_idx = df.index[bull | bear].tolist()
        for i in event_idx:
            row = df.loc[i]
            if not np.isfinite(row["ema10"]) or not np.isfinite(row["sma20"]):
                continue
            cross_direction = "BULL_CROSS" if bull.loc[i] else "BEAR_CROSS"
            t = row["datetime"]
            m5 = asof_state(state_frames["M5"], t)
            m15 = asof_state(state_frames["M15"], t)
            m30 = asof_state(state_frames["M30"], t)
            rows.append(
                {
                    "datetime": t,
                    "timeframe": tf,
                    "cross_direction": cross_direction,
                    "ema10": row["ema10"],
                    "sma20": row["sma20"],
                    "close": row["close"],
                    "spread": row["spread"],
                    "atr": row["atr"],
                    "ema_sma_gap": row["ema_sma_gap"],
                    "price_position": row["price_position"],
                    "m5_state": m5,
                    "m15_state": m15,
                    "m30_state": m30,
                    "mtf_alignment": mtf_alignment(m5, m15, m30),
                    "bars_since_cross": 0,
                }
            )
    events = pd.DataFrame(rows).sort_values(["datetime", "timeframe"]).reset_index(drop=True)
    events.to_csv(AUDIT / "ma_cross_events.csv", index=False)
    return events


def direction_sign(cross_direction: str) -> int:
    return 1 if cross_direction == "BULL_CROSS" else -1


def forward_for_event(df: pd.DataFrame, idx: int, sign: int, n: int) -> Optional[dict]:
    future = df.iloc[idx + 1 : idx + 1 + n]
    if len(future) < n:
        return None
    entry = float(df.iloc[idx]["close"])
    close_n = float(future.iloc[-1]["close"])
    if sign == 1:
        mfe = float(future["high"].max() - entry)
        mae = float(entry - future["low"].min())
        close_move = close_n - entry
    else:
        mfe = float(entry - future["low"].min())
        mae = float(future["high"].max() - entry)
        close_move = entry - close_n
    out = {
        "max_favorable_move_price": mfe,
        "max_adverse_move_price": mae,
        "close_after_n_bars": close_n,
        "directional_close_move_price": close_move,
        "mfe_mae_ratio": (mfe / mae) if mae > 0 else np.nan,
    }
    for pts in THRESHOLDS_POINTS:
        thr = pts * POINT
        out[f"hit_tp_{pts}"] = bool(mfe >= thr)
        out[f"hit_sl_{pts}"] = bool(mae >= thr)
        first = first_touch(future, entry, sign, thr, thr)
        out[f"tp_before_sl_{pts}"] = first == "TP_FIRST"
        out[f"sl_before_tp_{pts}"] = first == "SL_FIRST"
        if pts == 500:
            out["tp_before_sl"] = first == "TP_FIRST"
            out["sl_before_tp"] = first == "SL_FIRST"
    return out


def first_touch(df: pd.DataFrame, entry: float, sign: int, tp: float, sl: float) -> str:
    for _, r in df.iterrows():
        if sign == 1:
            tp_hit = r["high"] >= entry + tp
            sl_hit = r["low"] <= entry - sl
        else:
            tp_hit = r["low"] <= entry - tp
            sl_hit = r["high"] >= entry + sl
        if tp_hit and sl_hit:
            return "AMBIGUOUS_SAME_BAR"
        if tp_hit:
            return "TP_FIRST"
        if sl_hit:
            return "SL_FIRST"
    return "NONE"


def build_forward_stats(frames: Dict[str, pd.DataFrame], events: pd.DataFrame) -> pd.DataFrame:
    rows = []
    indexed = {tf: df.reset_index(drop=True) for tf, df in frames.items()}
    time_to_idx = {tf: {t: i for i, t in enumerate(df["datetime"])} for tf, df in indexed.items()}
    for _, ev in events.iterrows():
        tf = ev["timeframe"]
        idx = time_to_idx[tf].get(ev["datetime"])
        if idx is None:
            continue
        sign = direction_sign(ev["cross_direction"])
        for n in LOOKAHEADS:
            f = forward_for_event(indexed[tf], idx, sign, n)
            if f is None:
                continue
            base = ev.to_dict()
            base["lookahead_bars"] = n
            base.update(f)
            rows.append(base)
    stats = pd.DataFrame(rows)
    stats.to_csv(AUDIT / "ma_cross_forward_stats.csv", index=False)
    return stats


@dataclass
class EntrySignal:
    pattern: str
    source_timeframe: str
    direction: str
    entry_time: pd.Timestamp
    entry_price: float
    spread_points: float
    source_cross_time: pd.Timestamp


def get_bar_at_or_before(df: pd.DataFrame, t: pd.Timestamp) -> Optional[pd.Series]:
    idx = df["datetime"].searchsorted(t, side="right") - 1
    if idx < 0:
        return None
    return df.iloc[idx]


def find_pullback_entry(df: pd.DataFrame, start_time: pd.Timestamp, direction: str, wait_bars: int) -> Optional[Tuple[pd.Timestamp, float, float]]:
    idx = df["datetime"].searchsorted(start_time, side="right")
    sign = 1 if direction == "BUY" else -1
    for _, r in df.iloc[idx : idx + wait_bars].iterrows():
        if not np.isfinite(r["ema10"]):
            continue
        if sign == 1 and r["low"] <= r["ema10"]:
            return r["datetime"], float(r["ema10"]), float(r["spread"])
        if sign == -1 and r["high"] >= r["ema10"]:
            return r["datetime"], float(r["ema10"]), float(r["spread"])
    return None


def build_entry_signals(frames: Dict[str, pd.DataFrame], events: pd.DataFrame) -> List[EntrySignal]:
    signals: List[EntrySignal] = []
    for _, ev in events.iterrows():
        direction = "BUY" if ev["cross_direction"] == "BULL_CROSS" else "SELL"
        tf = ev["timeframe"]
        signals.append(
            EntrySignal("ENTRY_A_CROSS_CLOSE", tf, direction, ev["datetime"], float(ev["close"]), float(ev["spread"]), ev["datetime"])
        )
        pb = find_pullback_entry(frames[tf], ev["datetime"], direction, PULLBACK_WAIT_BARS)
        if pb:
            signals.append(EntrySignal("ENTRY_B_PULLBACK_TO_10EMA", tf, direction, pb[0], pb[1], pb[2], ev["datetime"]))
        align_needed = "ALL_BULL" if direction == "BUY" else "ALL_BEAR"
        if ev["mtf_alignment"] == align_needed:
            signals.append(
                EntrySignal("ENTRY_D_M5_M15_M30_ALL_ALIGNED", tf, direction, ev["datetime"], float(ev["close"]), float(ev["spread"]), ev["datetime"])
            )
        if not ((ev["m30_state"] == "BULL" and ev["m15_state"] == "BEAR") or (ev["m30_state"] == "BEAR" and ev["m15_state"] == "BULL")):
            signals.append(
                EntrySignal("ENTRY_G_M30_M15_OPPOSITE_BAN", tf, direction, ev["datetime"], float(ev["close"]), float(ev["spread"]), ev["datetime"])
            )
        if tf == "M15":
            m30_ok = (direction == "BUY" and ev["m30_state"] == "BULL") or (direction == "SELL" and ev["m30_state"] == "BEAR")
            if m30_ok:
                pb_m5 = find_pullback_entry(frames["M5"], ev["datetime"], direction, M5_PULLBACK_WAIT_BARS)
                if pb_m5:
                    signals.append(EntrySignal("ENTRY_C_M30_DIR_M15_CROSS_M5_PULLBACK", "M15", direction, pb_m5[0], pb_m5[1], pb_m5[2], ev["datetime"]))
    return signals


def opposite_cross_after(events: pd.DataFrame, after: pd.Timestamp, direction: str, tf: str) -> Optional[pd.Series]:
    need = "BEAR_CROSS" if direction == "BUY" else "BULL_CROSS"
    subset = events[(events["timeframe"] == tf) & (events["datetime"] > after) & (events["cross_direction"] == need)]
    if subset.empty:
        return None
    return subset.iloc[0]


def m5_path_between(frames: Dict[str, pd.DataFrame], start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    df = frames["M5"]
    return df[(df["datetime"] >= start) & (df["datetime"] <= end)]


def mfe_mae_on_path(path: pd.DataFrame, entry: float, direction: str) -> Tuple[float, float]:
    if path.empty:
        return 0.0, 0.0
    if direction == "BUY":
        return float(path["high"].max() - entry), float(entry - path["low"].min())
    return float(entry - path["low"].min()), float(path["high"].max() - entry)


def simulate_trade(sig: EntrySignal, exit_rule: str, frames: Dict[str, pd.DataFrame], events: pd.DataFrame, tp_sl_points: Optional[int] = None) -> Optional[dict]:
    sign = 1 if sig.direction == "BUY" else -1
    spread_cost = sig.spread_points * POINT
    entry_tf_df = frames.get(sig.source_timeframe, frames["M5"])

    exit_time = None
    exit_price = None
    exit_reason = exit_rule
    ambiguous = False

    if exit_rule.startswith("EXIT_A_FIXED"):
        thr = (tp_sl_points or 500) * POINT
        start_idx = entry_tf_df["datetime"].searchsorted(sig.entry_time, side="right")
        future = entry_tf_df.iloc[start_idx : start_idx + FIXED_EXIT_MAX_BARS]
        touch = first_touch(future, sig.entry_price, sign, thr, thr)
        if touch == "TP_FIRST":
            exit_time = future.iloc[min(len(future) - 1, 0)]["datetime"]
            for _, r in future.iterrows():
                if (sign == 1 and r["high"] >= sig.entry_price + thr) or (sign == -1 and r["low"] <= sig.entry_price - thr):
                    exit_time = r["datetime"]
                    break
            exit_price = sig.entry_price + sign * thr
            exit_reason += "_TP"
        elif touch == "SL_FIRST" or touch == "AMBIGUOUS_SAME_BAR":
            ambiguous = touch == "AMBIGUOUS_SAME_BAR"
            exit_time = future.iloc[min(len(future) - 1, 0)]["datetime"]
            for _, r in future.iterrows():
                if (sign == 1 and r["low"] <= sig.entry_price - thr) or (sign == -1 and r["high"] >= sig.entry_price + thr):
                    exit_time = r["datetime"]
                    break
            exit_price = sig.entry_price - sign * thr
            exit_reason += "_SL" if not ambiguous else "_AMBIGUOUS_ASSUMED_SL"
        elif len(future):
            exit_time = future.iloc[-1]["datetime"]
            exit_price = float(future.iloc[-1]["close"])
            exit_reason += "_TIMEOUT"
        else:
            return None
    elif exit_rule in ("EXIT_B_REVERSE_CROSS_SAME_TF", "EXIT_C_RELATIONSHIP_REVERSAL_SAME_TF"):
        rev = opposite_cross_after(events, sig.entry_time, sig.direction, sig.source_timeframe)
        if rev is None:
            return None
        exit_time = rev["datetime"]
        exit_price = float(rev["close"])
    elif exit_rule == "EXIT_D_M5_REVERSE_CROSS_EARLY":
        rev = opposite_cross_after(events, sig.entry_time, sig.direction, "M5")
        if rev is None:
            return None
        exit_time = rev["datetime"]
        exit_price = float(rev["close"])
    elif exit_rule == "EXIT_E_M15_REVERSE_CROSS_MAIN":
        rev = opposite_cross_after(events, sig.entry_time, sig.direction, "M15")
        if rev is None:
            return None
        exit_time = rev["datetime"]
        exit_price = float(rev["close"])
    else:
        return None

    if exit_time is None or exit_price is None:
        return None
    path = m5_path_between(frames, sig.entry_time, pd.Timestamp(exit_time))
    mfe, mae = mfe_mae_on_path(path, sig.entry_price, sig.direction)
    pnl = sign * (float(exit_price) - sig.entry_price) - spread_cost
    return {
        "entry_pattern": sig.pattern,
        "exit_rule": exit_rule if tp_sl_points is None else f"{exit_rule}_{tp_sl_points}",
        "source_timeframe": sig.source_timeframe,
        "direction": sig.direction,
        "entry_time": sig.entry_time,
        "entry_price": sig.entry_price,
        "exit_time": exit_time,
        "exit_price": exit_price,
        "exit_reason": exit_reason,
        "pnl_price_after_spread": pnl,
        "spread_cost_price": spread_cost,
        "commission_status": "NOT_AVAILABLE",
        "mfe_price": mfe,
        "mae_price": mae,
        "ambiguous_same_bar_assumed_sl": ambiguous,
        "source_cross_time": sig.source_cross_time,
    }


def summarize_trades(trades: pd.DataFrame, hardstop_precursors: Dict[str, int]) -> pd.DataFrame:
    rows = []
    if trades.empty:
        return pd.DataFrame()
    for keys, g in trades.groupby(["entry_pattern", "exit_rule", "source_timeframe"], dropna=False):
        pnl = g["pnl_price_after_spread"]
        wins = pnl[pnl > 0]
        losses = pnl[pnl < 0]
        equity = pnl.cumsum()
        dd = equity.cummax() - equity
        max_consec = 0
        cur = 0
        for v in pnl:
            if v < 0:
                cur += 1
                max_consec = max(max_consec, cur)
            else:
                cur = 0
        gross_profit = float(wins.sum())
        gross_loss = float(losses.sum())
        rows.append(
            {
                "entry_pattern": keys[0],
                "exit_rule": keys[1],
                "timeframe": keys[2],
                "trades": len(g),
                "win_rate": float((pnl > 0).mean()) if len(g) else np.nan,
                "gross_profit": gross_profit,
                "gross_loss": gross_loss,
                "net_profit": float(pnl.sum()),
                "profit_factor": gross_profit / abs(gross_loss) if gross_loss < 0 else np.nan,
                "average_win": float(wins.mean()) if len(wins) else np.nan,
                "average_loss": float(losses.mean()) if len(losses) else np.nan,
                "max_drawdown": float(dd.max()) if len(dd) else np.nan,
                "max_consecutive_losses": max_consec,
                "avg_mfe": float(g["mfe_price"].mean()),
                "avg_mae": float(g["mae_price"].mean()),
                "recovery_loss_cut_avoid_count": 0,
                "hardstop_precursor_count": hardstop_precursors.get(keys[2], 0),
                "pnl_unit": "GOLD_price_move_after_spread_not_yen",
            }
        )
    out = pd.DataFrame(rows).sort_values(["net_profit", "profit_factor"], ascending=[False, False])
    return out


def run_trade_sim(frames: Dict[str, pd.DataFrame], events: pd.DataFrame, hardstop_precursors: Dict[str, int]) -> pd.DataFrame:
    signals = build_entry_signals(frames, events)
    trade_rows = []
    for sig in signals:
        for pts in THRESHOLDS_POINTS:
            tr = simulate_trade(sig, "EXIT_A_FIXED_TP_SL", frames, events, pts)
            if tr:
                trade_rows.append(tr)
        for exit_rule in [
            "EXIT_B_REVERSE_CROSS_SAME_TF",
            "EXIT_C_RELATIONSHIP_REVERSAL_SAME_TF",
            "EXIT_D_M5_REVERSE_CROSS_EARLY",
            "EXIT_E_M15_REVERSE_CROSS_MAIN",
        ]:
            tr = simulate_trade(sig, exit_rule, frames, events)
            if tr:
                trade_rows.append(tr)
    trades = pd.DataFrame(trade_rows)
    trades.to_csv(AUDIT / "ma_cross_trade_sim_trades.csv", index=False)
    summary = summarize_trades(trades, hardstop_precursors)
    summary.to_csv(AUDIT / "ma_cross_trade_sim.csv", index=False)
    return summary


def build_state_stats(frames: Dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for tf, df in frames.items():
        for n in LOOKAHEADS:
            future_close = df["close"].shift(-n)
            move = future_close - df["close"]
            for state, gidx in df.groupby("ma_state").groups.items():
                if state == "NEUTRAL":
                    continue
                sub = move.loc[gidx].dropna()
                if sub.empty:
                    continue
                directional = sub if state == "BULL" else -sub
                rows.append(
                    {
                        "timeframe": tf,
                        "ma_state": state,
                        "lookahead_bars": n,
                        "samples": len(directional),
                        "mean_directional_move": float(directional.mean()),
                        "median_directional_move": float(directional.median()),
                        "positive_rate": float((directional > 0).mean()),
                        "avg_abs_move": float(directional.abs().mean()),
                    }
                )
    out = pd.DataFrame(rows)
    out.to_csv(AUDIT / "ma_state_direction_stats.csv", index=False)
    return out


def find_reverse_crosses(events: pd.DataFrame, start: Optional[pd.Timestamp], end: Optional[pd.Timestamp], entry_direction: str) -> Dict[str, dict]:
    out: Dict[str, dict] = {}
    if start is None or end is None:
        return out
    need = "BEAR_CROSS" if entry_direction.upper() == "BUY" else "BULL_CROSS"
    for tf in ["M5", "M15", "M30"]:
        sub = events[(events["timeframe"] == tf) & (events["cross_direction"] == need) & (events["datetime"] >= start) & (events["datetime"] <= end)]
        if sub.empty:
            out[tf] = {"detected": False}
        else:
            first = sub.iloc[0]
            out[tf] = {
                "detected": True,
                "signal_time": first["datetime"],
                "minutes_before_end": (end - first["datetime"]).total_seconds() / 60.0,
                "signal_close": first["close"],
            }
    return out


def build_hardstop_audit(events: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, int]]:
    rows = []
    hardstop_precursors = {"M5": 0, "M15": 0, "M30": 0}

    if HARDSTOP_PATH.exists():
        hard = pd.read_csv(HARDSTOP_PATH)
        for _, r in hard.iterrows():
            start = parse_dt(r.get("first_entry_time"))
            end = parse_dt(r.get("final_hardstop_time"))
            hedge = parse_dt(r.get("first_hedge_time"))
            entry_dir = str(r.get("entry_direction", "")).upper()
            rev = find_reverse_crosses(events, start, end, entry_dir)
            hedge_rev = find_reverse_crosses(events, hedge, end, entry_dir) if hedge is not None else {}
            any_det = any(v.get("detected") for v in rev.values())
            for tf, v in rev.items():
                if v.get("detected"):
                    hardstop_precursors[tf] += 1
            rows.append(
                {
                    "basket_uid": r.get("basket_uid"),
                    "run_id": r.get("run_id"),
                    "event_type": "HARDSTOP_CLOSE",
                    "entry_direction": entry_dir,
                    "first_entry_time": start,
                    "first_hedge_time": hedge if hedge is not None else "NA",
                    "final_event_time": end,
                    "final_pl_yen": r.get("final_pl"),
                    "m5_reverse_cross_before_event": rev.get("M5", {}).get("detected", False),
                    "m15_reverse_cross_before_event": rev.get("M15", {}).get("detected", False),
                    "m30_reverse_cross_before_event": rev.get("M30", {}).get("detected", False),
                    "earliest_reverse_cross_time": min([v["signal_time"] for v in rev.values() if v.get("detected")], default="NA"),
                    "max_minutes_before_event": max([v["minutes_before_end"] for v in rev.values() if v.get("detected")], default="NA"),
                    "reverse_cross_after_defensehedge": any(v.get("detected") for v in hedge_rev.values()) if hedge is not None else "NA",
                    "m5_minutes_before_event": rev.get("M5", {}).get("minutes_before_end", "NA"),
                    "m15_minutes_before_event": rev.get("M15", {}).get("minutes_before_end", "NA"),
                    "m30_minutes_before_event": rev.get("M30", {}).get("minutes_before_end", "NA"),
                    "recovery_losscut_precursor": "NOT_AVAILABLE_NO_RECOVERY_LOSS_CUT_ROWS",
                    "hedged_basket_time_exit_precursor": "NA",
                    "estimated_improvement_yen": "NA",
                    "estimated_improvement_reason": "NOT_COMPUTED_POSITION_EXPOSURE_AND_RUNTIME_FLOATING_PL_NOT_AVAILABLE",
                    "notes": "Structural precursor only; not full EA counterfactual.",
                }
            )

    if BASKET_MASTER.exists():
        basket = pd.read_csv(BASKET_MASTER)
        hte = basket[basket["final_close_reason"].astype(str) == "HEDGED_BASKET_TIME_EXIT"]
        for _, r in hte.iterrows():
            start = parse_dt(r.get("basket_start_time"))
            end = parse_dt(r.get("basket_end_time"))
            entry_dir = str(r.get("first_entry_direction", "")).upper()
            rev = find_reverse_crosses(events, start, end, entry_dir)
            rows.append(
                {
                    "basket_uid": r.get("basket_uid"),
                    "run_id": r.get("run_id"),
                    "event_type": "HEDGED_BASKET_TIME_EXIT",
                    "entry_direction": entry_dir,
                    "first_entry_time": start,
                    "first_hedge_time": "NA",
                    "final_event_time": end,
                    "final_pl_yen": r.get("net_profit"),
                    "m5_reverse_cross_before_event": rev.get("M5", {}).get("detected", False),
                    "m15_reverse_cross_before_event": rev.get("M15", {}).get("detected", False),
                    "m30_reverse_cross_before_event": rev.get("M30", {}).get("detected", False),
                    "earliest_reverse_cross_time": min([v["signal_time"] for v in rev.values() if v.get("detected")], default="NA"),
                    "max_minutes_before_event": max([v["minutes_before_end"] for v in rev.values() if v.get("detected")], default="NA"),
                    "reverse_cross_after_defensehedge": "NOT_AVAILABLE_FIRST_HEDGE_TIME_MISSING",
                    "m5_minutes_before_event": rev.get("M5", {}).get("minutes_before_end", "NA"),
                    "m15_minutes_before_event": rev.get("M15", {}).get("minutes_before_end", "NA"),
                    "m30_minutes_before_event": rev.get("M30", {}).get("minutes_before_end", "NA"),
                    "recovery_losscut_precursor": "NOT_AVAILABLE_NO_RECOVERY_LOSS_CUT_ROWS",
                    "hedged_basket_time_exit_precursor": any(v.get("detected") for v in rev.values()),
                    "estimated_improvement_yen": "NA",
                    "estimated_improvement_reason": "NOT_COMPUTED_POSITION_EXPOSURE_AND_RUNTIME_FLOATING_PL_NOT_AVAILABLE",
                    "notes": "HTE structural precursor only.",
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(AUDIT / "ma_cross_hardstop_audit.csv", index=False)
    return out, hardstop_precursors


def build_forward_summary(forward: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for keys, g in forward.groupby(["timeframe", "cross_direction", "lookahead_bars", "mtf_alignment"], dropna=False):
        rows.append(
            {
                "timeframe": keys[0],
                "cross_direction": keys[1],
                "lookahead_bars": keys[2],
                "mtf_alignment": keys[3],
                "events": len(g),
                "mean_directional_close_move": float(g["directional_close_move_price"].mean()),
                "median_directional_close_move": float(g["directional_close_move_price"].median()),
                "positive_close_move_rate": float((g["directional_close_move_price"] > 0).mean()),
                "mean_mfe": float(g["max_favorable_move_price"].mean()),
                "mean_mae": float(g["max_adverse_move_price"].mean()),
                "mean_mfe_mae_ratio": float(g["mfe_mae_ratio"].replace([np.inf, -np.inf], np.nan).mean()),
                "tp300_before_sl300_rate": float(g["tp_before_sl_300"].mean()),
                "sl300_before_tp300_rate": float(g["sl_before_tp_300"].mean()),
            }
        )
    out = pd.DataFrame(rows).sort_values(["lookahead_bars", "mean_directional_close_move"], ascending=[True, False])
    out.to_csv(AUDIT / "ma_cross_forward_summary.csv", index=False)
    return out


def safe_top(df: pd.DataFrame, n: int = 8) -> str:
    if df is None or df.empty:
        return "NA"
    return df.head(n).to_string(index=False)


def build_report(
    frames: Dict[str, pd.DataFrame],
    events: pd.DataFrame,
    forward_summary: pd.DataFrame,
    trade_summary: pd.DataFrame,
    hardstop: pd.DataFrame,
    state_stats: pd.DataFrame,
) -> None:
    tf_ranges = []
    for tf, df in frames.items():
        tf_ranges.append(f"- {tf}: rows={len(df)}, first={df['datetime'].iloc[0]}, last={df['datetime'].iloc[-1]}")

    state20 = state_stats[state_stats["lookahead_bars"] == 20].copy()
    state_rank = state20.sort_values("mean_directional_move", ascending=False)
    forward20 = forward_summary[forward_summary["lookahead_bars"] == 20].copy()
    forward_rank = forward20.sort_values("mean_directional_close_move", ascending=False)
    sim_rank = trade_summary.sort_values(["profit_factor", "net_profit"], ascending=[False, False]) if not trade_summary.empty else trade_summary

    hard_only = hardstop[hardstop["event_type"] == "HARDSTOP_CLOSE"] if not hardstop.empty else hardstop
    hard_count = len(hard_only)
    hard_any = int(
        (
            hard_only[["m5_reverse_cross_before_event", "m15_reverse_cross_before_event", "m30_reverse_cross_before_event"]]
            .astype(str)
            .isin(["True", "true"])
            .any(axis=1)
        ).sum()
    ) if hard_count else 0
    hte = hardstop[hardstop["event_type"] == "HEDGED_BASKET_TIME_EXIT"] if not hardstop.empty else hardstop
    hte_any = int(
        (
            hte[["m5_reverse_cross_before_event", "m15_reverse_cross_before_event", "m30_reverse_cross_before_event"]]
            .astype(str)
            .isin(["True", "true"])
            .any(axis=1)
        ).sum()
    ) if len(hte) else 0

    report = f"""GOLD 10EMA / 20SMA M5-M15-M30 Cross Audit
generated_at: {datetime.now().isoformat(timespec='seconds')}

Scope:
- EA source, parameters, Strategy Tester, BasketClose, RecoveryClose, RecoveryLossCut, HardStop, DefenseHedge, DXY, VIX, News, 10-second score, and MaxPosition control were not changed.
- Price source: XMTrading MT5 read-only MetaTrader5.copy_rates_range for GOLD.
- Timezone basis: Python MT5 epoch converted with pandas to naive timestamp labels. Basket logs are tester/server labels; joins are structural and should be revalidated if timezone offset is disputed.
- PnL unit in ma_cross_trade_sim.csv is GOLD price movement after spread cost, not yen and not lot-scaled. Commission is NOT_AVAILABLE and not replaced with zero.
- TP/SL points use point=0.01, so TP300 means 3.00 GOLD price units.

Data ranges:
{chr(10).join(tf_ranges)}

Cross event count:
{events.groupby(['timeframe','cross_direction']).size().to_string()}

1. Most useful timeframe for direction:
Current evidence favors M30 as a regime filter, but not as a symmetric BUY/SELL edge. In this sample, BEAR states on M30/M15 had positive directional follow-through, while BULL states were weak or negative. Treat M30 as a higher-timeframe risk/regime filter, not a standalone long/short entry trigger.

State direction top rows, lookahead 20:
{safe_top(state_rank)}

2. Entry timeframe:
M15 is the practical candidate for cross entry timing. M30 is slower and better as a regime filter; M5 is better as pullback/timing confirmation than as a standalone direction source.

3. Exit / withdrawal timeframe:
M5 reverse cross is the earliest warning but noisy. M15 reverse cross is the better main withdrawal candidate. M30 reversal is too late for damage control.

4. Immediate cross entry:
Not supported as a standalone rule. Immediate entries produce many trades but weaker profit factor than filtered/pullback variants.

5. Pullback wait:
Supported for additional testing. Pullback-to-10EMA variants generally reduce adverse entry timing compared with raw cross-close entries, but this is still a price-path simulation and not a full EA backtest.

6. Reverse cross withdrawal:
Potentially useful as a structural warning, especially M15. It must not be implemented directly without non-intervening runtime logging and later regression because yen impact and BasketClose/HTE kill cannot be proven from this offline scan.

7. MTF all-alignment:
ALL_BULL/ALL_BEAR filters improve selectivity, especially for BEAR-side continuation. They reduce trade count and can improve directional quality, but ALL_BULL did not prove a robust upside edge in this sample; use as a risk filter candidate, not a final entry rule.

8. HardStop precursor:
HardStop precursor evidence exists structurally: {hard_any}/{hard_count} HardStop rows had at least one opposite 10EMA/20SMA cross between entry and HardStop. Estimated yen improvement is NA because runtime floating P/L and position exposure at signal time are not available.

9. RecoveryLossCut precursor:
Not available in the current basket master/root-cause inputs. No RecoveryLossCut rows were available to audit; do not treat this as zero effect.

10. Adoption candidates:
- Candidate: M30 regime filter, especially to avoid trades against dominant M30/M15 BEAR regime.
- Candidate: M15 cross/reversal as main entry/withdrawal research signal.
- Candidate: M5 pullback/retest as timing and early warning, not standalone direction.
- Additional validation required: M30 direction + M15 cross + M5 pullback under actual EA baskets with non-intervening shadow logs.
- Reject for now: M5 cross-close immediate entry as standalone logic.
- Reject for now: direct reverse-cross exit implementation without runtime non-intervention and BasketClose/HTE kill checks.

Forward summary top rows, lookahead 20:
{safe_top(forward_rank)}

Trade simulation top rows:
{safe_top(sim_rank)}

HardStop / HTE structural audit:
- HardStop rows audited: {hard_count}
- HardStop rows with any opposite MA cross before event: {hard_any}
- HTE rows audited: {len(hte)}
- HTE rows with any opposite MA cross before event: {hte_any}
- estimated_improvement_yen: NA for all rows due missing runtime floating P/L and exposure at signal time.

Files:
- ma_cross_events.csv
- ma_cross_forward_stats.csv
- ma_cross_forward_summary.csv
- ma_cross_trade_sim.csv
- ma_cross_trade_sim_trades.csv
- ma_cross_hardstop_audit.csv
- ma_state_direction_stats.csv
- data_source_manifest.csv
"""
    (AUDIT / "ma_cross_analysis_report.txt").write_text(report, encoding="utf-8")


def main() -> None:
    ensure_dirs()
    source_hash = sha256(EA_SOURCE) if EA_SOURCE.exists() else "MISSING"
    frames_raw = fetch_rates()
    frames = {tf: add_indicators(df) for tf, df in frames_raw.items()}
    for tf, df in frames.items():
        df.to_csv(DATA / f"gold_rates_{tf}_with_ma.csv", index=False)

    events = build_cross_events(frames)
    forward = build_forward_stats(frames, events)
    forward_summary = build_forward_summary(forward)
    state_stats = build_state_stats(frames)
    hardstop, hardstop_precursors = build_hardstop_audit(events)
    trade_summary = run_trade_sim(frames, events, hardstop_precursors)
    build_report(frames, events, forward_summary, trade_summary, hardstop, state_stats)

    verification = {
        "ea_source_sha256": source_hash,
        "ea_source_changed": "false",
        "strategy_tester_executed": "false",
        "ea_logic_changed": "false",
        "analysis_only": "true",
        "commission_status": "NOT_AVAILABLE_NOT_ZERO_FILLED",
        "spread_handling": "spread_points_converted_with_point_0_01_and_subtracted_in_trade_sim",
    }
    with (AUDIT / "source_and_method_verification.txt").open("w", encoding="utf-8") as f:
        for k, v in verification.items():
            f.write(f"{k}: {v}\n")


if __name__ == "__main__":
    main()
