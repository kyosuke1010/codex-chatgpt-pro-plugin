﻿param([string]$Pattern = 'ALL')

$ErrorActionPreference = 'Stop'
$Workspace = 'C:\Users\user\Documents\New project'
$AuditRoot = Join-Path $Workspace 'KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT'
$TerminalExe = 'C:\Program Files\XMTrading MT5\terminal64.exe'
$TerminalData = 'C:\Users\user\AppData\Roaming\MetaQuotes\Terminal\2FA8A7E69CED7DC259B1AD86A247F675'
$TesterRoot = 'C:\Users\user\AppData\Roaming\MetaQuotes\Tester\2FA8A7E69CED7DC259B1AD86A247F675'
$AgentRoot = Join-Path $TesterRoot 'Agent-127.0.0.1-3000'
$AgentFiles = Join-Path $AgentRoot 'MQL5\Files'
$StatusPath = Join-Path $AuditRoot 'regression_run_status.csv'
$ManifestPath = Join-Path $AuditRoot 'regression_execution_manifest.csv'
$ExpectedSourceSha = 'E57BE0039E54FA605ADAFE582B4B273381059166C9964000FFBFC033DE40F03A'
$ExpectedEx5Sha = '49B3140292F614723D37FB8B8AF3DABAA83AD4A61C15FD328E9A201D7C9A6CDB'
$TerminalSource = Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5'
$TerminalEx5 = Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.ex5'

function CsvLine($values) {
    return (($values | ForEach-Object { '"' + ([string]$_ -replace '"','""') + '"' }) -join ',')
}

function Sha256($path) {
    if(!(Test-Path -LiteralPath $path)) { return 'MISSING' }
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Add-RunStatus {
    param($TestName,$Series,$RunGroupId,$Phase,$StartTime,$EndTime,$ExitCode,$IniPath,$Note)
    $elapsed = ''
    if($StartTime -and $EndTime) { $elapsed = [int]($EndTime - $StartTime).TotalSeconds }
    Add-Content -LiteralPath $StatusPath -Encoding UTF8 -Value (CsvLine @($TestName,$Series,$RunGroupId,$Phase,$StartTime.ToString('s'),$EndTime.ToString('s'),$elapsed,$ExitCode,$IniPath,$Note))
}

function Stop-TestProcesses {
    Get-CimInstance Win32_Process |
        Where-Object { $_.Name -match 'terminal64|metatester64' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function Get-AgentLogPath {
    return (Join-Path $AgentRoot ("logs\" + (Get-Date -Format 'yyyyMMdd') + ".log"))
}

function Get-TerminalLogPath {
    return (Join-Path $TerminalData ("logs\" + (Get-Date -Format 'yyyyMMdd') + ".log"))
}

function Get-ExpertsLogPath {
    return (Join-Path $TerminalData ("MQL5\Logs\" + (Get-Date -Format 'yyyyMMdd') + ".log"))
}

function Read-NewLines {
    param($Path,$FromLine)
    if(!(Test-Path -LiteralPath $Path)) { return @() }
    $lines = @(Get-Content -LiteralPath $Path)
    if($lines.Count -le $FromLine) { return @() }
    return @($lines[$FromLine..($lines.Count - 1)])
}

function Snapshot-AgentFiles {
    param($Destination)
    if(Test-Path -LiteralPath $AgentFiles) {
        Get-ChildItem -LiteralPath $AgentFiles -File -ErrorAction SilentlyContinue |
            Select-Object FullName,Name,Length,LastWriteTime |
            Export-Csv -LiteralPath $Destination -NoTypeInformation -Encoding UTF8
    } else {
        'FullName,Name,Length,LastWriteTime' | Set-Content -LiteralPath $Destination -Encoding UTF8
    }
}

function Backup-And-Clear-AgentOutputs {
    param($TestName)
    $backupDir = Join-Path (Join-Path $AuditRoot 'output_listings') ($TestName + '_stale_before')
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $patterns = @(
        'KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv',
        'KOUCHA_GOLD_ENTRY_OPPORTUNITY_AUDIT.csv',
        'KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK_LOG.csv',
        'KOUCHA_GOLD_ENTRY_DECISION_TRACE.csv',
        'KOUCHA_GOLD_REACTIVE_HEDGE_ELIGIBILITY_TRACE.csv',
        'KOUCHA_GOLD_PERFORMANCE_STATS.csv',
        'KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv',
        'KOUCHA_ML_SHADOW*.csv'
    )
    $items = @()
    foreach($pattern in $patterns) {
        $items += @(Get-ChildItem -LiteralPath $AgentFiles -Filter $pattern -File -ErrorAction SilentlyContinue)
    }
    $items = $items | Sort-Object FullName -Unique
    $manifest = @('original_path,backup_path,size,last_write_time,sha256,action')
    foreach($item in $items) {
        $dst = Join-Path $backupDir $item.Name
        Copy-Item -LiteralPath $item.FullName -Destination $dst -Force
        $manifest += CsvLine @($item.FullName,$dst,$item.Length,$item.LastWriteTime.ToString('s'),(Sha256 $dst),'BACKED_UP_THEN_REMOVED_FROM_AGENT_FILES')
        Remove-Item -LiteralPath $item.FullName -Force
    }
    $manifest | Set-Content -LiteralPath (Join-Path $backupDir 'stale_output_manifest.csv') -Encoding UTF8
}

function Copy-IfExists {
    param($Source,$Destination)
    if(Test-Path -LiteralPath $Source) {
        Copy-Item -LiteralPath $Source -Destination $Destination -Force
        return $true
    }
    return $false
}

function Copy-RunOutputs {
    param($Test)
    $testName = $Test.TestName
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv') -Destination (Join-Path (Join-Path $AuditRoot 'trade_exports') ($testName + '_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv')) | Out-Null
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_PERFORMANCE_STATS.csv') -Destination (Join-Path (Join-Path $AuditRoot 'trade_exports') ($testName + '_KOUCHA_GOLD_PERFORMANCE_STATS.csv')) | Out-Null
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK_LOG.csv') -Destination (Join-Path (Join-Path $AuditRoot 'expert_logs') ($testName + '_KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK_LOG.csv')) | Out-Null
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv') -Destination (Join-Path (Join-Path $AuditRoot 'evidence') ($testName + '_KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv')) | Out-Null
    foreach($shadow in Get-ChildItem -LiteralPath $AgentFiles -Filter 'KOUCHA_ML_SHADOW*.csv' -File -ErrorAction SilentlyContinue) {
        Copy-Item -LiteralPath $shadow.FullName -Destination (Join-Path (Join-Path $AuditRoot 'shadow_logs') ($testName + '_' + $shadow.Name)) -Force
    }
    Copy-IfExists -Source (Get-AgentLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'agent_logs') ($testName + '_agent_full.log')) | Out-Null
    Copy-IfExists -Source (Get-TerminalLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'journals') ($testName + '_terminal_full.log')) | Out-Null
    Copy-IfExists -Source (Get-ExpertsLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'expert_logs') ($testName + '_experts_full.log')) | Out-Null
}

$sourceSha = Sha256 $TerminalSource
$ex5Sha = Sha256 $TerminalEx5
if($sourceSha -ne $ExpectedSourceSha) { throw "Terminal source SHA mismatch: $sourceSha" }
if($ex5Sha -ne $ExpectedEx5Sha) { throw "Terminal EX5 SHA mismatch: $ex5Sha" }
if(!(Test-Path -LiteralPath $ManifestPath)) { throw "Execution manifest missing: $ManifestPath" }
if(!(Test-Path -LiteralPath $TerminalExe)) { throw "Terminal executable missing: $TerminalExe" }

$manifest = Import-Csv -LiteralPath $ManifestPath
if($Pattern -ne 'ALL') {
    $manifest = $manifest | Where-Object { $_.TestName -like "*$Pattern*" -or $_.PairId -eq $Pattern -or $_.Series -eq $Pattern }
}

foreach($test in $manifest) {
    Stop-TestProcesses
    Start-Sleep -Seconds 3
    $start = Get-Date
    Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'START' -StartTime $start -EndTime $start -ExitCode '' -IniPath $test.Ini -Note 'starting terminal strategy tester run'
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_before.csv'))
    Backup-And-Clear-AgentOutputs -TestName $test.TestName
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_after_clear.csv'))

    $agentLog = Get-AgentLogPath
    $agentStartLine = if(Test-Path -LiteralPath $agentLog) { @(Get-Content -LiteralPath $agentLog).Count } else { 0 }
    $terminalLog = Get-TerminalLogPath
    $terminalStartLine = if(Test-Path -LiteralPath $terminalLog) { @(Get-Content -LiteralPath $terminalLog).Count } else { 0 }
    $expertsLog = Get-ExpertsLogPath
    $expertsStartLine = if(Test-Path -LiteralPath $expertsLog) { @(Get-Content -LiteralPath $expertsLog).Count } else { 0 }

    $proc = Start-Process -FilePath $TerminalExe -ArgumentList "/config:`"$($test.Ini)`"" -WindowStyle Hidden -PassThru
    $expectedInitial = "initial deposit $($test.Deposit) JPY, leverage 1:888"
    $initialLine = ''
    $preflightOk = $false
    for($i = 0; $i -lt 450; $i++) {
        Start-Sleep -Seconds 2
        $newLines = Read-NewLines -Path $agentLog -FromLine $agentStartLine
        $initialLine = ($newLines | Select-String -Pattern 'initial deposit' | Select-Object -First 1).Line
        if($initialLine) {
            if($initialLine -match [regex]::Escape($expectedInitial)) { $preflightOk = $true }
            break
        }
        if($proc.HasExited) { break }
    }
    if(!$preflightOk) {
        $endFail = Get-Date
        Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'PREFLIGHT_FAIL' -StartTime $start -EndTime $endFail -ExitCode '' -IniPath $test.Ini -Note $initialLine
        if(!$proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
        Copy-RunOutputs -Test $test
        (Read-NewLines -Path $agentLog -FromLine $agentStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'agent_logs') ($test.TestName + '_agent_window.log')) -Encoding UTF8
        continue
    }
    Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'PREFLIGHT_OK' -StartTime $start -EndTime (Get-Date) -ExitCode '' -IniPath $test.Ini -Note $initialLine

    $timeoutSeconds = 10800
    $lastHeartbeat = Get-Date
    $completedByLog = $false
    while(!$proc.HasExited) {
        Start-Sleep -Seconds 10
        $now = Get-Date
        if(($now - $lastHeartbeat).TotalSeconds -ge 60) {
            $heartbeatLines = Read-NewLines -Path $agentLog -FromLine $agentStartLine
            $lastAgent = ($heartbeatLines | Select-Object -Last 1)
            Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'HEARTBEAT' -StartTime $start -EndTime $now -ExitCode '' -IniPath $test.Ini -Note $lastAgent
            $lastHeartbeat = $now
        }
        $runLines = Read-NewLines -Path $agentLog -FromLine $agentStartLine
        if($runLines -match 'tester stopped|MetaTester 5 stopped|shutdown finished|thread finished') {
            $completedByLog = $true
        }
        if(($now - $start).TotalSeconds -gt $timeoutSeconds) {
            Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'TIMEOUT' -StartTime $start -EndTime $now -ExitCode '' -IniPath $test.Ini -Note 'timeout 10800 seconds'
            Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
            break
        }
    }
    $end = Get-Date
    $exitCode = ''
    try { $exitCode = $proc.ExitCode } catch {}
    $phase = if($completedByLog -or $proc.HasExited) { 'END' } else { 'END_UNKNOWN' }
    Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase $phase -StartTime $start -EndTime $end -ExitCode $exitCode -IniPath $test.Ini -Note ($(if($completedByLog){'completion marker observed'}else{'process exited or was stopped'}))

    Copy-RunOutputs -Test $test
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_after.csv'))
    (Read-NewLines -Path $agentLog -FromLine $agentStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'agent_logs') ($test.TestName + '_agent_window.log')) -Encoding UTF8
    (Read-NewLines -Path $terminalLog -FromLine $terminalStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'journals') ($test.TestName + '_terminal_window.log')) -Encoding UTF8
    (Read-NewLines -Path $expertsLog -FromLine $expertsStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'expert_logs') ($test.TestName + '_experts_window.log')) -Encoding UTF8
}

Stop-TestProcesses
Write-Host "Finished Multilayer Phase1 regression restart runs in $AuditRoot"


