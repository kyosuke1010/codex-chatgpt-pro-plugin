﻿import csv
import hashlib
import json
import math
import os
from collections import Counter, defaultdict
from pathlib import Path

WORKSPACE = Path(r"C:\Users\user\Documents\New project")
AUDIT = WORKSPACE / "KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT"
RUNTIME = WORKSPACE / "KOUCHA_GOLD_TA9_SHADOW_RUNTIME_REGRESSION_AUDIT"

CANONICAL_FIELDS = [
    "TesterTime",
    "ServerTime",
    "EventType",
    "Symbol",
    "Retcode",
    "RetcodeDescription",
    "Comment",
    "Bid",
    "Ask",
    "SpreadPrice",
    "OrderDirection",
    "OrderLots",
    "OrderPrice",
    "ClosePrice",
    "ProfitYen",
    "BasketNetProfitYen",
    "Balance",
    "Equity",
    "LastStopReason",
    "Signal",
    "FirstDefenseHedgeTime",
    "NewsBlockActive",
    "TechnicalDangerBlockActive",
    "HardStopAfterMode",
]

ML_REQUIRED_COLUMNS = [
    "schema_version",
    "build_id",
    "run_id",
    "event_sequence",
    "event_type",
    "module_name",
    "root_snapshot_id",
    "basket_uid",
    "symbol",
    "period",
    "server_time",
    "server_time_msc",
    "tick_sequence_id",
    "eval_cycle_sequence",
    "eval_stage",
    "lifecycle_state",
    "hedge_state",
    "entry_state",
    "distance_to_hardstop_yen",
    "hardstop_now_runtime",
    "hardstop_now_snapshot",
    "logger_state",
    "current_HTE_eligibility",
    "current_Recovery_eligibility",
    "current_BasketClose_eligibility",
    "event_calendar_available",
    "high_impact_usd_event_window_state",
    "ma_retest_state",
    "detail",
]

ROOTLESS_ALLOWED = {
    "MULTILAYER_BASKET_SUMMARY",
    "MULTILAYER_RUN_SUMMARY",
    "MULTILAYER_LOGGER_HEALTH",
    "MULTILAYER_PARITY_ERROR",
}

def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})

def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest().upper()

def sha256_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()

def canonicalize_trade(path):
    rows = read_csv(path)
    canon_lines = []
    raw_h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            raw_h.update(chunk)
    event_counter = Counter()
    close_counter = Counter()
    shadow_origin_rows = 0
    final_balance = "NA"
    final_equity = "NA"
    for i, row in enumerate(rows, start=1):
        et = row.get("EventType", "")
        event_counter[et] += 1
        od = row.get("OrderDirection", "")
        is_close = ("CLOSE" in et and not et.startswith("AFTER_CLOSE")) or od.endswith("_CLOSE")
        if is_close:
            close_counter[et] += 1
        if row.get("Balance", "") not in ("", "NA"):
            final_balance = row.get("Balance", "")
        if row.get("Equity", "") not in ("", "NA"):
            final_equity = row.get("Equity", "")
        joined = "|".join(str(row.get(k, "")) for k in CANONICAL_FIELDS)
        canon_lines.append(joined)
        lower_joined = json.dumps(row, ensure_ascii=False).lower()
        if "multilayer" in lower_joined or "ml_shadow" in lower_joined or "koucha_ml_shadow" in lower_joined:
            shadow_origin_rows += 1
    canonical_hash = sha256_text("\n".join(canon_lines))
    return {
        "path": str(path),
        "exists": True,
        "row_count": len(rows),
        "raw_sha256": raw_h.hexdigest().upper(),
        "canonical_sha256": canonical_hash,
        "entry_count": event_counter.get("ENTRY_BUY", 0) + event_counter.get("ENTRY_SELL", 0),
        "close_count": sum(close_counter.values()),
        "order_count_proxy": sum(1 for r in rows if r.get("Retcode", "") not in ("", "0")),
        "deal_count_proxy": sum(1 for r in rows if r.get("Retcode", "") not in ("", "0")),
        "basket_count_proxy": sum(close_counter.values()),
        "hardstop_count": sum(v for k, v in event_counter.items() if "HARDSTOP" in k.upper()),
        "hte_count": sum(v for k, v in event_counter.items() if "HEDGED_BASKET_TIME_EXIT" in k.upper() or k.upper() == "HTE"),
        "recovery_count": sum(v for k, v in event_counter.items() if "RECOVERY" in k.upper()),
        "basketclose_count": event_counter.get("BASKET_CLOSE", 0),
        "final_balance": final_balance,
        "final_equity": final_equity,
        "close_reason_fingerprint": sha256_text(json.dumps(dict(sorted(close_counter.items())), sort_keys=True)),
        "close_reason_counts": dict(close_counter),
        "shadow_origin_rows": shadow_origin_rows,
    }

def missing_trade(path):
    return {
        "path": str(path),
        "exists": False,
        "row_count": 0,
        "raw_sha256": "MISSING",
        "canonical_sha256": "MISSING",
        "entry_count": "MISSING",
        "close_count": "MISSING",
        "order_count_proxy": "MISSING",
        "deal_count_proxy": "MISSING",
        "basket_count_proxy": "MISSING",
        "hardstop_count": "MISSING",
        "hte_count": "MISSING",
        "recovery_count": "MISSING",
        "basketclose_count": "MISSING",
        "final_balance": "MISSING",
        "final_equity": "MISSING",
        "close_reason_fingerprint": "MISSING",
        "close_reason_counts": {},
        "shadow_origin_rows": "MISSING",
    }

def compare_metrics(left_name, left, right_name, right):
    checks = [
        "row_count",
        "canonical_sha256",
        "entry_count",
        "close_count",
        "order_count_proxy",
        "deal_count_proxy",
        "basket_count_proxy",
        "hardstop_count",
        "hte_count",
        "recovery_count",
        "basketclose_count",
        "final_balance",
        "final_equity",
        "close_reason_fingerprint",
    ]
    diffs = []
    for key in checks:
        if str(left.get(key)) != str(right.get(key)):
            diffs.append(key)
    return {
        "comparison": f"{left_name}_vs_{right_name}",
        "pass": len(diffs) == 0,
        "diff_fields": ";".join(diffs),
        "left_canonical_sha256": left.get("canonical_sha256", ""),
        "right_canonical_sha256": right.get("canonical_sha256", ""),
        "left_final_balance": left.get("final_balance", ""),
        "right_final_balance": right.get("final_balance", ""),
    }

def find_reference_trade(pair_id):
    d = RUNTIME / f"TA9_A_FRESH_BASELINE_{pair_id}"
    f = d / f"TA9_A_FRESH_BASELINE_{pair_id}_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv"
    return f

def find_run_trade(test_name):
    return AUDIT / "trade_exports" / f"{test_name}_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv"

def validate_shadow_file(path):
    result = {
        "file": str(path),
        "sha256": sha256_file(path),
        "row_count": 0,
        "schema_missing_count": 0,
        "schema_versions": "",
        "run_id_missing_count": 0,
        "root_snapshot_id_missing_count": 0,
        "basket_uid_missing_count": 0,
        "event_sequence_duplicate_count": 0,
        "event_sequence_regression_count": 0,
        "duplicate_root_snapshot_body_count": 0,
        "orphan_module_row_count": 0,
        "malformed_row_count": 0,
        "nan_inf_count": 0,
        "unknown_false_conversion_count": 0,
        "unknown_zero_conversion_count": 0,
        "invalid_enum_count": 0,
        "logger_open_error_count": 0,
        "logger_write_error_count": 0,
        "dropped_row_count": 0,
        "root_snapshot_count": 0,
        "basket_summary_count": 0,
        "run_summary_count": 0,
        "prehedge_shadow_event_count": 0,
        "hedge_transition_event_count": 0,
        "event_risk_event_count": 0,
        "ma_retest_event_count": 0,
        "event_risk_unknown_count": 0,
        "ma_retest_unknown_count": 0,
        "hte_eligibility_unknown_count": 0,
        "recovery_eligibility_unknown_count": 0,
        "basketclose_eligibility_unknown_count": 0,
        "joinable_module_row_count": 0,
        "module_row_count": 0,
    }
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            header = reader.fieldnames or []
            missing = [c for c in ML_REQUIRED_COLUMNS if c not in header]
            result["schema_missing_count"] = len(missing)
            versions = set()
            seq_seen = set()
            last_seq = None
            roots = set()
            root_bodies = set()
            rows = []
            for row in reader:
                rows.append(row)
    except Exception:
        result["malformed_row_count"] += 1
        return result
    result["row_count"] = len(rows)
    for row in rows:
        et = row.get("event_type", "")
        mod = row.get("module_name", "")
        rid = row.get("root_snapshot_id", "")
        seq_raw = row.get("event_sequence", "")
        versions.add(row.get("schema_version", ""))
        if not row.get("run_id", ""):
            result["run_id_missing_count"] += 1
        if not rid:
            result["root_snapshot_id_missing_count"] += 1
        if not row.get("basket_uid", "") and et != "MULTILAYER_RUN_SUMMARY":
            result["basket_uid_missing_count"] += 1
        try:
            seq = int(seq_raw)
            if seq in seq_seen:
                result["event_sequence_duplicate_count"] += 1
            seq_seen.add(seq)
            if last_seq is not None and seq < last_seq:
                result["event_sequence_regression_count"] += 1
            last_seq = seq
        except Exception:
            result["invalid_enum_count"] += 1
        for v in row.values():
            sv = str(v)
            if sv.lower() in ("nan", "inf", "+inf", "-inf", "infinity", "-infinity"):
                result["nan_inf_count"] += 1
        if et == "MULTILAYER_ROOT_SNAPSHOT":
            result["root_snapshot_count"] += 1
            roots.add(rid)
            body = tuple((k, row.get(k, "")) for k in sorted(row.keys()) if k != "event_sequence")
            if body in root_bodies:
                result["duplicate_root_snapshot_body_count"] += 1
            root_bodies.add(body)
        if et == "MULTILAYER_BASKET_SUMMARY":
            result["basket_summary_count"] += 1
        if et == "MULTILAYER_RUN_SUMMARY":
            result["run_summary_count"] += 1
        if mod == "PRE_HEDGE_RISK_SHADOW":
            result["prehedge_shadow_event_count"] += 1
        if mod == "HEDGE_TRANSITION_SHADOW":
            result["hedge_transition_event_count"] += 1
        if mod == "EVENT_RISK_MINIMAL_SHADOW":
            result["event_risk_event_count"] += 1
        if mod == "MA_RETEST_SHADOW":
            result["ma_retest_event_count"] += 1
        if row.get("high_impact_usd_event_window_state", "") == "UNKNOWN" or row.get("event_calendar_available", "") == "UNKNOWN":
            result["event_risk_unknown_count"] += 1
        if row.get("ma_retest_state", "") == "UNKNOWN":
            result["ma_retest_unknown_count"] += 1
        if row.get("current_HTE_eligibility", "") == "UNKNOWN":
            result["hte_eligibility_unknown_count"] += 1
        if row.get("current_Recovery_eligibility", "") == "UNKNOWN":
            result["recovery_eligibility_unknown_count"] += 1
        if row.get("current_BasketClose_eligibility", "") == "UNKNOWN":
            result["basketclose_eligibility_unknown_count"] += 1
        detail = row.get("detail", "")
        if "logger_open_errors=" in detail:
            result["logger_open_error_count"] += extract_detail_int(detail, "logger_open_errors")
        if "logger_write_errors=" in detail:
            result["logger_write_error_count"] += extract_detail_int(detail, "logger_write_errors")
        if "dropped_rows=" in detail:
            result["dropped_row_count"] += extract_detail_int(detail, "dropped_rows")
        if "UNKNOWN=false" in json.dumps(row) or "UNKNOWN=FALSE" in json.dumps(row):
            result["unknown_false_conversion_count"] += 1
        if "UNKNOWN=0" in json.dumps(row):
            result["unknown_zero_conversion_count"] += 1
        if et not in ("MULTILAYER_ROOT_SNAPSHOT",) and et not in ROOTLESS_ALLOWED:
            result["module_row_count"] += 1
    for row in rows:
        et = row.get("event_type", "")
        rid = row.get("root_snapshot_id", "")
        if et not in ("MULTILAYER_ROOT_SNAPSHOT",) and et not in ROOTLESS_ALLOWED:
            if rid in roots:
                result["joinable_module_row_count"] += 1
            else:
                result["orphan_module_row_count"] += 1
    result["schema_versions"] = ";".join(sorted(versions))
    return result

def extract_detail_int(detail, key):
    for part in str(detail).split("|"):
        if part.startswith(key + "="):
            try:
                return int(float(part.split("=", 1)[1]))
            except Exception:
                return 0
    return 0

def main():
    manifest = read_csv(AUDIT / "regression_execution_manifest.csv")
    by_pair = defaultdict(dict)
    metrics_rows = []
    comparisons = []
    close_rows = []
    shadow_audit_rows = []
    csv_presence_rows = []
    for m in manifest:
        test_name = m["TestName"]
        pair_id = m["PairId"]
        series = m["Series"]
        path = find_run_trade(test_name)
        metrics = canonicalize_trade(path) if path.exists() else missing_trade(path)
        by_pair[pair_id][series] = metrics
        metrics_rows.append({
            "run_id": test_name,
            "series": series,
            "pair_id": pair_id,
            **{k: v for k, v in metrics.items() if k != "close_reason_counts"},
        })
        close_rows.append({
            "run_id": test_name,
            "series": series,
            "pair_id": pair_id,
            "close_reason_counts_json": json.dumps(metrics["close_reason_counts"], sort_keys=True, ensure_ascii=False),
            "close_reason_fingerprint": metrics["close_reason_fingerprint"],
        })
        shadow_audit_rows.append({
            "run_id": test_name,
            "series": series,
            "shadow_origin_order_count": metrics["shadow_origin_rows"],
            "shadow_origin_deal_count": metrics["shadow_origin_rows"],
            "shadow_origin_close_count": metrics["shadow_origin_rows"],
            "evidence": metrics["path"],
        })
        shadow_files = sorted((AUDIT / "shadow_logs").glob(test_name + "_KOUCHA_ML_SHADOW*.csv"))
        csv_presence_rows.append({
            "run_id": test_name,
            "series": series,
            "shadow_csv_count": len(shadow_files),
            "shadow_csv_paths": ";".join(str(p) for p in shadow_files),
            "expected": "0" if series == "B" else ">=1",
            "status": "OK" if ((series == "B" and len(shadow_files) == 0) or (series == "C" and len(shadow_files) >= 1)) else "NG",
        })
    for pair_id, series_map in sorted(by_pair.items()):
        ref_path = find_reference_trade(pair_id)
        ref = canonicalize_trade(ref_path) if ref_path.exists() else missing_trade(ref_path)
        b = series_map.get("B", missing_trade(Path("MISSING_B")))
        c = series_map.get("C", missing_trade(Path("MISSING_C")))
        for comp in [
            ("A_REFERENCE", ref, "B", b),
            ("B", b, "C", c),
            ("A_REFERENCE", ref, "C", c),
        ]:
            row = compare_metrics(*comp)
            row["pair_id"] = pair_id
            row["left_path"] = comp[1]["path"]
            row["right_path"] = comp[3]["path"]
            comparisons.append(row)
    write_csv(AUDIT / "trade_fingerprint_compare.csv", comparisons, [
        "pair_id","comparison","pass","diff_fields","left_canonical_sha256","right_canonical_sha256","left_final_balance","right_final_balance","left_path","right_path"
    ])
    write_csv(AUDIT / "canonical" / "trade_event_metrics.csv", metrics_rows, [
        "run_id","series","pair_id","path","exists","row_count","raw_sha256","canonical_sha256","entry_count","close_count","order_count_proxy","deal_count_proxy","basket_count_proxy","hardstop_count","hte_count","recovery_count","basketclose_count","final_balance","final_equity","close_reason_fingerprint","shadow_origin_rows"
    ])
    write_csv(AUDIT / "close_reason_compare.csv", close_rows, [
        "run_id","series","pair_id","close_reason_counts_json","close_reason_fingerprint"
    ])
    write_csv(AUDIT / "basket_outcome_compare.csv", comparisons, [
        "pair_id","comparison","pass","diff_fields","left_final_balance","right_final_balance","left_path","right_path"
    ])
    write_csv(AUDIT / "shadow_origin_order_audit.csv", shadow_audit_rows, [
        "run_id","series","shadow_origin_order_count","shadow_origin_deal_count","shadow_origin_close_count","evidence"
    ])
    write_csv(AUDIT / "shadow_off_on_csv_presence.csv", csv_presence_rows, [
        "run_id","series","shadow_csv_count","shadow_csv_paths","expected","status"
    ])

    schema_rows = []
    root_rows = []
    basket_rows = []
    run_rows = []
    coverage_rows = []
    sample_written = False
    for m in manifest:
        test_name = m["TestName"]
        if m["Series"] != "C":
            continue
        shadow_files = sorted((AUDIT / "shadow_logs").glob(test_name + "_KOUCHA_ML_SHADOW*.csv"))
        aggregate = Counter()
        for sf in shadow_files:
            v = validate_shadow_file(sf)
            schema_rows.append({
                "run_id": test_name,
                **v,
            })
            for k, val in v.items():
                if isinstance(val, int):
                    aggregate[k] += val
            if not sample_written:
                with sf.open("r", encoding="utf-8-sig", newline="") as f:
                    sample = []
                    for i, line in enumerate(f):
                        sample.append(line.rstrip("\n"))
                        if i >= 20:
                            break
                (AUDIT / "sample_multilayer_shadow_log.csv").write_text("\n".join(sample) + "\n", encoding="utf-8")
                sample_written = True
        root_rows.append({
            "run_id": test_name,
            "root_snapshot_count": aggregate["root_snapshot_count"],
            "duplicate_root_snapshot_count": aggregate["duplicate_root_snapshot_body_count"],
            "orphan_module_row_count": aggregate["orphan_module_row_count"],
            "joinable_module_row_count": aggregate["joinable_module_row_count"],
            "module_row_count": aggregate["module_row_count"],
            "join_rate": (aggregate["joinable_module_row_count"] / aggregate["module_row_count"]) if aggregate["module_row_count"] else "NA",
        })
        basket_rows.append({
            "run_id": test_name,
            "basket_summary_count": aggregate["basket_summary_count"],
            "basket_summary_duplicate_count": 0,
            "status": "OK" if aggregate["basket_summary_count"] > 0 else "NG",
        })
        run_rows.append({
            "run_id": test_name,
            "run_summary_count": aggregate["run_summary_count"],
            "status": "OK" if aggregate["run_summary_count"] >= 1 else "NG",
        })
        total_rows = aggregate["row_count"]
        coverage_rows.append({
            "run_id": test_name,
            "root_snapshot_count": aggregate["root_snapshot_count"],
            "prehedge_shadow_event_count": aggregate["prehedge_shadow_event_count"],
            "hedge_transition_event_count": aggregate["hedge_transition_event_count"],
            "ma_retest_event_count": aggregate["ma_retest_event_count"],
            "event_risk_event_count": aggregate["event_risk_event_count"],
            "basket_summary_count": aggregate["basket_summary_count"],
            "run_summary_count": aggregate["run_summary_count"],
            "event_risk_unknown_rate": (aggregate["event_risk_unknown_count"] / total_rows) if total_rows else "NA",
            "ma_retest_unknown_rate": (aggregate["ma_retest_unknown_count"] / total_rows) if total_rows else "NA",
            "hte_eligibility_unknown_rate": (aggregate["hte_eligibility_unknown_count"] / total_rows) if total_rows else "NA",
            "recovery_eligibility_unknown_rate": (aggregate["recovery_eligibility_unknown_count"] / total_rows) if total_rows else "NA",
            "basketclose_eligibility_unknown_rate": (aggregate["basketclose_eligibility_unknown_count"] / total_rows) if total_rows else "NA",
        })
    schema_fields = [
        "run_id","file","sha256","row_count","schema_missing_count","schema_versions","run_id_missing_count","root_snapshot_id_missing_count","basket_uid_missing_count","event_sequence_duplicate_count","event_sequence_regression_count","duplicate_root_snapshot_body_count","orphan_module_row_count","malformed_row_count","nan_inf_count","unknown_false_conversion_count","unknown_zero_conversion_count","invalid_enum_count","logger_open_error_count","logger_write_error_count","dropped_row_count","root_snapshot_count","basket_summary_count","run_summary_count","prehedge_shadow_event_count","hedge_transition_event_count","event_risk_event_count","ma_retest_event_count","event_risk_unknown_count","ma_retest_unknown_count","hte_eligibility_unknown_count","recovery_eligibility_unknown_count","basketclose_eligibility_unknown_count","joinable_module_row_count","module_row_count"
    ]
    write_csv(AUDIT / "multilayer_shadow_schema_validation.csv", schema_rows, schema_fields)
    write_csv(AUDIT / "root_snapshot_integrity_check.csv", root_rows, [
        "run_id","root_snapshot_count","duplicate_root_snapshot_count","orphan_module_row_count","joinable_module_row_count","module_row_count","join_rate"
    ])
    write_csv(AUDIT / "basket_summary_validation.csv", basket_rows, [
        "run_id","basket_summary_count","basket_summary_duplicate_count","status"
    ])
    write_csv(AUDIT / "run_summary_validation.csv", run_rows, [
        "run_id","run_summary_count","status"
    ])
    write_csv(AUDIT / "multilayer_shadow_coverage_summary.csv", coverage_rows, [
        "run_id","root_snapshot_count","prehedge_shadow_event_count","hedge_transition_event_count","ma_retest_event_count","event_risk_event_count","basket_summary_count","run_summary_count","event_risk_unknown_rate","ma_retest_unknown_rate","hte_eligibility_unknown_rate","recovery_eligibility_unknown_rate","basketclose_eligibility_unknown_rate"
    ])
    for name, field in [
        ("multilayer_event_risk_coverage_summary.csv", "event_risk_event_count"),
        ("multilayer_ma_retest_coverage_summary.csv", "ma_retest_event_count"),
        ("multilayer_prehedge_risk_coverage_summary.csv", "prehedge_shadow_event_count"),
        ("multilayer_hedge_transition_coverage_summary.csv", "hedge_transition_event_count"),
    ]:
        write_csv(AUDIT / name, [
            {"run_id": row["run_id"], "event_count": row[field]} for row in coverage_rows
        ], ["run_id","event_count"])

    # Effective input compare from generated configs.
    input_rows = []
    keys = [
        "EnableTA9ShadowLogging",
        "EnableMultilayerShadowLogging",
        "MultilayerShadowLogLevel",
        "EnableEventRiskMinimalShadow",
        "MultilayerShadowFlushMode",
        "MultilayerShadowMaxRowsPerRun",
        "MultilayerShadowFilePrefix",
    ]
    by_pair_cfg = defaultdict(dict)
    for m in manifest:
        by_pair_cfg[m["PairId"]][m["Series"]] = m
    for pair_id, sm in sorted(by_pair_cfg.items()):
        vals = {}
        for series in ("B","C"):
            cfg = Path(sm[series]["Ini"])
            text = cfg.read_text(encoding="utf-16")
            vals[series] = {}
            for line in text.splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    if k in keys:
                        vals[series][k] = v.split("||", 1)[0]
        for k in keys:
            input_rows.append({
                "pair_id": pair_id,
                "input_name": k,
                "B_value": vals["B"].get(k, ""),
                "C_value": vals["C"].get(k, ""),
                "status": "OK_ALLOWED_DIFF" if k == "EnableMultilayerShadowLogging" and vals["B"].get(k) != vals["C"].get(k) else ("OK" if vals["B"].get(k) == vals["C"].get(k) else "NG"),
            })
    write_csv(AUDIT / "input_effective_compare.csv", input_rows, [
        "pair_id","input_name","B_value","C_value","status"
    ])

    completed_status = read_csv(AUDIT / "regression_run_status.csv")
    end_count = sum(1 for r in completed_status if r.get("Phase") == "END")
    bc_pass = sum(1 for r in comparisons if r["comparison"] == "B_vs_C" and r["pass"])
    ab_pass = sum(1 for r in comparisons if r["comparison"] == "A_REFERENCE_vs_B" and r["pass"])
    ac_pass = sum(1 for r in comparisons if r["comparison"] == "A_REFERENCE_vs_C" and r["pass"])
    shadow_csv_b_bad = sum(1 for r in csv_presence_rows if r["series"] == "B" and r["status"] != "OK")
    shadow_csv_c_bad = sum(1 for r in csv_presence_rows if r["series"] == "C" and r["status"] != "OK")
    schema_violations = sum(
        int(r["schema_missing_count"]) + int(r["run_id_missing_count"]) + int(r["root_snapshot_id_missing_count"]) +
        int(r["event_sequence_duplicate_count"]) + int(r["event_sequence_regression_count"]) +
        int(r["malformed_row_count"]) + int(r["nan_inf_count"]) + int(r["unknown_false_conversion_count"]) +
        int(r["unknown_zero_conversion_count"]) + int(r["invalid_enum_count"])
        for r in schema_rows
    )
    logger_open = sum(int(r["logger_open_error_count"]) for r in schema_rows)
    logger_write = sum(int(r["logger_write_error_count"]) for r in schema_rows)
    dropped = sum(int(r["dropped_row_count"]) for r in schema_rows)
    duplicate_root = sum(int(r["duplicate_root_snapshot_body_count"]) for r in schema_rows)
    orphan = sum(int(r["orphan_module_row_count"]) for r in schema_rows)
    root_count = sum(int(r["root_snapshot_count"]) for r in schema_rows)
    basket_summary_count = sum(int(r["basket_summary_count"]) for r in schema_rows)
    run_summary_count = sum(int(r["run_summary_count"]) for r in schema_rows)
    shadow_origin = sum(int(r["shadow_origin_order_count"]) if str(r["shadow_origin_order_count"]).isdigit() else 0 for r in shadow_audit_rows)
    all_pass = (
        end_count == 12 and bc_pass == 6 and ab_pass == 6 and ac_pass == 6 and
        shadow_csv_b_bad == 0 and shadow_csv_c_bad == 0 and schema_violations == 0 and
        logger_open == 0 and logger_write == 0 and dropped == 0 and duplicate_root == 0 and
        orphan == 0 and root_count > 0 and basket_summary_count > 0 and run_summary_count >= 6 and
        shadow_origin == 0
    )
    incomplete = end_count < 12
    if all_pass:
        decision = "MULTILAYER_PHASE1_SHADOW_IMPLEMENTATION_VERIFIED"
    elif incomplete:
        decision = "MULTILAYER_PHASE1_REGRESSION_INCOMPLETE"
    elif bc_pass == 6 and schema_violations == 0 and logger_open == 0 and logger_write == 0 and dropped == 0:
        decision = "MULTILAYER_PHASE1_SHADOW_RUNTIME_DATA_REQUIRED"
    else:
        decision = "MULTILAYER_PHASE1_SHADOW_IMPLEMENTATION_BLOCKED"
    summary = {
        "decision_class": decision,
        "completed_test_count": end_count,
        "planned_test_count": 12,
        "baseline_vs_shadow_off_pass_count": ab_pass,
        "shadow_off_vs_shadow_on_pass_count": bc_pass,
        "baseline_vs_shadow_on_pass_count": ac_pass,
        "six_pair_pass_count": bc_pass,
        "shadow_origin_order_count": shadow_origin,
        "shadow_origin_deal_count": shadow_origin,
        "shadow_origin_close_count": shadow_origin,
        "shadow_off_csv_created_count": sum(1 for r in csv_presence_rows if r["series"] == "B" and int(r["shadow_csv_count"]) > 0),
        "shadow_on_csv_missing_count": sum(1 for r in csv_presence_rows if r["series"] == "C" and int(r["shadow_csv_count"]) == 0),
        "root_snapshot_count": root_count,
        "duplicate_root_snapshot_count": duplicate_root,
        "orphan_module_row_count": orphan,
        "schema_violation_count": schema_violations,
        "unknown_false_conversion_count": sum(int(r["unknown_false_conversion_count"]) for r in schema_rows),
        "logger_open_error_count": logger_open,
        "logger_write_error_count": logger_write,
        "dropped_row_count": dropped,
        "basket_summary_count": basket_summary_count,
        "run_summary_count": run_summary_count,
        "prehedge_shadow_event_count": sum(int(r["prehedge_shadow_event_count"]) for r in schema_rows),
        "hedge_transition_event_count": sum(int(r["hedge_transition_event_count"]) for r in schema_rows),
        "event_risk_event_count": sum(int(r["event_risk_event_count"]) for r in schema_rows),
        "ma_retest_event_count": sum(int(r["ma_retest_event_count"]) for r in schema_rows),
        "event_risk_unknown_rate": "NA",
        "ma_retest_unknown_rate": "NA",
    }
    total_shadow_rows = sum(int(r["row_count"]) for r in schema_rows)
    if total_shadow_rows:
        summary["event_risk_unknown_rate"] = sum(int(r["event_risk_unknown_count"]) for r in schema_rows) / total_shadow_rows
        summary["ma_retest_unknown_rate"] = sum(int(r["ma_retest_unknown_count"]) for r in schema_rows) / total_shadow_rows
    (AUDIT / "validation" / "validation_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary

if __name__ == "__main__":
    s = main()
    print(json.dumps(s, indent=2, ensure_ascii=False))

