from build_ma_runtime_overlay_bundle import main

if __name__ == '__main__':
    main()
