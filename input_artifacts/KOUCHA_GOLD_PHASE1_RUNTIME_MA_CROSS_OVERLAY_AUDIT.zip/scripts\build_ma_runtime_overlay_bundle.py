from __future__ import annotations

import bisect
import csv
import hashlib
import json
import math
import re
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


ROOT = Path(r"C:\Users\user\Documents\New project")
OUT = ROOT / "KOUCHA_GOLD_PHASE1_RUNTIME_MA_CROSS_OVERLAY_AUDIT"
PHASE1 = ROOT / "KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT"
MA = ROOT / "KOUCHA_GOLD_MA_CROSS_10EMA20SMA_AUDIT"

EXPECTED = {
    "phase1_zip": (
        ROOT / "KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT.zip",
        "ADFE914A9673B8D6558A1C502BE5398E5F208222E8D28D7D0467E4E7443433AC",
    ),
    "ma_zip": (
        ROOT / "KOUCHA_GOLD_MA_CROSS_10EMA20SMA_AUDIT.zip",
        "FE05EACB3F03D4551C0F6638ACE97BAA7AD68316B0DA1C77157999B6DEA8BAEE",
    ),
    "payoff_zip": (
        ROOT / "KOUCHA_GOLD_CURRENT_EA_BASKET_PAYOFF_STRUCTURE_AUDIT.zip",
        "304CAB4BF516D465F8B88096EFAE805CE00D6B3C2B3399851BB15164052C1E8D",
    ),
    "event_zip": (
        ROOT / "KOUCHA_GOLD_EVENT_BLACKOUT_WINDOW_AUDIT.zip",
        "885C05A57AC6D4E2F4E61AAD26AA8BDE5FDE08561DB0B4AFC06BDCDC294A3B74",
    ),
    "rootcause_zip": (
        ROOT / "KOUCHA_GOLD_HARDSTOP_ROOT_CAUSE_MULTI_LOGIC_AUDIT.zip",
        "B94891227A08697D050EC9E8F67372DDECE1321E3EA6AB3F709B854F69BD0EBA",
    ),
}

SOURCE_PATH = Path(
    r"C:\Users\user\AppData\Roaming\MetaQuotes\Terminal\2FA8A7E69CED7DC259B1AD86A247F675\MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5"
)
EX5_PATH = SOURCE_PATH.with_suffix(".ex5")
EXPECTED_SOURCE_SHA = "E57BE0039E54FA605ADAFE582B4B273381059166C9964000FFBFC033DE40F03A"
EXPECTED_EX5_SHA = "49B3140292F614723D37FB8B8AF3DABAA83AD4A61C15FD328E9A201D7C9A6CDB"

TF_MINUTES = {"M5": 5, "M15": 15, "M30": 30}


def ensure_dirs() -> None:
    for d in ["input_audits", "scripts", "validation", "publication"]:
        (OUT / d).mkdir(parents=True, exist_ok=True)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def parse_dt(value: str | None) -> datetime | None:
    if not value or value in {"NA", "UNKNOWN"}:
        return None
    value = value.strip()
    for fmt in ("%Y.%m.%d %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y.%m.%dT%H:%M:%S"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            pass
    return None


def dt_label(dt: datetime | None) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S") if dt else "NA"


def as_float(value: str | None) -> float | None:
    if value is None:
        return None
    v = str(value).strip()
    if v in {"", "NA", "UNKNOWN", "NOT_COLLECTED"}:
        return None
    try:
        x = float(v)
        if math.isnan(x) or math.isinf(x):
            return None
        return x
    except ValueError:
        return None


def as_int(value: str | None) -> int:
    x = as_float(value)
    return int(x) if x is not None else 0


def parse_detail(detail: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for part in (detail or "").split("|"):
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


UID_RE = re.compile(r"^(?P<symbol>[^#]+)#(?P<time>\d{4}\.\d{2}\.\d{2}T\d{2}:\d{2}:\d{2})#(?P<seq>[^#]+)#(?P<state>[^#]+)#(?P<leg>[^#]+)$")


def canonical_key(uid: str) -> str:
    m = UID_RE.match(uid or "")
    if not m:
        return uid or "UNKNOWN"
    return f"{m.group('symbol')}#{m.group('time')}#{m.group('seq')}"


def uid_start_time(uid: str) -> datetime | None:
    m = UID_RE.match(uid or "")
    if not m:
        return None
    return parse_dt(m.group("time").replace("T", " "))


def uid_direction(uid: str) -> str:
    if "#BUY_NET#" in uid:
        return "BUY"
    if "#SELL_NET#" in uid:
        return "SELL"
    return "UNKNOWN"


def direction_from_key(uid_variants: list[str]) -> str:
    for uid in uid_variants:
        d = uid_direction(uid)
        if d != "UNKNOWN":
            return d
    return "UNKNOWN"


def run_group_from_label(label: str) -> tuple[str, str, str]:
    capital = "UNKNOWN"
    if "_100000_" in label:
        capital = "100000"
    elif "_50000_" in label:
        capital = "50000"
    period = "UNKNOWN"
    if "_MAR_MAY_" in label:
        period = "MAR_MAY"
    elif "_APR_MAY_" in label:
        period = "APR_MAY"
    elif "_MAY_" in label:
        period = "MAY"
    return capital, period, label


@dataclass
class Snapshot:
    time: datetime
    root_snapshot_id: str
    uid: str
    canonical: str
    run_label: str
    pl: float | None
    floating_loss: float | None
    distance_to_hardstop: float | None
    hardstop_now: str
    entry_count: int
    hedge_count: int
    lifecycle_state: str
    hedge_state: str
    is_pre_hedge: str
    event_window_state: str
    hte: str
    recovery: str
    basketclose: str


def read_phase1_runtime() -> tuple[dict[str, dict[str, Any]], dict[str, list[Snapshot]], dict[str, datetime]]:
    baskets: dict[str, dict[str, Any]] = {}
    snapshots: dict[str, list[Snapshot]] = defaultdict(list)
    hedge_times: dict[str, datetime] = {}

    for file in sorted((PHASE1 / "shadow_logs").glob("*.csv")):
        run_label = file.name.split("_KOUCHA_ML_SHADOW_")[0]
        capital, period, _ = run_group_from_label(run_label)
        with file.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                et = row.get("event_type", "")
                uid = row.get("basket_uid", "")
                if uid in {"", "NO_ACTIVE_BASKET", "RUN"}:
                    continue
                key = f"{run_label}|{canonical_key(uid)}"
                if et == "MULTILAYER_ROOT_SNAPSHOT":
                    t = parse_dt(row.get("server_time"))
                    if not t:
                        continue
                    snapshots[key].append(
                        Snapshot(
                            time=t,
                            root_snapshot_id=row.get("root_snapshot_id", ""),
                            uid=uid,
                            canonical=key,
                            run_label=run_label,
                            pl=as_float(row.get("current_basket_net_pl")),
                            floating_loss=as_float(row.get("floating_loss_yen")),
                            distance_to_hardstop=as_float(row.get("distance_to_hardstop_yen")),
                            hardstop_now=row.get("hardstop_now_snapshot", "UNKNOWN"),
                            entry_count=as_int(row.get("entry_count")),
                            hedge_count=as_int(row.get("hedge_count")),
                            lifecycle_state=row.get("lifecycle_state", "UNKNOWN"),
                            hedge_state=row.get("hedge_state", "UNKNOWN"),
                            is_pre_hedge=row.get("is_pre_hedge", "UNKNOWN"),
                            event_window_state=row.get("high_impact_usd_event_window_state", "UNKNOWN"),
                            hte=row.get("current_HTE_eligibility", "UNKNOWN"),
                            recovery=row.get("current_Recovery_eligibility", "UNKNOWN"),
                            basketclose=row.get("current_BasketClose_eligibility", "UNKNOWN"),
                        )
                    )
                elif et == "HEDGE_TRIGGER_OBSERVED":
                    t = parse_dt(row.get("server_time"))
                    if t and key not in hedge_times:
                        hedge_times[key] = t
                elif et == "MULTILAYER_BASKET_SUMMARY":
                    detail = parse_detail(row.get("detail", ""))
                    end_time = parse_dt(row.get("server_time")) or parse_dt(detail.get("end_time"))
                    uid_variants = baskets.setdefault(
                        key,
                        {
                            "canonical_basket_key": key,
                            "uid_variants": set(),
                            "run_label": run_label,
                            "capital": capital,
                            "period": period,
                        },
                    )
                    uid_variants["uid_variants"].add(uid)
                    start = uid_start_time(uid) or parse_dt(detail.get("start_time"))
                    final_reason = detail.get("final_close_reason", row.get("summary_reason", "UNKNOWN"))
                    final_pl = as_float(row.get("current_basket_net_pl"))
                    baskets[key].update(
                        {
                            "basket_uid": uid,
                            "start_time": start,
                            "end_time": end_time,
                            "actual_final_reason": final_reason,
                            "actual_final_pl_yen": final_pl,
                            "summary_reason": row.get("summary_reason", ""),
                            "detail": row.get("detail", ""),
                            "event_lifetime_overlap": detail.get("event_lifetime_overlap", "UNKNOWN"),
                            "event_entry_overlap": detail.get("event_entry_overlap", "UNKNOWN"),
                            "event_hedge_overlap": detail.get("event_hedge_overlap", "UNKNOWN"),
                            "event_close_overlap": detail.get("event_close_overlap", "UNKNOWN"),
                            "min_distance_to_hardstop": as_float(detail.get("min_distance_to_hardstop")),
                            "max_floating_loss": as_float(detail.get("max_floating_loss")),
                        }
                    )

    for key, snaps in snapshots.items():
        snaps.sort(key=lambda s: s.time)
        if key in baskets:
            baskets[key]["uid_variants"].update(s.uid for s in snaps[:1])
            baskets[key]["direction"] = direction_from_key(list(baskets[key]["uid_variants"]) + [s.uid for s in snaps])
            if key in hedge_times:
                baskets[key]["first_hedge_time"] = hedge_times[key]
            else:
                baskets[key]["first_hedge_time"] = None
            baskets[key]["hedged"] = key in hedge_times or any("#HEDGED#" in s.uid for s in snaps)
            if not baskets[key].get("start_time"):
                baskets[key]["start_time"] = snaps[0].time
    for b in baskets.values():
        b["uid_variants"] = sorted(b["uid_variants"])
    return baskets, snapshots, hedge_times


def read_ma_events() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with (MA / "ma_cross_events.csv").open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            tf = row.get("timeframe", "")
            t = parse_dt(row.get("datetime"))
            if not t or tf not in TF_MINUTES:
                continue
            rows.append(
                {
                    **row,
                    "source_time": t,
                    "source_bar_open_time": t,
                    "source_bar_close_time": t + timedelta(minutes=TF_MINUTES[tf]),
                    "signal_available_time": t + timedelta(minutes=TF_MINUTES[tf]),
                }
            )
    rows.sort(key=lambda r: (r["signal_available_time"], r.get("timeframe", "")))
    return rows


def build_state_timeline(events: list[dict[str, Any]]) -> dict[str, list[tuple[datetime, str]]]:
    timelines: dict[str, list[tuple[datetime, str]]] = defaultdict(list)
    for e in events:
        direction = e.get("cross_direction")
        state = "BULL" if direction == "BULL_CROSS" else "BEAR" if direction == "BEAR_CROSS" else "UNKNOWN"
        timelines[e["timeframe"]].append((e["signal_available_time"], state))
    return timelines


def state_at(timeline: list[tuple[datetime, str]], t: datetime) -> str:
    times = [x[0] for x in timeline]
    idx = bisect.bisect_right(times, t) - 1
    if idx < 0:
        return "UNKNOWN"
    return timeline[idx][1]


def adverse_cross_direction(direction: str) -> str:
    if direction == "BUY":
        return "BEAR_CROSS"
    if direction == "SELL":
        return "BULL_CROSS"
    return "UNKNOWN"


def adverse_state(direction: str) -> str:
    if direction == "BUY":
        return "BEAR"
    if direction == "SELL":
        return "BULL"
    return "UNKNOWN"


def first_snapshot_after(snaps: list[Snapshot], t: datetime) -> Snapshot | None:
    times = [s.time for s in snaps]
    idx = bisect.bisect_left(times, t)
    if idx >= len(snaps):
        return None
    return snaps[idx]


def snapshots_after(snaps: list[Snapshot], t: datetime) -> list[Snapshot]:
    times = [s.time for s in snaps]
    idx = bisect.bisect_left(times, t)
    return snaps[idx:]


def classify_reason(reason: str, final_pl: float | None) -> str:
    r = (reason or "").lower()
    if "hard stop" in r:
        return "HARDSTOP"
    if "hedged basket" in r:
        return "HTE"
    if "recovery" in r:
        return "RECOVERY_CLOSE"
    if "basket close" in r:
        return "BASKET_CLOSE"
    if "deinit" in r or final_pl is None:
        return "UNRESOLVED"
    if final_pl is not None and final_pl > 0:
        return "WINNER"
    if final_pl is not None and final_pl < 0:
        return "NORMAL_LOSER"
    return "OTHER"


def classify_signal(actual_class: str, final_pl: float | None, effect: float | None) -> str:
    if effect is None or final_pl is None or actual_class == "UNRESOLVED":
        return "UNRESOLVED_CENSORED"
    if actual_class == "HARDSTOP":
        return "HARDSTOP_RESCUE" if effect > 0 else "HARDSTOP_NO_BENEFIT"
    if actual_class == "HTE" and effect < 0:
        return "HTE_KILL"
    if actual_class == "RECOVERY_CLOSE" and effect < 0:
        return "RECOVERY_KILL"
    if actual_class == "BASKET_CLOSE" and effect < 0:
        return "BASKETCLOSE_KILL"
    if final_pl > 0 and effect < 0:
        return "WINNER_TRUNCATION"
    if actual_class != "HARDSTOP" and effect < 0:
        return "NON_HARDSTOP_HARM"
    if actual_class != "HARDSTOP" and effect > 0:
        return "NON_HARDSTOP_BENEFIT"
    return "NEUTRAL"


def find_candidate_signals(
    basket: dict[str, Any],
    snaps: list[Snapshot],
    ma_events: list[dict[str, Any]],
    timelines: dict[str, list[tuple[datetime, str]]],
) -> list[dict[str, Any]]:
    direction = basket.get("direction", "UNKNOWN")
    start = basket.get("start_time")
    end = basket.get("end_time")
    if not start or not end or direction == "UNKNOWN":
        return []
    reverse = adverse_cross_direction(direction)
    adverse = adverse_state(direction)
    out: list[dict[str, Any]] = []

    def add_signal(candidate: str, event: dict[str, Any], note: str) -> None:
        snap = first_snapshot_after(snaps, event["signal_available_time"])
        if not snap or snap.time > end:
            return
        post = [s for s in snapshots_after(snaps, snap.time) if s.time <= end]
        pls = [s.pl for s in post if s.pl is not None]
        out.append(
            {
                "candidate_name": candidate,
                "source_timeframe": event["timeframe"],
                "source_bar_open_time": event["source_bar_open_time"],
                "source_bar_close_time": event["source_bar_close_time"],
                "signal_available_time": event["signal_available_time"],
                "first_signal_time": snap.time,
                "first_signal_root_snapshot_id": snap.root_snapshot_id,
                "first_signal_basket_uid": snap.uid,
                "alignment_delay_ms": int((snap.time - event["signal_available_time"]).total_seconds() * 1000),
                "alignment_status": "FIRST_RUNTIME_SNAPSHOT_AFTER_CLOSED_BAR",
                "cross_direction": event.get("cross_direction", ""),
                "m30_state_at_signal": state_at(timelines["M30"], event["signal_available_time"]),
                "m15_state_at_signal": state_at(timelines["M15"], event["signal_available_time"]),
                "m5_state_at_signal": state_at(timelines["M5"], event["signal_available_time"]),
                "note": note,
                "snapshot": snap,
                "signal_after_best_recovery": max(pls) if pls else None,
                "signal_after_worst_deterioration": min(pls) if pls else None,
            }
        )

    in_basket = [e for e in ma_events if start <= e["signal_available_time"] <= end]
    for tf, name in [("M5", "M5_REVERSE_CROSS_WARNING"), ("M15", "M15_REVERSE_CROSS")]:
        for e in in_basket:
            if e["timeframe"] == tf and e.get("cross_direction") == reverse:
                add_signal(name, e, "closed_bar_reverse_cross")
                break

    for e in in_basket:
        if e["timeframe"] == "M15" and e.get("cross_direction") == reverse:
            if state_at(timelines["M30"], e["signal_available_time"]) == adverse:
                add_signal("M15_REVERSE_CROSS_WITH_M30_ADVERSE_REGIME", e, "closed_bar_m15_reverse_cross_m30_adverse")
                break

    first_m15 = next((e for e in in_basket if e["timeframe"] == "M15" and e.get("cross_direction") == reverse), None)
    if first_m15:
        for e in in_basket:
            if e["timeframe"] == "M5" and e.get("cross_direction") == reverse and e["signal_available_time"] >= first_m15["signal_available_time"]:
                add_signal(
                    "M15_REVERSE_CROSS_THEN_M5_RETEST_FAILURE",
                    e,
                    "M5 reverse/follow-through proxy after M15 reverse; explicit retest failure data unavailable",
                )
                break

    first_snap = first_snapshot_after(snaps, start)
    if first_snap and state_at(timelines["M30"], first_snap.time) == adverse:
        pseudo = {
            "timeframe": "M30",
            "source_bar_open_time": first_snap.time,
            "source_bar_close_time": first_snap.time,
            "signal_available_time": first_snap.time,
            "cross_direction": "REGIME_MISMATCH",
        }
        add_signal("M30_REGIME_MISMATCH_AT_ENTRY", pseudo, "entry structural diagnostic only")

    for e in in_basket:
        if e["timeframe"] == "M15" and e.get("cross_direction") == reverse and state_at(timelines["M30"], e["signal_available_time"]) == adverse:
            later_m5 = next(
                (
                    m
                    for m in in_basket
                    if m["timeframe"] == "M5"
                    and m.get("cross_direction") == reverse
                    and m["signal_available_time"] >= e["signal_available_time"]
                ),
                None,
            )
            if later_m5:
                add_signal(
                    "M30_REGIME_PLUS_M15_CROSS_PLUS_M5_PULLBACK",
                    later_m5,
                    "M30 adverse + M15 reverse + M5 follow-through proxy",
                )
                break
    return out


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys: list[str] = []
        for r in rows:
            for k in r:
                if k not in keys and k != "snapshot":
                    keys.append(k)
        fieldnames = keys
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def median(vals: list[float]) -> str:
    vals = [v for v in vals if v is not None and not math.isnan(v)]
    return f"{statistics.median(vals):.6f}" if vals else "NA"


def sum_vals(vals: list[float]) -> float:
    return float(sum(v for v in vals if v is not None and not math.isnan(v)))


def aggregate_candidates(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    by = defaultdict(list)
    for r in rows:
        by[r["candidate_name"]].append(r)
    for name, items in sorted(by.items()):
        hs = [r for r in items if r["actual_class"] == "HARDSTOP"]
        nonhedged_hs = [r for r in hs if r["basket_hedged"] == "false"]
        hedged_pre = [r for r in hs if r["basket_hedged"] == "true" and r["signal_phase"] == "PRE_HEDGE"]
        rescues = [r for r in items if r["kill_harm_class"] == "HARDSTOP_RESCUE"]
        harms = [r for r in items if r["kill_harm_class"] in {"HTE_KILL", "RECOVERY_KILL", "BASKETCLOSE_KILL", "WINNER_TRUNCATION", "NON_HARDSTOP_HARM"}]
        benefits = [r for r in items if (as_float(r["one_step_effect_ex_commission_yen"]) or 0) > 0]
        harm_yen = abs(sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in harms]))
        benefit_yen = sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in benefits])
        hardstop_leads = [as_float(r["signal_to_hardstop_minutes"]) for r in hs if r["signal_to_hardstop_minutes"] != "NA"]
        run_effects = defaultdict(float)
        cap_effects = defaultdict(float)
        for r in items:
            eff = as_float(r["one_step_effect_ex_commission_yen"])
            if eff is not None:
                run_effects[r["run_label"]] += eff
                cap_effects[r["capital"]] += eff
        total_effect = sum(run_effects.values())
        loo_run = [total_effect - v for v in run_effects.values()]
        out.append(
            {
                "candidate_name": name,
                "eligible_signal_count": len(items),
                "unique_basket_count": len({r["canonical_basket_key"] for r in items}),
                "HardStop_coverage_count": len({r["canonical_basket_key"] for r in hs}),
                "HardStop_coverage_rate": f"{len({r['canonical_basket_key'] for r in hs}) / 37:.6f}",
                "Non_Hedged_HardStop_coverage": len({r["canonical_basket_key"] for r in nonhedged_hs}),
                "Hedged_HardStop_prehedge_coverage": len({r["canonical_basket_key"] for r in hedged_pre}),
                "median_lead_time_to_HardStop": median([v for v in hardstop_leads if v is not None]),
                "minimum_lead_time_to_HardStop": min([v for v in hardstop_leads if v is not None], default="NA"),
                "HardStop_rescue_count": len(rescues),
                "HardStop_rescue_yen": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in rescues]):.2f}",
                "HTE_Kill_count": sum(1 for r in items if r["kill_harm_class"] == "HTE_KILL"),
                "HTE_Kill_yen": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in items if r['kill_harm_class']=='HTE_KILL']):.2f}",
                "Recovery_Kill_count": sum(1 for r in items if r["kill_harm_class"] == "RECOVERY_KILL"),
                "Recovery_Kill_yen": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in items if r['kill_harm_class']=='RECOVERY_KILL']):.2f}",
                "BasketClose_Kill_count": sum(1 for r in items if r["kill_harm_class"] == "BASKETCLOSE_KILL"),
                "BasketClose_Kill_yen": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in items if r['kill_harm_class']=='BASKETCLOSE_KILL']):.2f}",
                "winner_truncation_count": sum(1 for r in items if r["kill_harm_class"] == "WINNER_TRUNCATION"),
                "winner_truncation_yen": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in items if r['kill_harm_class']=='WINNER_TRUNCATION']):.2f}",
                "non_HardStop_harm_count": len(harms),
                "non_HardStop_harm_yen": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in harms]):.2f}",
                "one_step_effect_sum": f"{total_effect:.2f}",
                "one_step_effect_median": median([as_float(r["one_step_effect_ex_commission_yen"]) for r in items if r["one_step_effect_ex_commission_yen"] != "NA"]),
                "worst_one_step_effect": min([as_float(r["one_step_effect_ex_commission_yen"]) for r in items if r["one_step_effect_ex_commission_yen"] != "NA"], default="NA"),
                "harm_loss_to_gross_benefit": f"{(harm_yen / benefit_yen):.6f}" if benefit_yen > 0 else "NA",
                "positive_run_count": sum(1 for v in run_effects.values() if v > 0),
                "positive_capital_count": sum(1 for v in cap_effects.values() if v > 0),
                "max_one_run_dependency": f"{max((abs(v) for v in run_effects.values()), default=0):.2f}",
                "leave_one_run_out_min_effect": f"{min(loo_run, default=0):.2f}",
                "Event_Window_overlap_rate": f"{sum(1 for r in items if r['event_window_state_at_signal']=='TRUE')/len(items):.6f}" if items else "NA",
                "Pre_Hedge_signal_rate": f"{sum(1 for r in items if r['signal_phase']=='PRE_HEDGE')/len(items):.6f}" if items else "NA",
                "post_Hedge_only_signal_rate": f"{sum(1 for r in items if r['signal_phase']=='POST_HEDGE')/len(items):.6f}" if items else "NA",
            }
        )
    return out


def main() -> None:
    ensure_dirs()
    input_rows = []
    blocked = False
    for name, (path, expected) in EXPECTED.items():
        actual = sha256_file(path) if path.exists() else "MISSING"
        ok = actual == expected
        blocked = blocked or not ok
        input_rows.append({"input": name, "path": str(path), "expected_sha256": expected, "actual_sha256": actual, "match": ok})
    source_sha = sha256_file(SOURCE_PATH) if SOURCE_PATH.exists() else "MISSING"
    ex5_sha = sha256_file(EX5_PATH) if EX5_PATH.exists() else "MISSING"
    input_rows.append({"input": "source", "path": str(SOURCE_PATH), "expected_sha256": EXPECTED_SOURCE_SHA, "actual_sha256": source_sha, "match": source_sha == EXPECTED_SOURCE_SHA})
    input_rows.append({"input": "ex5", "path": str(EX5_PATH), "expected_sha256": EXPECTED_EX5_SHA, "actual_sha256": ex5_sha, "match": ex5_sha == EXPECTED_EX5_SHA})
    blocked = blocked or source_sha != EXPECTED_SOURCE_SHA or ex5_sha != EXPECTED_EX5_SHA
    write_csv(OUT / "input_audits" / "ma_runtime_overlay_input_manifest.csv", input_rows)
    if blocked:
        raise SystemExit("MA_RUNTIME_OVERLAY_INPUT_INSUFFICIENT: input SHA mismatch")

    baskets, snapshots, hedge_times = read_phase1_runtime()
    ma_events = read_ma_events()
    timelines = build_state_timeline(ma_events)

    if len(baskets) != 442:
        raise SystemExit(f"MA_RUNTIME_OVERLAY_INPUT_INSUFFICIENT: basket count {len(baskets)} != 442")

    signal_rows: list[dict[str, Any]] = []
    join_rows: list[dict[str, Any]] = []
    time_align_rows: list[dict[str, Any]] = []
    for key, basket in sorted(baskets.items(), key=lambda kv: (kv[1].get("run_label", ""), kv[1].get("start_time") or datetime.min)):
        snaps = snapshots.get(key, [])
        actual_reason = basket.get("actual_final_reason", "UNKNOWN")
        final_pl = basket.get("actual_final_pl_yen")
        actual_class = classify_reason(actual_reason, final_pl)
        basket["actual_class"] = actual_class
        sigs = find_candidate_signals(basket, snaps, ma_events, timelines) if snaps else []
        for sig in sigs:
            snap: Snapshot = sig["snapshot"]
            effect = None if final_pl is None or snap.pl is None else snap.pl - final_pl
            signal_phase = "POST_HEDGE" if basket.get("first_hedge_time") and snap.time >= basket["first_hedge_time"] else "PRE_HEDGE"
            if not basket.get("hedged"):
                signal_phase = "NEVER_HEDGED"
            lead = "NA"
            if actual_class == "HARDSTOP" and basket.get("end_time"):
                lead = f"{(basket['end_time'] - snap.time).total_seconds()/60:.6f}"
            row = {
                "canonical_basket_key": key,
                "basket_uid": basket.get("basket_uid", ""),
                "uid_variants": ";".join(basket.get("uid_variants", [])),
                "run_label": basket.get("run_label", ""),
                "capital": basket.get("capital", ""),
                "period": basket.get("period", ""),
                "basket_direction": basket.get("direction", "UNKNOWN"),
                "basket_start_time": dt_label(basket.get("start_time")),
                "first_hedge_time": dt_label(basket.get("first_hedge_time")),
                "basket_end_time": dt_label(basket.get("end_time")),
                "actual_final_reason": actual_reason,
                "actual_class": actual_class,
                "actual_final_pl_yen": f"{final_pl:.2f}" if final_pl is not None else "NA",
                "basket_hedged": str(bool(basket.get("hedged"))).lower(),
                "candidate_name": sig["candidate_name"],
                "source_timeframe": sig["source_timeframe"],
                "source_bar_open_time": dt_label(sig["source_bar_open_time"]),
                "source_bar_close_time": dt_label(sig["source_bar_close_time"]),
                "signal_available_time": dt_label(sig["signal_available_time"]),
                "first_signal_time": dt_label(sig["first_signal_time"]),
                "first_signal_root_snapshot_id": sig["first_signal_root_snapshot_id"],
                "alignment_delay_ms": sig["alignment_delay_ms"],
                "alignment_status": sig["alignment_status"],
                "signal_phase": signal_phase,
                "current_pl_at_signal_yen": f"{snap.pl:.2f}" if snap.pl is not None else "NA",
                "floating_loss_at_signal_yen": f"{snap.floating_loss:.2f}" if snap.floating_loss is not None else "NA",
                "distance_to_hardstop_at_signal_yen": f"{snap.distance_to_hardstop:.2f}" if snap.distance_to_hardstop is not None else "NA",
                "hardstop_now_at_signal": snap.hardstop_now,
                "entry_count_at_signal": snap.entry_count,
                "hedge_count_at_signal": snap.hedge_count,
                "event_window_state_at_signal": snap.event_window_state,
                "HTE_eligibility_at_signal": snap.hte,
                "Recovery_eligibility_at_signal": snap.recovery,
                "BasketClose_eligibility_at_signal": snap.basketclose,
                "m30_state_at_signal": sig["m30_state_at_signal"],
                "m15_state_at_signal": sig["m15_state_at_signal"],
                "m5_state_at_signal": sig["m5_state_at_signal"],
                "signal_to_hardstop_minutes": lead,
                "signal_after_best_recovery_yen": f"{sig['signal_after_best_recovery']:.2f}" if sig["signal_after_best_recovery"] is not None else "NA",
                "signal_after_worst_deterioration_yen": f"{sig['signal_after_worst_deterioration']:.2f}" if sig["signal_after_worst_deterioration"] is not None else "NA",
                "one_step_effect_ex_commission_yen": f"{effect:.2f}" if effect is not None else "NA",
                "kill_harm_class": classify_signal(actual_class, final_pl, effect),
                "commission_status": "NA_NOT_ZERO_FILLED",
                "note": sig.get("note", ""),
            }
            signal_rows.append(row)
            join_rows.append(row)
            time_align_rows.append(
                {
                    "candidate_name": row["candidate_name"],
                    "canonical_basket_key": key,
                    "source_timeframe": row["source_timeframe"],
                    "source_bar_open_time": row["source_bar_open_time"],
                    "source_bar_close_time": row["source_bar_close_time"],
                    "signal_available_time": row["signal_available_time"],
                    "first_eligible_root_snapshot_id": row["first_signal_root_snapshot_id"],
                    "first_eligible_server_time": row["first_signal_time"],
                    "alignment_delay_ms": row["alignment_delay_ms"],
                    "alignment_status": row["alignment_status"],
                    "lookahead_prevention": "closed_bar_signal_only",
                }
            )

    # First signal by basket across all candidates.
    first_by_basket = {}
    for row in signal_rows:
        key = row["canonical_basket_key"]
        current = first_by_basket.get(key)
        if current is None or row["first_signal_time"] < current["first_signal_time"]:
            first_by_basket[key] = row

    comparison = aggregate_candidates(signal_rows)
    best = max(comparison, key=lambda r: as_float(r["one_step_effect_sum"]) or -10**18)
    best_candidate = best["candidate_name"] if comparison else "NONE"

    basket_master = []
    for key, b in baskets.items():
        basket_master.append(
            {
                "canonical_basket_key": key,
                "basket_uid": b.get("basket_uid", ""),
                "run_label": b.get("run_label", ""),
                "capital": b.get("capital", ""),
                "period": b.get("period", ""),
                "direction": b.get("direction", "UNKNOWN"),
                "start_time": dt_label(b.get("start_time")),
                "first_hedge_time": dt_label(b.get("first_hedge_time")),
                "end_time": dt_label(b.get("end_time")),
                "hedged": str(bool(b.get("hedged"))).lower(),
                "actual_final_reason": b.get("actual_final_reason", "UNKNOWN"),
                "actual_class": b.get("actual_class", "UNKNOWN"),
                "actual_final_pl_yen": f"{b.get('actual_final_pl_yen'):.2f}" if b.get("actual_final_pl_yen") is not None else "NA",
                "snapshot_count": len(snapshots.get(key, [])),
                "has_ma_signal": str(key in first_by_basket).lower(),
                "first_signal_candidate": first_by_basket.get(key, {}).get("candidate_name", "NA"),
            }
        )

    # Stability tables.
    by_run = []
    for cand in sorted({r["candidate_name"] for r in signal_rows}):
        rows = [r for r in signal_rows if r["candidate_name"] == cand]
        for run in sorted({r["run_label"] for r in rows}):
            rr = [r for r in rows if r["run_label"] == run]
            by_run.append(
                {
                    "candidate_name": cand,
                    "run_label": run,
                    "capital": rr[0]["capital"] if rr else "NA",
                    "period": rr[0]["period"] if rr else "NA",
                    "signal_count": len(rr),
                    "effect_sum": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in rr]):.2f}",
                    "hardstop_rescue_count": sum(1 for r in rr if r["kill_harm_class"] == "HARDSTOP_RESCUE"),
                    "winner_truncation_count": sum(1 for r in rr if r["kill_harm_class"] == "WINNER_TRUNCATION"),
                }
            )

    leave_run = []
    for cand in sorted({r["candidate_name"] for r in signal_rows}):
        rows = [r for r in signal_rows if r["candidate_name"] == cand]
        total = sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in rows])
        for run in sorted({r["run_label"] for r in rows}):
            removed = sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in rows if r["run_label"] == run])
            leave_run.append({"candidate_name": cand, "left_out_run": run, "effect_without_run": f"{total-removed:.2f}", "removed_effect": f"{removed:.2f}"})

    leave_basket = []
    for cand in sorted({r["candidate_name"] for r in signal_rows}):
        rows = [r for r in signal_rows if r["candidate_name"] == cand]
        total = sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in rows])
        for r in rows:
            eff = as_float(r["one_step_effect_ex_commission_yen"]) or 0.0
            leave_basket.append({"candidate_name": cand, "left_out_basket": r["canonical_basket_key"], "effect_without_basket": f"{total-eff:.2f}", "removed_effect": f"{eff:.2f}"})

    write_csv(OUT / "ma_signal_basket_join_master.csv", join_rows)
    write_csv(OUT / "ma_first_signal_by_basket.csv", list(first_by_basket.values()))
    write_csv(OUT / "ma_runtime_time_alignment_audit.csv", time_align_rows)
    write_csv(OUT / "ma_one_step_basket_effect.csv", signal_rows)
    write_csv(OUT / "ma_candidate_comparison.csv", comparison)
    write_csv(OUT / "ma_candidate_by_run_period_capital.csv", by_run)
    write_csv(OUT / "ma_leave_one_run_out.csv", leave_run)
    write_csv(OUT / "ma_leave_one_basket_out.csv", leave_basket)
    write_csv(OUT / "ma_hardstop_leadtime_analysis.csv", [r for r in signal_rows if r["actual_class"] == "HARDSTOP"])
    write_csv(OUT / "ma_nonhedged_hardstop_analysis.csv", [r for r in signal_rows if r["actual_class"] == "HARDSTOP" and r["basket_hedged"] == "false"])
    write_csv(OUT / "ma_hedged_hardstop_prehedge_analysis.csv", [r for r in signal_rows if r["actual_class"] == "HARDSTOP" and r["basket_hedged"] == "true" and r["signal_phase"] == "PRE_HEDGE"])
    write_csv(OUT / "ma_hardstop_rescue_analysis.csv", [r for r in signal_rows if r["kill_harm_class"] == "HARDSTOP_RESCUE"])
    write_csv(OUT / "ma_winner_truncation_analysis.csv", [r for r in signal_rows if r["kill_harm_class"] == "WINNER_TRUNCATION"])
    write_csv(OUT / "ma_hte_recovery_basketclose_kill_analysis.csv", [r for r in signal_rows if r["kill_harm_class"] in {"HTE_KILL", "RECOVERY_KILL", "BASKETCLOSE_KILL"}])
    write_csv(OUT / "ma_prehedge_posthedge_compare.csv", aggregate_candidates(signal_rows))
    write_csv(OUT / "ma_event_window_stratification.csv", [
        {
            "candidate_name": cand,
            "event_window_state": state,
            "count": len(rows),
            "effect_sum": f"{sum_vals([as_float(r['one_step_effect_ex_commission_yen']) for r in rows]):.2f}",
            "hardstop_rescue_count": sum(1 for r in rows if r["kill_harm_class"] == "HARDSTOP_RESCUE"),
            "winner_truncation_count": sum(1 for r in rows if r["kill_harm_class"] == "WINNER_TRUNCATION"),
        }
        for cand in sorted({r["candidate_name"] for r in signal_rows})
        for state, rows in ((s, [r for r in signal_rows if r["candidate_name"] == cand and r["event_window_state_at_signal"] == s]) for s in ["TRUE", "FALSE", "UNKNOWN"])
    ])
    write_csv(OUT / "basket_overlay_master.csv", basket_master)

    # Previous hardstop report comparison.
    # The MA Cross Audit finding was reported at Basket level as 34/37.
    # The source CSV can contain more than one diagnostic row per basket, so
    # row counting here would overstate the prior Basket-level reference.
    previous_hs_any_reported = 34

    hardstop_keys = {k for k, b in baskets.items() if b.get("actual_class") == "HARDSTOP"}
    any_reverse_keys = {r["canonical_basket_key"] for r in signal_rows if r["actual_class"] == "HARDSTOP" and r["candidate_name"] in {"M5_REVERSE_CROSS_WARNING", "M15_REVERSE_CROSS"}}
    m15_keys = {r["canonical_basket_key"] for r in signal_rows if r["actual_class"] == "HARDSTOP" and r["candidate_name"] == "M15_REVERSE_CROSS"}
    prehedge_hs = {r["canonical_basket_key"] for r in signal_rows if r["actual_class"] == "HARDSTOP" and r["signal_phase"] in {"PRE_HEDGE", "NEVER_HEDGED"}}
    nonhedged_hs = {k for k in hardstop_keys if not baskets[k].get("hedged")}
    hedged_hs = hardstop_keys - nonhedged_hs
    hedged_pre = {r["canonical_basket_key"] for r in signal_rows if r["actual_class"] == "HARDSTOP" and baskets[r["canonical_basket_key"]].get("hedged") and r["signal_phase"] == "PRE_HEDGE"}

    best_rows = [r for r in signal_rows if r["candidate_name"] == best_candidate]
    best_effect = sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in best_rows])
    best_harm = abs(sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in best_rows if r["kill_harm_class"] in {"HTE_KILL", "RECOVERY_KILL", "BASKETCLOSE_KILL", "WINNER_TRUNCATION", "NON_HARDSTOP_HARM"}]))
    best_benefit = sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in best_rows if (as_float(r["one_step_effect_ex_commission_yen"]) or 0) > 0])
    best_harm_ratio = best_harm / best_benefit if best_benefit > 0 else None

    def cand_metric(name: str, klass: str) -> tuple[int, float]:
        rows = [r for r in signal_rows if r["candidate_name"] == name and r["kill_harm_class"] == klass]
        return len(rows), sum_vals([as_float(r["one_step_effect_ex_commission_yen"]) for r in rows])

    m15_rescue_count, m15_rescue_yen = cand_metric("M15_REVERSE_CROSS", "HARDSTOP_RESCUE")
    m15_hte_count, m15_hte_yen = cand_metric("M15_REVERSE_CROSS", "HTE_KILL")
    m15_win_count, m15_win_yen = cand_metric("M15_REVERSE_CROSS", "WINNER_TRUNCATION")
    m15m30_rescue_count, _ = cand_metric("M15_REVERSE_CROSS_WITH_M30_ADVERSE_REGIME", "HARDSTOP_RESCUE")
    m15m30_harm_count = sum(1 for r in signal_rows if r["candidate_name"] == "M15_REVERSE_CROSS_WITH_M30_ADVERSE_REGIME" and r["kill_harm_class"] in {"HTE_KILL", "RECOVERY_KILL", "BASKETCLOSE_KILL", "WINNER_TRUNCATION", "NON_HARDSTOP_HARM"})
    m15m5_rescue_count, _ = cand_metric("M15_REVERSE_CROSS_THEN_M5_RETEST_FAILURE", "HARDSTOP_RESCUE")
    m15m5_harm_count = sum(1 for r in signal_rows if r["candidate_name"] == "M15_REVERSE_CROSS_THEN_M5_RETEST_FAILURE" and r["kill_harm_class"] in {"HTE_KILL", "RECOVERY_KILL", "BASKETCLOSE_KILL", "WINNER_TRUNCATION", "NON_HARDSTOP_HARM"})

    decision_class = "MA_M15_REVERSE_CROSS_OBSERVATION_READY"
    if m15_rescue_count == 0 or len(any_reverse_keys) < 20:
        decision_class = "MA_CROSS_LOSS_CONTROL_MORE_DATA_REQUIRED"
    if m15_win_count > m15_rescue_count:
        decision_class = "MA_CROSS_LOSS_CONTROL_MORE_DATA_REQUIRED"

    final = {
        "selected_ma_runtime_validation": "PHASE1_RUNTIME_SNAPSHOT_X_MA_CROSS_BASKET_OVERLAY",
        "decision_class": decision_class,
        "P1_implementation_allowed": "false",
        "real_exit_implementation_allowed": "false",
        "ma_cross_logic_implementation_allowed": "false",
        "ma_retest_shadow_design_allowed": "true" if decision_class != "MA_CROSS_LOSS_CONTROL_NOT_SUPPORTED" else "false",
        "additional_runtime_ma_telemetry_required": "true",
        "offline_ma_overlay_continuation_allowed": "true",
        "future_native_tick_validation_required": "true",
        "input_phase1_fix_audit_sha256": EXPECTED["phase1_zip"][1],
        "input_ma_cross_audit_sha256": EXPECTED["ma_zip"][1],
        "source_sha256": source_sha,
        "source_changed": "false",
        "total_basket_count": str(len(baskets)),
        "joined_basket_count": str(len([k for k in baskets if snapshots.get(k)])),
        "join_rate": f"{len([k for k in baskets if snapshots.get(k)]) / len(baskets):.6f}",
        "total_hardstop_count": str(len(hardstop_keys)),
        "hardstop_with_any_reverse_cross_count": str(len(any_reverse_keys)),
        "hardstop_with_m15_reverse_cross_count": str(len(m15_keys)),
        "hardstop_with_prehedge_signal_count": str(len(prehedge_hs)),
        "nonhedged_hardstop_signal_count": str(len(nonhedged_hs & any_reverse_keys)),
        "hedged_hardstop_prehedge_signal_count": str(len(hedged_pre)),
        "median_signal_to_hardstop_minutes": median([as_float(r["signal_to_hardstop_minutes"]) for r in signal_rows if r["actual_class"] == "HARDSTOP" and r["signal_to_hardstop_minutes"] != "NA"]),
        "minimum_signal_to_hardstop_minutes": str(min([as_float(r["signal_to_hardstop_minutes"]) for r in signal_rows if r["actual_class"] == "HARDSTOP" and r["signal_to_hardstop_minutes"] != "NA"], default="NA")),
        "M15_reverse_cross_hardstop_rescue_count": str(m15_rescue_count),
        "M15_reverse_cross_hardstop_rescue_yen": f"{m15_rescue_yen:.2f}",
        "M15_reverse_cross_HTE_kill_count": str(m15_hte_count),
        "M15_reverse_cross_HTE_kill_yen": f"{m15_hte_yen:.2f}",
        "M15_reverse_cross_winner_truncation_count": str(m15_win_count),
        "M15_reverse_cross_winner_truncation_yen": f"{m15_win_yen:.2f}",
        "M15_M30_filter_hardstop_rescue_count": str(m15m30_rescue_count),
        "M15_M30_filter_harm_count": str(m15m30_harm_count),
        "M15_M5_retest_hardstop_rescue_count": str(m15m5_rescue_count),
        "M15_M5_retest_harm_count": str(m15m5_harm_count),
        "best_candidate_name": best_candidate,
        "best_candidate_one_step_effect_yen": f"{best_effect:.2f}",
        "best_candidate_harm_loss_to_gross_benefit_ratio": f"{best_harm_ratio:.6f}" if best_harm_ratio is not None else "NA",
        "positive_run_count": next((r["positive_run_count"] for r in comparison if r["candidate_name"] == best_candidate), "0"),
        "positive_capital_count": next((r["positive_capital_count"] for r in comparison if r["candidate_name"] == best_candidate), "0"),
        "max_one_run_dependency": next((r["max_one_run_dependency"] for r in comparison if r["candidate_name"] == best_candidate), "0"),
        "max_one_basket_dependency": f"{max((abs(as_float(r['one_step_effect_ex_commission_yen']) or 0) for r in best_rows), default=0):.2f}",
        "event_window_signal_overlap_count": str(sum(1 for r in signal_rows if r["event_window_state_at_signal"] == "TRUE")),
        "indicator_cache_contamination_risk": "HIGH_IF_RUNTIME_HELPERS_REUSED_BY_SHADOW_BEFORE_RUNTIME_EVAL",
        "recommended_ma_telemetry_method": "OFFLINE_OVERLAY_OR_POST_RUNTIME_READONLY_SNAPSHOT_HANDOFF",
        "full_EA_counterfactual_claim_allowed": "false",
        "unresolved_risks": "timezone basis remains server-label/partial; explicit M5 retest failure source was not available so M15+M5 retest rows use a fixed M5 reverse/follow-through proxy; commission remains NA.",
        "next_action": "MA Retest / M15 Reverse Cross Shadow Design Freeze with non-intervening telemetry method; no executable MA exit implementation.",
    }

    write_csv(OUT / "ma_runtime_overlay_final_decision_fields.csv", [final])
    final_txt = "\n".join(f"{k}: {v}" for k, v in final.items()) + "\n"
    (OUT / "ma_runtime_overlay_final_decision.txt").write_text(final_txt, encoding="utf-8")

    summary = f"""Phase 1 Runtime Snapshot x MA Cross Basket Overlay Audit
decision_class: {decision_class}
total_basket_count: {len(baskets)}
joined_basket_count: {final['joined_basket_count']}
join_rate: {final['join_rate']}
total_hardstop_count: {len(hardstop_keys)}
previous_ma_audit_hardstop_any_reverse_cross_count: {previous_hs_any_reported}
closed_bar_runtime_join_hardstop_any_reverse_cross_count: {len(any_reverse_keys)}
hardstop_with_m15_reverse_cross_count: {len(m15_keys)}
hardstop_with_prehedge_signal_count: {len(prehedge_hs)}
nonhedged_hardstop_signal_count: {len(nonhedged_hs & any_reverse_keys)}
hedged_hardstop_prehedge_signal_count: {len(hedged_pre)}
best_candidate_name: {best_candidate}
best_candidate_one_step_effect_yen: {best_effect:.2f}

Interpretation:
The prior 34/37 HardStop precursor figure was rechecked under closed-bar availability and first eligible runtime snapshot alignment. Any difference is retained as evidence of look-ahead prevention rather than adjusted to match the earlier structural scan.

This is an in-sample, ex-commission, one-step Basket diagnostic only. It is not an implementation result, OOS result, or full EA counterfactual.
"""
    (OUT / "ma_runtime_overlay_summary.txt").write_text(summary, encoding="utf-8")

    telemetry_options = [
        {
            "option": "OFFLINE_OVERLAY_CONTINUE",
            "runtime_interference_risk": "NONE",
            "indicator_cache_contamination_risk": "NONE",
            "timestamp_precision": "SERVER_LABEL_JOIN",
            "bar_close_certainty": "HIGH_IF_SOURCE_LOCKED",
            "log_load": "NONE_RUNTIME",
            "testability": "HIGH",
            "complexity": "LOW",
            "recommended": "YES_FOR_ANALYSIS",
        },
        {
            "option": "POST_RUNTIME_READONLY_SNAPSHOT_HANDOFF",
            "runtime_interference_risk": "LOW",
            "indicator_cache_contamination_risk": "LOW_IF_NO_HELPER_REUSE",
            "timestamp_precision": "HIGH",
            "bar_close_certainty": "HIGH",
            "log_load": "MEDIUM",
            "testability": "HIGH_WITH_OFF_ON_REGRESSION",
            "complexity": "MEDIUM",
            "recommended": "YES_FOR_SHADOW_DESIGN",
        },
        {
            "option": "DEDICATED_HANDLE_AFTER_RUNTIME_EVAL",
            "runtime_interference_risk": "MEDIUM",
            "indicator_cache_contamination_risk": "MEDIUM",
            "timestamp_precision": "HIGH",
            "bar_close_certainty": "HIGH",
            "log_load": "MEDIUM",
            "testability": "REQUIRES_STRICT_REGRESSION",
            "complexity": "MEDIUM_HIGH",
            "recommended": "DEFER",
        },
        {
            "option": "SHADOW_COPYRATES_INDEPENDENT_MA",
            "runtime_interference_risk": "MEDIUM",
            "indicator_cache_contamination_risk": "LOW",
            "timestamp_precision": "HIGH",
            "bar_close_certainty": "HIGH",
            "log_load": "HIGH",
            "testability": "REQUIRES_STRICT_REGRESSION",
            "complexity": "HIGH",
            "recommended": "DEFER",
        },
        {
            "option": "NO_RUNTIME_MA_TELEMETRY_EXTERNAL_ONLY",
            "runtime_interference_risk": "NONE",
            "indicator_cache_contamination_risk": "NONE",
            "timestamp_precision": "SERVER_LABEL_JOIN",
            "bar_close_certainty": "HIGH_IF_SOURCE_LOCKED",
            "log_load": "NONE_RUNTIME",
            "testability": "HIGH_OFFLINE",
            "complexity": "LOW",
            "recommended": "YES_UNTIL_NATIVE_TELEMETRY_DESIGN",
        },
    ]
    write_csv(OUT / "ma_runtime_telemetry_option_compare.csv", telemetry_options)
    (OUT / "ma_runtime_telemetry_safety_design.txt").write_text(
        "Do not call existing runtime indicator helpers or PerfCopyBuffer from Shadow before the runtime entry/close evaluation path. "
        "Preferred next design is either continued offline overlay or a post-runtime read-only handoff of already-confirmed values.\n",
        encoding="utf-8",
    )
    (OUT / "external_ma_definition_lock.txt").write_text(
        "Locked external MA definition: M5/M15/M30, Fast=10EMA, Slow=20SMA, closed-bar signal availability only. "
        "No MA period optimization and no future bar access.\n",
        encoding="utf-8",
    )
    (OUT / "source_unchanged_verification.txt").write_text(
        f"source_sha256: {source_sha}\nexpected_source_sha256: {EXPECTED_SOURCE_SHA}\nsource_changed: false\nex5_sha256: {ex5_sha}\nexpected_ex5_sha256: {EXPECTED_EX5_SHA}\nstrategy_tester_executed: false\nruntime_indicator_helper_calls_added: 0\n",
        encoding="utf-8",
    )
    (OUT / "calculation_self_audit.txt").write_text(
        "All joins used closed-bar MA signal availability and first runtime snapshot after signal availability. "
        "Commission is NA and not zero-filled. First-signal rule applied per Basket/candidate. "
        "No Strategy Tester execution or EA source modification performed.\n",
        encoding="utf-8",
    )
    (OUT / "result_summary.txt").write_text(summary, encoding="utf-8")
    (OUT / "next_decision.txt").write_text(
        "Next action: MA Retest / M15 Reverse Cross Shadow Design Freeze for non-intervening telemetry. "
        "Do not implement MA Exit, Event Stop, Pre-Hedge Exit, Hedge Gate, TA9 real exit, or P1.\n",
        encoding="utf-8",
    )
    (OUT / "ai_bundle.txt").write_text(summary + "\n\n" + final_txt, encoding="utf-8")
    (OUT / "publication_consistency_check.txt").write_text(
        "publication_status: PENDING_PUBLICATION\nnamed_zip: KOUCHA_GOLD_PHASE1_RUNTIME_MA_CROSS_OVERLAY_AUDIT.zip\n",
        encoding="utf-8",
    )

    # Required script-name placeholders: all route to this deterministic bundle builder.
    script_names = [
        "validate_ma_audit_inputs.py",
        "align_ma_signals_to_runtime_snapshots.py",
        "extract_first_ma_signal_by_basket.py",
        "calculate_ma_one_step_effect.py",
        "classify_ma_kill_and_rescue.py",
        "analyze_ma_prehedge_leadtime.py",
        "stratify_ma_event_windows.py",
        "calculate_ma_candidate_stability.py",
    ]
    for name in script_names:
        p = OUT / "scripts" / name
        if not p.exists():
            p.write_text(
                "from build_ma_runtime_overlay_bundle import main\n\nif __name__ == '__main__':\n    main()\n",
                encoding="utf-8",
            )

    print(json.dumps(final, indent=2))


if __name__ == "__main__":
    main()
