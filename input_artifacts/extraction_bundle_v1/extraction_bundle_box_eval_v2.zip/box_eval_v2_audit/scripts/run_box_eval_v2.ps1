param(
    [string]$Pattern = 'ALL',
    [switch]$AppendStatus,
    [switch]$SkipCompleted
)

$ErrorActionPreference = 'Stop'
$Workspace = 'C:\Users\user\Documents\New project'
$AuditRoot = Join-Path $Workspace 'KOUCHA_GOLD_BOX_EXIT_EVALUATION_V2_AUDIT'
$TerminalExe = 'C:\Program Files\XMTrading MT5\terminal64.exe'
$TerminalData = 'C:\Users\user\AppData\Roaming\MetaQuotes\Terminal\2FA8A7E69CED7DC259B1AD86A247F675'
$TesterRoot = 'C:\Users\user\AppData\Roaming\MetaQuotes\Tester\2FA8A7E69CED7DC259B1AD86A247F675'
$AgentRoot = Join-Path $TesterRoot 'Agent-127.0.0.1-3000'
$AgentFiles = Join-Path $AgentRoot 'MQL5\Files'
$StatusPath = Join-Path $AuditRoot 'box_eval_v2_run_status.csv'
$ManifestPath = Join-Path $AuditRoot 'box_eval_v2_execution_manifest.csv'

$ExpectedSurvivalSha = 'C1DBE51A9FBBBAE0029C63588961A19BA4A0CD2F0EEE1C237169805ADC27AD51'
$ExpectedW3MqhSha = '36FC7066B107A2DA8DBD8F2F2146A55FAB48AAC6BFBB53D68A594685A91F6B7E'
$ExpectedSurvivalEx5Sha = '1652AA38BE2D0239DB7F6FAB810065DBF21E69DC05196DB15F85215427088E36'
$ExpectedV1VariantSha = '11EBE14B5679C7291B5C0FECE459678D9BCE8F396A09EC5615E830054DFF59AA'
$BoxAbsCapYen = '2000.0'
$BoxHsFraction = '0.50'

function CsvLine($values) { return (($values | ForEach-Object { '"' + ([string]$_ -replace '"','""') + '"' }) -join ',') }
function Sha256($path) { if(!(Test-Path -LiteralPath $path)) { return 'MISSING' }; return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant() }
function Add-ContentRetry { param($Path,$Value)
    for($i=1; $i -le 20; $i++){
        try { Add-Content -LiteralPath $Path -Encoding UTF8 -Value $Value; return } catch { Start-Sleep -Milliseconds ([Math]::Min(250*$i,3000)) }
    }
    Add-Content -LiteralPath ($Path + '.fallback') -Encoding UTF8 -Value $Value
}
function Add-RunStatus { param($TestName,$Kind,$RunGroupId,$Phase,$StartTime,$EndTime,$ExitCode,$IniPath,$Note)
    $elapsed=''; if($StartTime -and $EndTime){ $elapsed=[int]($EndTime-$StartTime).TotalSeconds }
    Add-ContentRetry -Path $StatusPath -Value (CsvLine @($TestName,$Kind,$RunGroupId,$Phase,$StartTime.ToString('s'),$EndTime.ToString('s'),$elapsed,$ExitCode,$IniPath,$Note))
}
function Stop-TestProcesses { Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'terminal64|metatester64' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }
function Get-AgentLogPath { return (Join-Path $AgentRoot ('logs\' + (Get-Date -Format 'yyyyMMdd') + '.log')) }
function Get-TerminalLogPath { return (Join-Path $TerminalData ('logs\' + (Get-Date -Format 'yyyyMMdd') + '.log')) }
function Read-NewLines { param($Path,$FromLine); if(!(Test-Path -LiteralPath $Path)){ return @() }; $lines=@(Get-Content -LiteralPath $Path); if($lines.Count -le $FromLine){ return @() }; return @($lines[$FromLine..($lines.Count-1)]) }
function Snapshot-AgentFiles { param($Destination); if(Test-Path -LiteralPath $AgentFiles){ Get-ChildItem -LiteralPath $AgentFiles -File -ErrorAction SilentlyContinue | Select-Object FullName,Name,Length,LastWriteTime | Export-Csv -LiteralPath $Destination -NoTypeInformation -Encoding UTF8 } else { 'FullName,Name,Length,LastWriteTime' | Set-Content -LiteralPath $Destination -Encoding UTF8 } }
function Backup-And-Clear-AgentOutputs { param($TestName)
    $backupDir=Join-Path (Join-Path $AuditRoot 'output_listings') ($TestName + '_stale_before'); New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $patterns=@('KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv','KOUCHA_GOLD_ENTRY_OPPORTUNITY_AUDIT.csv','KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK_LOG.csv','KOUCHA_GOLD_ENTRY_DECISION_TRACE.csv','KOUCHA_GOLD_REACTIVE_HEDGE_ELIGIBILITY_TRACE.csv','KOUCHA_GOLD_PERFORMANCE_STATS.csv','KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv','KOUCHA_ML_SHADOW*.csv','KOUCHA_W3_TELEMETRY*.csv')
    foreach($pattern in $patterns){ foreach($item in Get-ChildItem -LiteralPath $AgentFiles -Filter $pattern -File -ErrorAction SilentlyContinue){ Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $backupDir $item.Name) -Force; Remove-Item -LiteralPath $item.FullName -Force -ErrorAction SilentlyContinue } }
}
function Copy-IfExists { param($Source,$Destination); if(Test-Path -LiteralPath $Source){ Copy-Item -LiteralPath $Source -Destination $Destination -Force; return $true }; return $false }
function Copy-RunOutputs { param($TestName)
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv') -Destination (Join-Path (Join-Path $AuditRoot 'trade_exports') ($TestName + '_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv')) | Out-Null
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_PERFORMANCE_STATS.csv') -Destination (Join-Path (Join-Path $AuditRoot 'trade_exports') ($TestName + '_KOUCHA_GOLD_PERFORMANCE_STATS.csv')) | Out-Null
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv') -Destination (Join-Path (Join-Path $AuditRoot 'evidence') ($TestName + '_KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv')) | Out-Null
    foreach($w3 in Get-ChildItem -LiteralPath $AgentFiles -Filter 'KOUCHA_W3_TELEMETRY*.csv' -File -ErrorAction SilentlyContinue){ Copy-Item -LiteralPath $w3.FullName -Destination (Join-Path (Join-Path $AuditRoot 'w3_logs') ($TestName + '_' + $w3.Name)) -Force }
    Copy-IfExists -Source (Get-AgentLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'agent_logs') ($TestName + '_agent_full.log')) | Out-Null
    Copy-IfExists -Source (Get-TerminalLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'journals') ($TestName + '_terminal_full.log')) | Out-Null
}
function SetOrAddInput { param([string]$Text,[string]$Name,[string]$Value)
    $line=$Name + '=' + $Value
    if($Text -match ([regex]::Escape($Name) + '=.*')) { return ($Text -replace ([regex]::Escape($Name) + '=.*'), $line) }
    return $Text + "`r`n" + $line + "`r`n"
}
function New-V2Ini { param($SourceIni,$DestinationIni,$TestName,$FromDate,$ToDate,$Deposit)
    $text=Get-Content -LiteralPath $SourceIni -Raw
    $text=$text -replace 'Expert=.*', 'Expert=KOUCHA_GOLD_KIWAMI_BOX_EVAL_V2.ex5'
    $text=$text -replace 'Report=.*', ('Report=' + (Join-Path (Join-Path $AuditRoot 'reports') ($TestName + '.htm')))
    $text=$text -replace 'ReplaceReport=.*', ('ReplaceReport=' + (Join-Path (Join-Path $AuditRoot 'reports') ($TestName + '.htm')))
    if($FromDate){ $text=$text -replace 'FromDate=.*', ('FromDate=' + $FromDate) }
    if($ToDate){ $text=$text -replace 'ToDate=.*', ('ToDate=' + $ToDate) }
    if($Deposit){ $text=$text -replace 'Deposit=.*', ('Deposit=' + $Deposit) }
    if($text -match 'BacktestPatternName=.*') { $text=$text -replace 'BacktestPatternName=.*', ('BacktestPatternName=' + $TestName) } else { $text=$text -replace '(\[TesterInputs\]\s*)', "`$1`r`nBacktestPatternName=$TestName`r`n" }
    $text=SetOrAddInput $text 'EnableMultilayerShadowLogging' 'false||false||0||true||N'
    $text=SetOrAddInput $text 'W3_LOGGING_ENABLED' 'true||false||0||true||N'
    $text=SetOrAddInput $text 'BOX_ABS_CAP_YEN' ($BoxAbsCapYen + '||2000.0||100.0||5000.0||N')
    $text=SetOrAddInput $text 'BOX_HS_FRACTION' ($BoxHsFraction + '||0.50||0.01||1.00||N')
    $text=SetOrAddInput $text 'UseDefenseHedge' 'false||true||0||true||N'
    $text=SetOrAddInput $text 'UseSinglePositionReactiveDefenseHedge' 'false||true||0||true||N'
    Set-Content -LiteralPath $DestinationIni -Value $text -Encoding Unicode
}

foreach($d in 'configs','reports','trade_exports','w3_logs','agent_logs','journals','output_listings','evidence','validation','source','compile'){ New-Item -ItemType Directory -Force -Path (Join-Path $AuditRoot $d) | Out-Null }
if(!$AppendStatus -or !(Test-Path -LiteralPath $StatusPath)){ '"test_name","kind","run_group_id","phase","start_time","end_time","elapsed_seconds","exit_code","ini_path","note"' | Set-Content -LiteralPath $StatusPath -Encoding UTF8 }
if(!$AppendStatus -or !(Test-Path -LiteralPath $ManifestPath)){ '"test_name","kind","run_group_id","source_ini","ini","expert","from_date","to_date","deposit","survival_sha","survival_ex5_sha","w3_mqh_sha","v1_variant_sha","v2_source_sha","v2_ex5_sha","box_abs_cap_yen","box_hs_fraction","defense_hedge","single_reactive_hedge"' | Set-Content -LiteralPath $ManifestPath -Encoding UTF8 }

$survivalSource=Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5'
$survivalEx5=Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.ex5'
$w3Mqh=Join-Path $TerminalData 'MQL5\Experts\W3Telemetry.mqh'
$v1Source=Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_BOX_EVAL.mq5'
$v2Source=Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_BOX_EVAL_V2.mq5'
$v2Ex5=Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_BOX_EVAL_V2.ex5'
if((Sha256 $survivalSource) -ne $ExpectedSurvivalSha){ throw "Survival source SHA mismatch: $(Sha256 $survivalSource)" }
if((Sha256 $survivalEx5) -ne $ExpectedSurvivalEx5Sha){ throw "Survival EX5 SHA mismatch: $(Sha256 $survivalEx5)" }
if((Sha256 $w3Mqh) -ne $ExpectedW3MqhSha){ throw "W3 mqh SHA mismatch: $(Sha256 $w3Mqh)" }
if((Sha256 $v1Source) -ne $ExpectedV1VariantSha){ throw "v1 variant SHA mismatch: $(Sha256 $v1Source)" }

$sourceConfigs = @(
    @{Run='ML_C_SHADOW_ON_100000_MAR_MAY_M5_20260301_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_ML_C_SHADOW_ON_100000_MAR_MAY_M5_20260301_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_50000_MAR_MAY_M5_20260301_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_ML_C_SHADOW_ON_50000_MAR_MAY_M5_20260301_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_50000_APR_MAY_M5_20260401_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_ML_C_SHADOW_ON_50000_APR_MAY_M5_20260401_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_100000_APR_MAY_M5_20260401_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_ML_C_SHADOW_ON_100000_APR_MAY_M5_20260401_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_50000_MAY_M5_20260501_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_ML_C_SHADOW_ON_50000_MAY_M5_20260501_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_100000_MAY_M5_20260501_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_ML_C_SHADOW_ON_100000_MAY_M5_20260501_20260529.ini'},
    @{Run='JUNE_C_SHADOW_ON_50000_M5_20260601_20260630'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_JUNE_C_SHADOW_ON_50000_M5_20260601_20260630.ini'},
    @{Run='JUNE_C_SHADOW_ON_100000_M5_20260601_20260630'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT\configs\W3_ON_JUNE_C_SHADOW_ON_100000_M5_20260601_20260630.ini'}
)

$tests=@()
foreach($cfg in $sourceConfigs){
    $name='BOX_V2_' + $cfg.Run
    $ini=Join-Path (Join-Path $AuditRoot 'configs') ($name + '.ini')
    New-V2Ini -SourceIni $cfg.Ini -DestinationIni $ini -TestName $name -FromDate $null -ToDate $null -Deposit $null
    $tests += [pscustomobject]@{TestName=$name;Kind='BOX_V2';RunGroupId=$cfg.Run;Ini=$ini}
}
foreach($dep in @('50000','100000')){
    $template = if($dep -eq '50000'){ $sourceConfigs[1].Ini } else { $sourceConfigs[0].Ini }
    $name='BOX_V2_W4_' + $dep + '_FEB2026_UPTREND_M5_20260202_20260227'
    $ini=Join-Path (Join-Path $AuditRoot 'configs') ($name + '.ini')
    New-V2Ini -SourceIni $template -DestinationIni $ini -TestName $name -FromDate '2026.02.02' -ToDate '2026.02.27' -Deposit $dep
    $tests += [pscustomobject]@{TestName=$name;Kind='BOX_V2_W4';RunGroupId='W4_FEB2026_UPTREND';Ini=$ini}
}

foreach($t in $tests){
    Add-ContentRetry -Path $ManifestPath -Value (CsvLine @($t.TestName,$t.Kind,$t.RunGroupId,'GENERATED',$t.Ini,((Select-String -Path $t.Ini -Pattern '^Expert=').Line -replace '^Expert=',''),((Select-String -Path $t.Ini -Pattern '^FromDate=').Line -replace '^FromDate=',''),((Select-String -Path $t.Ini -Pattern '^ToDate=').Line -replace '^ToDate=',''),((Select-String -Path $t.Ini -Pattern '^Deposit=').Line -replace '^Deposit=',''),(Sha256 $survivalSource),(Sha256 $survivalEx5),(Sha256 $w3Mqh),(Sha256 $v1Source),(Sha256 $v2Source),(Sha256 $v2Ex5),$BoxAbsCapYen,$BoxHsFraction,'false','false'))
}
if($Pattern -ne 'ALL'){ $tests=@($tests | Where-Object { $_.TestName -like "*$Pattern*" -or $_.RunGroupId -like "*$Pattern*" -or $_.Kind -eq $Pattern }) }
if($SkipCompleted -and (Test-Path -LiteralPath $StatusPath)){
    $completed=@{}
    try{ Import-Csv -LiteralPath $StatusPath | Where-Object { $_.phase -eq 'END' } | ForEach-Object { $completed[$_.test_name]=$true }; $tests=@($tests | Where-Object { -not $completed.ContainsKey($_.TestName) }) } catch {}
}

Stop-TestProcesses
Start-Sleep -Seconds 2
foreach($test in $tests){
    $start=Get-Date
    Add-RunStatus -TestName $test.TestName -Kind $test.Kind -RunGroupId $test.RunGroupId -Phase 'START' -StartTime $start -EndTime $start -ExitCode '' -IniPath $test.Ini -Note 'starting terminal tester run'
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_before.csv'))
    Backup-And-Clear-AgentOutputs -TestName $test.TestName
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_after_clear.csv'))
    $agentLog=Get-AgentLogPath; $agentStartLine=if(Test-Path -LiteralPath $agentLog){ @(Get-Content -LiteralPath $agentLog).Count } else { 0 }
    $terminalLog=Get-TerminalLogPath; $terminalStartLine=if(Test-Path -LiteralPath $terminalLog){ @(Get-Content -LiteralPath $terminalLog).Count } else { 0 }
    $proc=Start-Process -FilePath $TerminalExe -ArgumentList "/config:`"$($test.Ini)`"" -WindowStyle Hidden -PassThru
    $timeoutSeconds=10800
    $lastHeartbeat=Get-Date
    $completedByLog=$false
    while(!$proc.HasExited){
        Start-Sleep -Seconds 10
        $now=Get-Date
        if(($now-$lastHeartbeat).TotalSeconds -ge 60){
            $lastAgent=(Read-NewLines -Path $agentLog -FromLine $agentStartLine | Select-Object -Last 1)
            Add-RunStatus -TestName $test.TestName -Kind $test.Kind -RunGroupId $test.RunGroupId -Phase 'HEARTBEAT' -StartTime $start -EndTime $now -ExitCode '' -IniPath $test.Ini -Note $lastAgent
            $lastHeartbeat=$now
        }
        $runLines=Read-NewLines -Path $agentLog -FromLine $agentStartLine
        if($runLines -match 'tester stopped|MetaTester 5 stopped|shutdown finished|thread finished'){ $completedByLog=$true }
        if(($now-$start).TotalSeconds -gt $timeoutSeconds){
            Add-RunStatus -TestName $test.TestName -Kind $test.Kind -RunGroupId $test.RunGroupId -Phase 'TIMEOUT' -StartTime $start -EndTime $now -ExitCode '' -IniPath $test.Ini -Note 'timeout 10800 seconds'
            Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
            break
        }
    }
    $end=Get-Date; $exitCode=''; try{ $exitCode=$proc.ExitCode }catch{}
    Add-RunStatus -TestName $test.TestName -Kind $test.Kind -RunGroupId $test.RunGroupId -Phase 'END' -StartTime $start -EndTime $end -ExitCode $exitCode -IniPath $test.Ini -Note ($(if($completedByLog){'completion marker observed'}else{'process exited or stopped'}))
    Copy-RunOutputs -TestName $test.TestName
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_after.csv'))
    (Read-NewLines -Path $agentLog -FromLine $agentStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'agent_logs') ($test.TestName + '_agent_window.log')) -Encoding UTF8
    (Read-NewLines -Path $terminalLog -FromLine $terminalStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'journals') ($test.TestName + '_terminal_window.log')) -Encoding UTF8
}
Stop-TestProcesses
Write-Host "Finished BOX eval v2 runs in $AuditRoot"
