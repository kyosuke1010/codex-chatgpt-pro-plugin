
param(
    [string]$Pattern = 'ALL',
    [switch]$AppendStatus,
    [switch]$SkipCompleted
)

$ErrorActionPreference = 'Stop'
$Workspace = 'C:\Users\user\Documents\New project'
$AuditRoot = Join-Path $Workspace 'KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT'
$TerminalExe = 'C:\Program Files\XMTrading MT5\terminal64.exe'
$TerminalData = 'C:\Users\user\AppData\Roaming\MetaQuotes\Terminal\2FA8A7E69CED7DC259B1AD86A247F675'
$TesterRoot = 'C:\Users\user\AppData\Roaming\MetaQuotes\Tester\2FA8A7E69CED7DC259B1AD86A247F675'
$AgentRoot = Join-Path $TesterRoot 'Agent-127.0.0.1-3000'
$AgentFiles = Join-Path $AgentRoot 'MQL5\Files'
$StatusPath = Join-Path $AuditRoot 'w3_run_status.csv'
$ManifestPath = Join-Path $AuditRoot 'w3_execution_manifest.csv'
$TerminalSource = Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.mq5'
$TerminalEx5 = Join-Path $TerminalData 'MQL5\Experts\KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK.ex5'
$ExpectedSourceSha = 'C1DBE51A9FBBBAE0029C63588961A19BA4A0CD2F0EEE1C237169805ADC27AD51'
$ExpectedW3MqhSha = '36FC7066B107A2DA8DBD8F2F2146A55FAB48AAC6BFBB53D68A594685A91F6B7E'

function CsvLine($values) { return (($values | ForEach-Object { '"' + ([string]$_ -replace '"','""') + '"' }) -join ',') }
function Add-ContentRetry { param($Path,$Value)
    $lastError=$null
    for($attempt=1; $attempt -le 20; $attempt++){
        try{
            Add-Content -LiteralPath $Path -Encoding UTF8 -Value $Value
            return
        } catch {
            $lastError=$_
            Start-Sleep -Milliseconds ([Math]::Min(250 * $attempt, 3000))
        }
    }
    $fallback = Join-Path (Split-Path -Parent $Path) ((Split-Path -Leaf $Path) + '.fallback')
    Add-Content -LiteralPath $fallback -Encoding UTF8 -Value $Value
    Add-Content -LiteralPath $fallback -Encoding UTF8 -Value (CsvLine @('WRITE_RETRY_EXHAUSTED',(Get-Date).ToString('s'),$Path,$lastError.Exception.Message))
}
function Sha256($path) { if(!(Test-Path -LiteralPath $path)) { return 'MISSING' }; return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToUpperInvariant() }
function Add-RunStatus { param($TestName,$Series,$RunGroupId,$Phase,$StartTime,$EndTime,$ExitCode,$IniPath,$Note)
    $elapsed=''; if($StartTime -and $EndTime){ $elapsed=[int]($EndTime-$StartTime).TotalSeconds }
    Add-ContentRetry -Path $StatusPath -Value (CsvLine @($TestName,$Series,$RunGroupId,$Phase,$StartTime.ToString('s'),$EndTime.ToString('s'),$elapsed,$ExitCode,$IniPath,$Note))
}
function Stop-TestProcesses { Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'terminal64|metatester64' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }
function Get-AgentLogPath { return (Join-Path $AgentRoot ('logs\' + (Get-Date -Format 'yyyyMMdd') + '.log')) }
function Get-TerminalLogPath { return (Join-Path $TerminalData ('logs\' + (Get-Date -Format 'yyyyMMdd') + '.log')) }
function Get-ExpertsLogPath { return (Join-Path $TerminalData ('MQL5\Logs\' + (Get-Date -Format 'yyyyMMdd') + '.log')) }
function Read-NewLines { param($Path,$FromLine); if(!(Test-Path -LiteralPath $Path)){ return @() }; $lines=@(Get-Content -LiteralPath $Path); if($lines.Count -le $FromLine){ return @() }; return @($lines[$FromLine..($lines.Count-1)]) }
function Snapshot-AgentFiles { param($Destination); if(Test-Path -LiteralPath $AgentFiles){ Get-ChildItem -LiteralPath $AgentFiles -File -ErrorAction SilentlyContinue | Select-Object FullName,Name,Length,LastWriteTime | Export-Csv -LiteralPath $Destination -NoTypeInformation -Encoding UTF8 } else { 'FullName,Name,Length,LastWriteTime' | Set-Content -LiteralPath $Destination -Encoding UTF8 } }
function Backup-And-Clear-AgentOutputs { param($TestName)
    $backupDir=Join-Path (Join-Path $AuditRoot 'output_listings') ($TestName + '_stale_before'); New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    $patterns=@('KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv','KOUCHA_GOLD_ENTRY_OPPORTUNITY_AUDIT.csv','KOUCHA_GOLD_KIWAMI_SURVIVAL_TICK_LOG.csv','KOUCHA_GOLD_ENTRY_DECISION_TRACE.csv','KOUCHA_GOLD_REACTIVE_HEDGE_ELIGIBILITY_TRACE.csv','KOUCHA_GOLD_PERFORMANCE_STATS.csv','KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv','KOUCHA_ML_SHADOW*.csv','KOUCHA_W3_TELEMETRY*.csv')
    foreach($pattern in $patterns){ foreach($item in Get-ChildItem -LiteralPath $AgentFiles -Filter $pattern -File -ErrorAction SilentlyContinue){ Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $backupDir $item.Name) -Force; Remove-Item -LiteralPath $item.FullName -Force -ErrorAction SilentlyContinue } }
}
function Copy-IfExists { param($Source,$Destination); if(Test-Path -LiteralPath $Source){ Copy-Item -LiteralPath $Source -Destination $Destination -Force; return $true }; return $false }
function Copy-RunOutputs { param($TestName)
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv') -Destination (Join-Path (Join-Path $AuditRoot 'trade_exports') ($TestName + '_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv')) | Out-Null
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_PERFORMANCE_STATS.csv') -Destination (Join-Path (Join-Path $AuditRoot 'trade_exports') ($TestName + '_KOUCHA_GOLD_PERFORMANCE_STATS.csv')) | Out-Null
    Copy-IfExists -Source (Join-Path $AgentFiles 'KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv') -Destination (Join-Path (Join-Path $AuditRoot 'evidence') ($TestName + '_KOUCHA_GOLD_COPYBUFFER_BREAKDOWN.csv')) | Out-Null
    foreach($shadow in Get-ChildItem -LiteralPath $AgentFiles -Filter 'KOUCHA_ML_SHADOW*.csv' -File -ErrorAction SilentlyContinue){ Copy-Item -LiteralPath $shadow.FullName -Destination (Join-Path (Join-Path $AuditRoot 'shadow_logs') ($TestName + '_' + $shadow.Name)) -Force }
    foreach($w3 in Get-ChildItem -LiteralPath $AgentFiles -Filter 'KOUCHA_W3_TELEMETRY*.csv' -File -ErrorAction SilentlyContinue){ Copy-Item -LiteralPath $w3.FullName -Destination (Join-Path (Join-Path $AuditRoot 'w3_logs') ($TestName + '_' + $w3.Name)) -Force }
    Copy-IfExists -Source (Get-AgentLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'agent_logs') ($TestName + '_agent_full.log')) | Out-Null
    Copy-IfExists -Source (Get-TerminalLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'journals') ($TestName + '_terminal_full.log')) | Out-Null
    Copy-IfExists -Source (Get-ExpertsLogPath) -Destination (Join-Path (Join-Path $AuditRoot 'expert_logs') ($TestName + '_experts_full.log')) | Out-Null
}
function New-W3Ini { param($SourceIni,$DestinationIni,$TestName,$W3Enabled)
    $text=Get-Content -LiteralPath $SourceIni -Raw
    $text=$text -replace 'Report=.*', ('Report=' + (Join-Path (Join-Path $AuditRoot 'reports') ($TestName + '.htm')))
    if($text -match 'BacktestPatternName=.*') { $text=$text -replace 'BacktestPatternName=.*', ('BacktestPatternName=' + $TestName) } else { $text=$text -replace '(\[TesterInputs\]\s*)', "`$1`r`nBacktestPatternName=$TestName`r`n" }
    $mlLine='EnableMultilayerShadowLogging=false||false||0||true||N'
    if($text -match 'EnableMultilayerShadowLogging=.*') { $text=$text -replace 'EnableMultilayerShadowLogging=.*', $mlLine } else { $text += "`r`n" + $mlLine + "`r`n" }
    $line='W3_LOGGING_ENABLED=' + ($(if($W3Enabled){'true'}else{'false'})) + '||false||0||true||N'
    if($text -match 'W3_LOGGING_ENABLED=.*') { $text=$text -replace 'W3_LOGGING_ENABLED=.*', $line } else { $text += "`r`n" + $line + "`r`n" }
    Set-Content -LiteralPath $DestinationIni -Value $text -Encoding Unicode
}

foreach($d in 'configs','sets','reports','trade_exports','shadow_logs','w3_logs','agent_logs','journals','expert_logs','output_listings','evidence'){ New-Item -ItemType Directory -Force -Path (Join-Path $AuditRoot $d) | Out-Null }
if(!$AppendStatus -or !(Test-Path -LiteralPath $StatusPath)){
    '"test_name","series","run_group_id","phase","start_time","end_time","elapsed_seconds","exit_code","ini_path","note"' | Set-Content -LiteralPath $StatusPath -Encoding UTF8
}
if(!$AppendStatus -or !(Test-Path -LiteralPath $ManifestPath)){
    '"test_name","series","run_group_id","source_ini","ini","source_sha","ex5_sha","w3_mqh_sha","w3_enabled"' | Set-Content -LiteralPath $ManifestPath -Encoding UTF8
}

if((Sha256 $TerminalSource) -ne $ExpectedSourceSha){ throw "Terminal source SHA mismatch: $(Sha256 $TerminalSource)" }
if((Sha256 (Join-Path $TerminalData 'MQL5\Experts\W3Telemetry.mqh')) -ne $ExpectedW3MqhSha){ throw "W3 mqh SHA mismatch" }

$sourceConfigs = @(
    @{Run='ML_C_SHADOW_ON_100000_MAR_MAY_M5_20260301_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT\configs\ML_C_SHADOW_ON_100000_MAR_MAY_M5_20260301_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_50000_MAR_MAY_M5_20260301_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT\configs\ML_C_SHADOW_ON_50000_MAR_MAY_M5_20260301_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_50000_APR_MAY_M5_20260401_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT\configs\ML_C_SHADOW_ON_50000_APR_MAY_M5_20260401_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_100000_APR_MAY_M5_20260401_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT\configs\ML_C_SHADOW_ON_100000_APR_MAY_M5_20260401_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_50000_MAY_M5_20260501_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT\configs\ML_C_SHADOW_ON_50000_MAY_M5_20260501_20260529.ini'},
    @{Run='ML_C_SHADOW_ON_100000_MAY_M5_20260501_20260529'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_MULTILAYER_PHASE1_SHADOW_FIX_AUDIT\configs\ML_C_SHADOW_ON_100000_MAY_M5_20260501_20260529.ini'},
    @{Run='JUNE_C_SHADOW_ON_50000_M5_20260601_20260630'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_PREHEDGE_PROSPECTIVE_JUNE2026_COLLECTION\configs\JUNE_C_SHADOW_ON_50000_M5_20260601_20260630.ini'},
    @{Run='JUNE_C_SHADOW_ON_100000_M5_20260601_20260630'; Ini='C:\Users\user\Documents\New project\KOUCHA_GOLD_PREHEDGE_PROSPECTIVE_JUNE2026_COLLECTION\configs\JUNE_C_SHADOW_ON_100000_M5_20260601_20260630.ini'}
)

$tests=@()
foreach($cfg in $sourceConfigs){
    foreach($series in @('W3_OFF','W3_ON')){
        $enabled=($series -eq 'W3_ON')
        $testName=$series + '_' + $cfg.Run
        $ini=Join-Path (Join-Path $AuditRoot 'configs') ($testName + '.ini')
        New-W3Ini -SourceIni $cfg.Ini -DestinationIni $ini -TestName $testName -W3Enabled $enabled
        Add-ContentRetry -Path $ManifestPath -Value (CsvLine @($testName,$series,$cfg.Run,$cfg.Ini,$ini,(Sha256 $TerminalSource),(Sha256 $TerminalEx5),(Sha256 (Join-Path $TerminalData 'MQL5\Experts\W3Telemetry.mqh')),$enabled))
        $tests += [pscustomobject]@{TestName=$testName;Series=$series;RunGroupId=$cfg.Run;Ini=$ini}
    }
}

if($Pattern -ne 'ALL'){ $tests=@($tests | Where-Object { $_.TestName -like "*$Pattern*" -or $_.RunGroupId -like "*$Pattern*" -or $_.Series -eq $Pattern }) }
if($SkipCompleted -and (Test-Path -LiteralPath $StatusPath)){
    $completed=@{}
    try{
        Import-Csv -LiteralPath $StatusPath | Where-Object { $_.phase -eq 'END' } | ForEach-Object { $completed[$_.test_name]=$true }
        $tests=@($tests | Where-Object { -not $completed.ContainsKey($_.TestName) })
    } catch {}
}

Stop-TestProcesses
Start-Sleep -Seconds 2
foreach($test in $tests){
    $start=Get-Date
    Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'START' -StartTime $start -EndTime $start -ExitCode '' -IniPath $test.Ini -Note 'starting terminal tester run'
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_before.csv'))
    Backup-And-Clear-AgentOutputs -TestName $test.TestName
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_after_clear.csv'))
    $agentLog=Get-AgentLogPath; $agentStartLine=if(Test-Path -LiteralPath $agentLog){ @(Get-Content -LiteralPath $agentLog).Count } else { 0 }
    $terminalLog=Get-TerminalLogPath; $terminalStartLine=if(Test-Path -LiteralPath $terminalLog){ @(Get-Content -LiteralPath $terminalLog).Count } else { 0 }
    $expertsLog=Get-ExpertsLogPath; $expertsStartLine=if(Test-Path -LiteralPath $expertsLog){ @(Get-Content -LiteralPath $expertsLog).Count } else { 0 }
    $proc=Start-Process -FilePath $TerminalExe -ArgumentList "/config:`"$($test.Ini)`"" -WindowStyle Hidden -PassThru
    $timeoutSeconds=10800
    $lastHeartbeat=Get-Date
    $completedByLog=$false
    while(!$proc.HasExited){
        Start-Sleep -Seconds 10
        $now=Get-Date
        if(($now-$lastHeartbeat).TotalSeconds -ge 60){
            $newLines=Read-NewLines -Path $agentLog -FromLine $agentStartLine
            $lastAgent=($newLines | Select-Object -Last 1)
            Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'HEARTBEAT' -StartTime $start -EndTime $now -ExitCode '' -IniPath $test.Ini -Note $lastAgent
            $lastHeartbeat=$now
        }
        $runLines=Read-NewLines -Path $agentLog -FromLine $agentStartLine
        if($runLines -match 'tester stopped|MetaTester 5 stopped|shutdown finished|thread finished'){ $completedByLog=$true }
        if(($now-$start).TotalSeconds -gt $timeoutSeconds){
            Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase 'TIMEOUT' -StartTime $start -EndTime $now -ExitCode '' -IniPath $test.Ini -Note 'timeout 10800 seconds'
            Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue
            break
        }
    }
    $end=Get-Date; $exitCode=''; try{ $exitCode=$proc.ExitCode }catch{}
    $phase=if($completedByLog -or $proc.HasExited){'END'}else{'END_UNKNOWN'}
    Add-RunStatus -TestName $test.TestName -Series $test.Series -RunGroupId $test.RunGroupId -Phase $phase -StartTime $start -EndTime $end -ExitCode $exitCode -IniPath $test.Ini -Note ($(if($completedByLog){'completion marker observed'}else{'process exited or stopped'}))
    Copy-RunOutputs -TestName $test.TestName
    Snapshot-AgentFiles -Destination (Join-Path (Join-Path $AuditRoot 'output_listings') ($test.TestName + '_agent_files_after.csv'))
    (Read-NewLines -Path $agentLog -FromLine $agentStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'agent_logs') ($test.TestName + '_agent_window.log')) -Encoding UTF8
    (Read-NewLines -Path $terminalLog -FromLine $terminalStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'journals') ($test.TestName + '_terminal_window.log')) -Encoding UTF8
    (Read-NewLines -Path $expertsLog -FromLine $expertsStartLine) | Set-Content -LiteralPath (Join-Path (Join-Path $AuditRoot 'expert_logs') ($test.TestName + '_experts_window.log')) -Encoding UTF8
}
Stop-TestProcesses
Write-Host "Finished W3 runs in $AuditRoot"
