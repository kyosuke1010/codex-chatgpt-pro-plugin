import csv
import hashlib
from pathlib import Path

ROOT = Path(r"C:\Users\user\Documents\New project\KOUCHA_GOLD_W3_TELEMETRY_IMPLEMENTATION_AUDIT")
TRADE_DIR = ROOT / "trade_exports"
W3_DIR = ROOT / "w3_logs"
OUT_DIR = ROOT / "validation"
OUT_DIR.mkdir(exist_ok=True)

REQUIRED_W3_COLUMNS = [
    "schema_version",
    "build_id",
    "run_id",
    "event_sequence",
    "event_type",
    "module_name",
    "basket_uid",
    "server_time",
    "server_time_msc",
    "stage",
    "distance_to_hs_yen",
    "distance_to_hs_price",
    "threshold_gap_yen",
    "threshold_gap_price",
    "logger_state",
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def rows(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="", errors="replace") as f:
        yield from csv.DictReader(f)


trade_files = list(TRADE_DIR.glob("*_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv"))
groups = {}
for p in trade_files:
    name = p.name.replace("_KOUCHA_GOLD_KIWAMI_TRADE_EVENTS.csv", "")
    if name.startswith("W3_OFF_"):
        groups.setdefault(name[len("W3_OFF_") :], {})["OFF"] = p
    elif name.startswith("W3_ON_"):
        groups.setdefault(name[len("W3_ON_") :], {})["ON"] = p

compare_rows = []
schema_rows = []
coverage_rows = []
all_pass = True

for group in sorted(groups):
    off = groups[group].get("OFF")
    on = groups[group].get("ON")
    off_exists = off is not None and off.exists()
    on_exists = on is not None and on.exists()
    off_sha = sha256(off) if off_exists else "MISSING"
    on_sha = sha256(on) if on_exists else "MISSING"
    byte_equal = off_exists and on_exists and off.read_bytes() == on.read_bytes()
    off_w3 = sorted(W3_DIR.glob(f"W3_OFF_{group}_KOUCHA_W3_TELEMETRY*.csv"))
    on_w3 = sorted(W3_DIR.glob(f"W3_ON_{group}_KOUCHA_W3_TELEMETRY*.csv"))
    row = {
        "run_group_id": group,
        "off_trade_exists": str(off_exists).upper(),
        "on_trade_exists": str(on_exists).upper(),
        "off_trade_sha256": off_sha,
        "on_trade_sha256": on_sha,
        "trade_byte_equal": str(byte_equal).upper(),
        "w3_off_csv_count": len(off_w3),
        "w3_on_csv_count": len(on_w3),
        "pass": str(byte_equal and len(off_w3) == 0 and len(on_w3) == 1).upper(),
    }
    compare_rows.append(row)
    if row["pass"] != "TRUE":
        all_pass = False

    for w3 in on_w3:
        count = 0
        schema_violation = 0
        event_seq_dup = 0
        event_seq_regression = 0
        logger_error = 0
        dropped = 0
        unknown_false = 0
        malformed = 0
        run_summary = 0
        basket_summary = 0
        last_seq = None
        seen = set()
        header = []
        try:
            with w3.open("r", encoding="utf-8-sig", newline="", errors="replace") as f:
                reader = csv.DictReader(f)
                header = reader.fieldnames or []
                missing = [c for c in REQUIRED_W3_COLUMNS if c not in header]
                for r in reader:
                    count += 1
                    if missing:
                        schema_violation += 1
                    try:
                        seq = int(r.get("event_sequence", ""))
                        if seq in seen:
                            event_seq_dup += 1
                        seen.add(seq)
                        if last_seq is not None and seq < last_seq:
                            event_seq_regression += 1
                        last_seq = seq
                    except Exception:
                        malformed += 1
                    if (r.get("logger_state") or "OK") not in ("OK", "UNKNOWN", "MISSING", ""):
                        logger_error += 1
                    detail = (r.get("detail") or "").upper()
                    if "DROPPED_ROWS=" in detail:
                        try:
                            if int(detail.split("DROPPED_ROWS=", 1)[1].split("|", 1)[0]) != 0:
                                dropped += 1
                        except Exception:
                            dropped += 1
                    elif "DROPPED" in detail or "DROP_ERROR" in detail:
                        dropped += 1
                    # Conservative check: do not count ordinary FALSE booleans as UNKNOWN conversion.
                    for key in ("distance_to_hs_yen", "distance_to_hs_price", "threshold_gap_yen", "threshold_gap_price"):
                        if (r.get(key) or "").strip().upper() == "FALSE":
                            unknown_false += 1
                    et = (r.get("event_type") or "").upper()
                    if et in ("RUN_SUMMARY", "W3_RUN_SUMMARY"):
                        run_summary += 1
                    if et == "BASKET_SUMMARY":
                        basket_summary += 1
        except Exception:
            malformed += 1
        schema_pass = (
            count > 0
            and schema_violation == 0
            and event_seq_dup == 0
            and event_seq_regression == 0
            and logger_error == 0
            and dropped == 0
            and unknown_false == 0
            and malformed == 0
            and run_summary >= 1
        )
        if not schema_pass:
            all_pass = False
        schema_rows.append(
            {
                "run_group_id": group,
                "w3_csv": str(w3),
                "sha256": sha256(w3),
                "row_count": count,
                "schema_missing_columns": "|".join([c for c in REQUIRED_W3_COLUMNS if c not in header]),
                "schema_violation_count": schema_violation,
                "event_sequence_duplicate_count": event_seq_dup,
                "event_sequence_regression_count": event_seq_regression,
                "malformed_row_count": malformed,
                "logger_error_count": logger_error,
                "dropped_row_count": dropped,
                "unknown_false_conversion_count": unknown_false,
                "basket_summary_count": basket_summary,
                "run_summary_count": run_summary,
                "schema_pass": str(schema_pass).upper(),
            }
        )

        event_counts = {}
        for r in rows(w3):
            event_counts[r.get("event_type", "UNKNOWN")] = event_counts.get(r.get("event_type", "UNKNOWN"), 0) + 1
        for event_type, n in sorted(event_counts.items()):
            coverage_rows.append({"run_group_id": group, "event_type": event_type, "count": n})


def write_csv(path: Path, data):
    data = list(data)
    if not data:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(data[0].keys()))
        w.writeheader()
        w.writerows(data)


write_csv(OUT_DIR / "w3_trade_fingerprint_compare.csv", compare_rows)
write_csv(OUT_DIR / "w3_schema_validation.csv", schema_rows)
write_csv(OUT_DIR / "w3_event_coverage_summary.csv", coverage_rows)

summary = [
    f"w3_validation_pass={str(all_pass).upper()}",
    f"run_group_count={len(groups)}",
    f"trade_pair_pass_count={sum(1 for r in compare_rows if r['pass'] == 'TRUE')}",
    f"schema_pass_count={sum(1 for r in schema_rows if r['schema_pass'] == 'TRUE')}",
    f"w3_on_csv_count={len(schema_rows)}",
    f"w3_off_csv_total={sum(int(r['w3_off_csv_count']) for r in compare_rows)}",
]
(OUT_DIR / "w3_validation_summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")
print("\n".join(summary))
