#ifndef KOUCHA_W3_TELEMETRY_MQH
#define KOUCHA_W3_TELEMETRY_MQH

#define W3_TELEMETRY_SCHEMA_VERSION "W3.1"
#define W3_TELEMETRY_BUILD_ID "W3_TELEMETRY_20260711"
#define W3_TELEMETRY_MISSING "MISSING"

string w3RunId = "";
string w3LogFileName = "";
bool w3HeaderWritten = false;
bool w3LoggerHealthy = true;
bool w3LoggerErrorPrinted = false;
int w3LoggerOpenErrorCount = 0;
int w3LoggerWriteErrorCount = 0;
int w3DroppedRows = 0;
long w3EventSequence = 0;
datetime w3RunStartTime = 0;

bool w3BasketActive = false;
string w3BasketUid = "";
datetime w3BasketStartTime = 0;
datetime w3FirstHedgeTime = 0;
datetime w3LastPeriodicSnapshotTime = 0;
double w3WorstFloatingPreHedge = 0.0;
double w3WorstFloatingPostHedge = 0.0;
double w3WorstFloatingLifecycle = 0.0;
datetime w3WorstFloatingTime = 0;
double w3WorstFloatingPrice = 0.0;
bool w3Hedged = false;
bool w3HardStopConditionSeen = false;
datetime w3HardStopConditionTime = 0;
double w3HardStopConditionPl = 0.0;
double w3HardStopConditionLoss = 0.0;
double w3HardStopConditionDistanceYen = 0.0;
double w3HardStopConditionPrice = 0.0;

int w3BasketOpenCount = 0;
int w3HedgeTimingCount = 0;
int w3HardStopConditionCount = 0;
int w3HardStopRequestCount = 0;
int w3CloseAnchorCount = 0;
int w3WorstFloatingUpdateCount = 0;
int w3PeriodicSnapshotCount = 0;

bool W3TelemetryEnabled()
{
   return W3_LOGGING_ENABLED;
}

string W3BoolText(bool value)
{
   return value ? "TRUE" : "FALSE";
}

string W3SafeToken(string text)
{
   StringReplace(text, " ", "_");
   StringReplace(text, ":", "");
   StringReplace(text, ".", "");
   StringReplace(text, "#", "_");
   StringReplace(text, "\\", "_");
   StringReplace(text, "/", "_");
   StringReplace(text, "-", "");
   return text;
}

string W3TimeText(datetime value)
{
   if(value <= 0)
      return W3_TELEMETRY_MISSING;
   return TimeToString(value, TIME_DATE | TIME_SECONDS);
}

string W3DoubleText(double value, int digits = 2)
{
   if(!MathIsValidNumber(value))
      return W3_TELEMETRY_MISSING;
   return DoubleToString(value, digits);
}

void W3CsvAppend(string &line, string value)
{
   StringReplace(value, "\"", "\"\"");
   if(line != "")
      line += ",";
   line += "\"" + value + "\"";
}

string W3TfText()
{
   return EnumToString((ENUM_TIMEFRAMES)_Period);
}

double W3FloatingLossYen(const PositionState &ps)
{
   if(ps.floatingProfit < 0.0)
      return -ps.floatingProfit;
   return 0.0;
}

double W3DistanceToHardStopYen(const PositionState &ps, double thresholdYen)
{
   return thresholdYen - W3FloatingLossYen(ps);
}

ulong W3EarliestEaPositionTicket(datetime &firstOpenTime)
{
   firstOpenTime = 0;
   ulong firstTicket = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;
      datetime openTime = (datetime)PositionGetInteger(POSITION_TIME);
      if(firstOpenTime == 0 || openTime < firstOpenTime || (openTime == firstOpenTime && ticket < firstTicket))
      {
         firstOpenTime = openTime;
         firstTicket = ticket;
      }
   }
   return firstTicket;
}

string W3BasketUidNoRuntimeMutation(const PositionState &ps)
{
   datetime firstOpenTime = 0;
   ulong firstTicket = W3EarliestEaPositionTicket(firstOpenTime);
   datetime basketStart = firstOpenTime;
   if(basketStart <= 0)
      basketStart = TimeCurrent();
   string timeText = TimeToString(basketStart, TIME_DATE | TIME_SECONDS);
   StringReplace(timeText, " ", "T");
   return _Symbol + "#" + timeText + "#" + IntegerToString((long)firstTicket) + "#" + IntegerToString(ps.net) + "#" + IntegerToString(ps.total);
}

void W3LegStats(double &mainProfit,
                double &hedgeProfit,
                double &mainLots,
                double &hedgeLots,
                string &mainSide,
                string &hedgeSide,
                int &positionCount)
{
   mainProfit = 0.0;
   hedgeProfit = 0.0;
   mainLots = 0.0;
   hedgeLots = 0.0;
   mainSide = W3_TELEMETRY_MISSING;
   hedgeSide = W3_TELEMETRY_MISSING;
   positionCount = 0;

   datetime firstOpenTime = 0;
   ulong firstTicket = W3EarliestEaPositionTicket(firstOpenTime);
   ENUM_POSITION_TYPE mainType = POSITION_TYPE_BUY;
   bool mainTypeKnown = false;
   if(firstTicket != 0 && PositionSelectByTicket(firstTicket))
   {
      mainType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      mainSide = (mainType == POSITION_TYPE_BUY ? "BUY" : "SELL");
      mainTypeKnown = true;
   }

   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;

      positionCount++;
      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double lots = PositionGetDouble(POSITION_VOLUME);
      double profit = PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
      if(mainTypeKnown && type == mainType)
      {
         mainProfit += profit;
         mainLots += lots;
      }
      else
      {
         hedgeProfit += profit;
         hedgeLots += lots;
         hedgeSide = (type == POSITION_TYPE_BUY ? "BUY" : "SELL");
      }
   }
}

double W3NetLots()
{
   double buyLots = 0.0;
   double sellLots = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0 || !PositionSelectByTicket(ticket))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != _Symbol)
         continue;
      if((ulong)PositionGetInteger(POSITION_MAGIC) != MagicNumber)
         continue;
      double lots = PositionGetDouble(POSITION_VOLUME);
      ENUM_POSITION_TYPE type = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      if(type == POSITION_TYPE_BUY)
         buyLots += lots;
      else if(type == POSITION_TYPE_SELL)
         sellLots += lots;
   }
   return buyLots - sellLots;
}

string W3DistanceToHardStopPriceText(double distanceYen)
{
   double netLots = MathAbs(W3NetLots());
   if(netLots <= 0.0 || !MathIsValidNumber(distanceYen))
      return W3_TELEMETRY_MISSING;
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickValue <= 0.0 || tickSize <= 0.0)
      return W3_TELEMETRY_MISSING;
   double yenPerPrice = (tickValue / tickSize) * netLots;
   if(yenPerPrice <= 0.0)
      return W3_TELEMETRY_MISSING;
   return W3DoubleText(distanceYen / yenPerPrice, _Digits);
}

void W3EnsureRunId()
{
   if(w3RunId != "")
      return;
   string token = BacktestPatternName;
   if(token == "")
      token = _Symbol + "_" + TimeToString(TimeLocal(), TIME_DATE | TIME_SECONDS) + "_" + IntegerToString((int)GetTickCount());
   w3RunId = W3SafeToken(token);
   w3LogFileName = "KOUCHA_W3_TELEMETRY_" + w3RunId + ".csv";
   if(w3RunStartTime <= 0)
      w3RunStartTime = TimeCurrent();
}

string W3HeaderLine()
{
   string line = "";
   W3CsvAppend(line, "schema_version");
   W3CsvAppend(line, "build_id");
   W3CsvAppend(line, "run_id");
   W3CsvAppend(line, "event_sequence");
   W3CsvAppend(line, "event_type");
   W3CsvAppend(line, "module_name");
   W3CsvAppend(line, "basket_uid");
   W3CsvAppend(line, "symbol");
   W3CsvAppend(line, "timeframe");
   W3CsvAppend(line, "server_time");
   W3CsvAppend(line, "server_time_msc");
   W3CsvAppend(line, "tick_sequence_id");
   W3CsvAppend(line, "stage");
   W3CsvAppend(line, "bid");
   W3CsvAppend(line, "ask");
   W3CsvAppend(line, "spread_price");
   W3CsvAppend(line, "margin_level");
   W3CsvAppend(line, "position_count");
   W3CsvAppend(line, "basket_floating_pl");
   W3CsvAppend(line, "floating_loss_yen");
   W3CsvAppend(line, "hardstop_threshold_yen");
   W3CsvAppend(line, "distance_to_hs_yen");
   W3CsvAppend(line, "distance_to_hs_price");
   W3CsvAppend(line, "hardstop_now");
   W3CsvAppend(line, "main_side");
   W3CsvAppend(line, "hedge_side");
   W3CsvAppend(line, "main_lots");
   W3CsvAppend(line, "hedge_lots");
   W3CsvAppend(line, "main_leg_floating_pl");
   W3CsvAppend(line, "hedge_leg_floating_pl");
   W3CsvAppend(line, "first_hedge_time");
   W3CsvAppend(line, "worst_floating_prehedge");
   W3CsvAppend(line, "worst_floating_posthedge");
   W3CsvAppend(line, "worst_floating_lifecycle");
   W3CsvAppend(line, "worst_floating_time");
   W3CsvAppend(line, "worst_floating_price");
   W3CsvAppend(line, "threshold_gap_yen");
   W3CsvAppend(line, "threshold_gap_price");
   W3CsvAppend(line, "close_reason");
   W3CsvAppend(line, "logger_state");
   W3CsvAppend(line, "detail");
   return line;
}

bool W3WriteLine(string line)
{
   if(!W3TelemetryEnabled())
      return false;
   W3EnsureRunId();
   int handle = FileOpen(w3LogFileName, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(handle == INVALID_HANDLE)
   {
      w3LoggerHealthy = false;
      w3LoggerOpenErrorCount++;
      w3DroppedRows++;
      if(!w3LoggerErrorPrinted)
      {
         Print("W3 telemetry log open failed. error=", GetLastError());
         w3LoggerErrorPrinted = true;
      }
      return false;
   }
   if(!w3HeaderWritten || FileSize(handle) == 0)
   {
      FileSeek(handle, 0, SEEK_END);
      if(FileWriteString(handle, W3HeaderLine() + "\r\n") <= 0)
      {
         w3LoggerHealthy = false;
         w3LoggerWriteErrorCount++;
      }
      w3HeaderWritten = true;
   }
   FileSeek(handle, 0, SEEK_END);
   bool ok = (FileWriteString(handle, line + "\r\n") > 0);
   if(!ok)
   {
      w3LoggerHealthy = false;
      w3LoggerWriteErrorCount++;
      w3DroppedRows++;
   }
   FileClose(handle);
   return ok;
}

void W3ResetRun()
{
   w3RunId = "";
   w3LogFileName = "";
   w3HeaderWritten = false;
   w3LoggerHealthy = true;
   w3LoggerErrorPrinted = false;
   w3LoggerOpenErrorCount = 0;
   w3LoggerWriteErrorCount = 0;
   w3DroppedRows = 0;
   w3EventSequence = 0;
   w3RunStartTime = TimeCurrent();
   w3BasketActive = false;
   w3BasketUid = "";
   w3BasketStartTime = 0;
   w3FirstHedgeTime = 0;
   w3LastPeriodicSnapshotTime = 0;
   w3WorstFloatingPreHedge = 0.0;
   w3WorstFloatingPostHedge = 0.0;
   w3WorstFloatingLifecycle = 0.0;
   w3WorstFloatingTime = 0;
   w3WorstFloatingPrice = 0.0;
   w3Hedged = false;
   w3HardStopConditionSeen = false;
   w3HardStopConditionTime = 0;
   w3HardStopConditionPl = 0.0;
   w3HardStopConditionLoss = 0.0;
   w3HardStopConditionDistanceYen = 0.0;
   w3HardStopConditionPrice = 0.0;
   w3BasketOpenCount = 0;
   w3HedgeTimingCount = 0;
   w3HardStopConditionCount = 0;
   w3HardStopRequestCount = 0;
   w3CloseAnchorCount = 0;
   w3WorstFloatingUpdateCount = 0;
   w3PeriodicSnapshotCount = 0;
}

void W3AppendBase(string &line,
                  string eventType,
                  string moduleName,
                  string basketUid,
                  const PositionState &ps,
                  bool hardStopNow,
                  double marginLevel,
                  const MqlTick &tick,
                  string stage,
                  string closeReason = "",
                  string detail = "")
{
   W3EnsureRunId();
   w3EventSequence++;
   datetime serverTime = (tick.time > 0 ? tick.time : TimeCurrent());
   long serverTimeMsc = (tick.time_msc > 0 ? (long)tick.time_msc : ((long)serverTime) * 1000);
   double threshold = GetHardStopThresholdYen();
   double floatingLoss = W3FloatingLossYen(ps);
   double distanceYen = W3DistanceToHardStopYen(ps, threshold);
   double mainProfit = 0.0, hedgeProfit = 0.0, mainLots = 0.0, hedgeLots = 0.0;
   string mainSide = W3_TELEMETRY_MISSING, hedgeSide = W3_TELEMETRY_MISSING;
   int positionCount = 0;
   W3LegStats(mainProfit, hedgeProfit, mainLots, hedgeLots, mainSide, hedgeSide, positionCount);
   double thresholdGapYen = W3_TELEMETRY_MISSING == "" ? 0.0 : ps.floatingProfit - w3HardStopConditionPl;
   string thresholdGapYenText = W3_TELEMETRY_MISSING;
   string thresholdGapPriceText = W3_TELEMETRY_MISSING;
   if(w3HardStopConditionSeen && (eventType == "HARDSTOP_CLOSE_REQUEST" || eventType == "CLOSE_ANCHOR"))
   {
      thresholdGapYenText = W3DoubleText(thresholdGapYen, 2);
      thresholdGapPriceText = W3DistanceToHardStopPriceText(MathAbs(thresholdGapYen));
   }

   W3CsvAppend(line, W3_TELEMETRY_SCHEMA_VERSION);
   W3CsvAppend(line, W3_TELEMETRY_BUILD_ID);
   W3CsvAppend(line, w3RunId);
   W3CsvAppend(line, IntegerToString((long)w3EventSequence));
   W3CsvAppend(line, eventType);
   W3CsvAppend(line, moduleName);
   W3CsvAppend(line, basketUid);
   W3CsvAppend(line, _Symbol);
   W3CsvAppend(line, W3TfText());
   W3CsvAppend(line, W3TimeText(serverTime));
   W3CsvAppend(line, IntegerToString((long)serverTimeMsc));
   W3CsvAppend(line, IntegerToString(runtimeEvalTickSequenceId));
   W3CsvAppend(line, stage);
   W3CsvAppend(line, W3DoubleText(tick.bid, _Digits));
   W3CsvAppend(line, W3DoubleText(tick.ask, _Digits));
   W3CsvAppend(line, W3DoubleText(tick.ask - tick.bid, _Digits));
   W3CsvAppend(line, W3DoubleText(marginLevel, 2));
   W3CsvAppend(line, IntegerToString(positionCount));
   W3CsvAppend(line, W3DoubleText(ps.floatingProfit, 2));
   W3CsvAppend(line, W3DoubleText(floatingLoss, 2));
   W3CsvAppend(line, W3DoubleText(threshold, 2));
   W3CsvAppend(line, W3DoubleText(distanceYen, 2));
   W3CsvAppend(line, W3DistanceToHardStopPriceText(distanceYen));
   W3CsvAppend(line, W3BoolText(hardStopNow));
   W3CsvAppend(line, mainSide);
   W3CsvAppend(line, hedgeSide);
   W3CsvAppend(line, W3DoubleText(mainLots, 2));
   W3CsvAppend(line, W3DoubleText(hedgeLots, 2));
   W3CsvAppend(line, W3DoubleText(mainProfit, 2));
   W3CsvAppend(line, W3DoubleText(hedgeProfit, 2));
   W3CsvAppend(line, W3TimeText(w3FirstHedgeTime));
   W3CsvAppend(line, W3DoubleText(w3WorstFloatingPreHedge, 2));
   W3CsvAppend(line, W3DoubleText(w3WorstFloatingPostHedge, 2));
   W3CsvAppend(line, W3DoubleText(w3WorstFloatingLifecycle, 2));
   W3CsvAppend(line, W3TimeText(w3WorstFloatingTime));
   W3CsvAppend(line, W3DoubleText(w3WorstFloatingPrice, _Digits));
   W3CsvAppend(line, thresholdGapYenText);
   W3CsvAppend(line, thresholdGapPriceText);
   W3CsvAppend(line, closeReason);
   W3CsvAppend(line, w3LoggerHealthy ? "OK" : "DEGRADED");
   W3CsvAppend(line, detail);
}

void W3WriteEvent(string eventType,
                  string moduleName,
                  string basketUid,
                  const PositionState &ps,
                  bool hardStopNow,
                  double marginLevel,
                  const MqlTick &tick,
                  string stage,
                  string closeReason = "",
                  string detail = "")
{
   if(!W3TelemetryEnabled())
      return;
   string line = "";
   W3AppendBase(line, eventType, moduleName, basketUid, ps, hardStopNow, marginLevel, tick, stage, closeReason, detail);
   W3WriteLine(line);
}

void W3ObservePreClose(const PositionState &ps, bool hardStopNow, double marginLevel, const MqlTick &tick, string stage)
{
   if(!W3TelemetryEnabled())
      return;
   if(ps.total <= 0)
      return;

   string uid = W3BasketUidNoRuntimeMutation(ps);
   datetime nowTime = (tick.time > 0 ? tick.time : TimeCurrent());
   bool newBasket = (!w3BasketActive || w3BasketUid != uid);
   if(newBasket)
   {
      w3BasketActive = true;
      w3BasketUid = uid;
      w3BasketStartTime = nowTime;
      w3FirstHedgeTime = 0;
      w3LastPeriodicSnapshotTime = 0;
      w3WorstFloatingPreHedge = ps.floatingProfit;
      w3WorstFloatingPostHedge = ps.floatingProfit;
      w3WorstFloatingLifecycle = ps.floatingProfit;
      w3WorstFloatingTime = nowTime;
      w3WorstFloatingPrice = (ps.net >= 0 ? tick.bid : tick.ask);
      w3Hedged = false;
      w3HardStopConditionSeen = false;
      w3HardStopConditionTime = 0;
      w3HardStopConditionPl = 0.0;
      w3HardStopConditionLoss = 0.0;
      w3HardStopConditionDistanceYen = 0.0;
      w3HardStopConditionPrice = 0.0;
      w3BasketOpenCount++;
      W3WriteEvent("BASKET_OPEN", "W3_RUNTIME", uid, ps, hardStopNow, marginLevel, tick, stage, "", "new_basket=true");
   }

   bool hedgeNow = (CountDefenseHedges() > 0);
   if(hedgeNow)
      w3Hedged = true;

   bool worstUpdate = false;
   if(ps.floatingProfit < w3WorstFloatingLifecycle)
   {
      w3WorstFloatingLifecycle = ps.floatingProfit;
      w3WorstFloatingTime = nowTime;
      w3WorstFloatingPrice = (ps.net >= 0 ? tick.bid : tick.ask);
      worstUpdate = true;
   }
   if(!w3Hedged && ps.floatingProfit < w3WorstFloatingPreHedge)
   {
      w3WorstFloatingPreHedge = ps.floatingProfit;
      worstUpdate = true;
   }
   if(w3Hedged && ps.floatingProfit < w3WorstFloatingPostHedge)
   {
      w3WorstFloatingPostHedge = ps.floatingProfit;
      worstUpdate = true;
   }
   if(worstUpdate)
   {
      w3WorstFloatingUpdateCount++;
      W3WriteEvent("WORST_FLOATING_UPDATE", "WORST_FLOATING_PL_TELEMETRY", uid, ps, hardStopNow, marginLevel, tick, stage, "", "hedged=" + W3BoolText(w3Hedged));
   }

   if(!w3HardStopConditionSeen && hardStopNow)
   {
      double threshold = GetHardStopThresholdYen();
      w3HardStopConditionSeen = true;
      w3HardStopConditionTime = nowTime;
      w3HardStopConditionPl = ps.floatingProfit;
      w3HardStopConditionLoss = W3FloatingLossYen(ps);
      w3HardStopConditionDistanceYen = W3DistanceToHardStopYen(ps, threshold);
      w3HardStopConditionPrice = (ps.net >= 0 ? tick.bid : tick.ask);
      w3HardStopConditionCount++;
      W3WriteEvent("HARDSTOP_CONDITION_TRUE", "HARDSTOP_THRESHOLD_GAP_TELEMETRY", uid, ps, hardStopNow, marginLevel, tick, stage, "", "first_true=true");
   }

   if(w3LastPeriodicSnapshotTime <= 0 || nowTime - w3LastPeriodicSnapshotTime >= 250)
   {
      w3LastPeriodicSnapshotTime = nowTime;
      w3PeriodicSnapshotCount++;
      W3WriteEvent("W3_250S_SNAPSHOT", "W3_RUNTIME", uid, ps, hardStopNow, marginLevel, tick, stage, "", "interval_seconds=250");
   }
}

void W3ObserveHedgeTiming(const PositionState &preHedgePs,
                          const PositionState &postHedgePs,
                          bool hedgeIsBuy,
                          double hedgeVolume,
                          const MqlTick &tick,
                          double marginLevel)
{
   if(!W3TelemetryEnabled())
      return;
   string uid = W3BasketUidNoRuntimeMutation(postHedgePs);
   w3BasketActive = true;
   w3BasketUid = uid;
   w3Hedged = true;
   w3FirstHedgeTime = (tick.time > 0 ? tick.time : TimeCurrent());
   w3WorstFloatingPostHedge = postHedgePs.floatingProfit;
   if(w3WorstFloatingLifecycle == 0.0 || postHedgePs.floatingProfit < w3WorstFloatingLifecycle)
      w3WorstFloatingLifecycle = postHedgePs.floatingProfit;
   w3HedgeTimingCount++;
   bool hardStopNow = IsHardStopTriggeredByBasis(postHedgePs, marginLevel);
   string detail = "hedge_side=" + (hedgeIsBuy ? "BUY" : "SELL") +
                   "|hedge_volume=" + W3DoubleText(hedgeVolume, 2) +
                   "|pre_hedge_pl=" + W3DoubleText(preHedgePs.floatingProfit, 2) +
                   "|post_hedge_pl=" + W3DoubleText(postHedgePs.floatingProfit, 2);
   W3WriteEvent("HEDGE_TIMING", "HEDGE_TIMING_TELEMETRY", uid, postHedgePs, hardStopNow, marginLevel, tick, "HEDGE_ESTABLISHED", "", detail);
}

void W3ObserveHardStopCloseRequest(const PositionState &ps, const MqlTick &tick, double marginLevel)
{
   if(!W3TelemetryEnabled())
      return;
   string uid = W3BasketUidNoRuntimeMutation(ps);
   w3HardStopRequestCount++;
   W3WriteEvent("HARDSTOP_CLOSE_REQUEST", "HARDSTOP_THRESHOLD_GAP_TELEMETRY", uid, ps, true, marginLevel, tick, "BEFORE_HARDSTOP_CLOSE_REQUEST", "hard stop emergency close", "close_request=true");
}

void W3ObserveCloseAnchor(string reason, bool contextReady, const PositionState &contextPs)
{
   if(!W3TelemetryEnabled())
      return;
   PositionState ps = contextPs;
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
   {
      tick.time = TimeCurrent();
      tick.time_msc = ((long)tick.time) * 1000;
      tick.bid = 0.0;
      tick.ask = 0.0;
   }
   double marginLevel = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);
   string uid = (w3BasketUid != "" ? w3BasketUid : (contextReady ? W3BasketUidNoRuntimeMutation(ps) : "UNKNOWN_BASKET"));
   bool hardStopClose = (StringFind(reason, "hard stop") >= 0 || StringFind(reason, "HardStop") >= 0 || StringFind(reason, "HARDSTOP") >= 0);
   w3CloseAnchorCount++;
   W3WriteEvent("CLOSE_ANCHOR", "POST_CLOSE_MOVE_REFERENCE", uid, ps, hardStopClose, marginLevel, tick, "BASKET_FINAL_CLOSE", reason, "runtime_future_move_not_calculated=true");
   w3BasketActive = false;
   w3BasketUid = "";
}

void W3WriteRunSummary(string shutdownReason)
{
   if(!W3TelemetryEnabled())
      return;
   PositionState ps;
   ps.total = 0;
   ps.buys = 0;
   ps.sells = 0;
   ps.net = 0;
   ps.floatingProfit = 0.0;
   ps.floatingLossPercent = 0.0;
   ps.avgBuy = 0.0;
   ps.avgSell = 0.0;
   MqlTick tick;
   if(!SymbolInfoTick(_Symbol, tick))
   {
      tick.time = TimeCurrent();
      tick.time_msc = ((long)tick.time) * 1000;
      tick.bid = 0.0;
      tick.ask = 0.0;
   }
   string detail = "shutdown_reason=" + shutdownReason +
                   "|basket_open_count=" + IntegerToString(w3BasketOpenCount) +
                   "|hedge_timing_count=" + IntegerToString(w3HedgeTimingCount) +
                   "|hardstop_condition_count=" + IntegerToString(w3HardStopConditionCount) +
                   "|hardstop_request_count=" + IntegerToString(w3HardStopRequestCount) +
                   "|close_anchor_count=" + IntegerToString(w3CloseAnchorCount) +
                   "|worst_floating_update_count=" + IntegerToString(w3WorstFloatingUpdateCount) +
                   "|periodic_snapshot_count=" + IntegerToString(w3PeriodicSnapshotCount) +
                   "|logger_open_errors=" + IntegerToString(w3LoggerOpenErrorCount) +
                   "|logger_write_errors=" + IntegerToString(w3LoggerWriteErrorCount) +
                   "|dropped_rows=" + IntegerToString(w3DroppedRows);
   W3WriteEvent("W3_RUN_SUMMARY", "W3_RUN_SUMMARY", "RUN", ps, false, 0.0, tick, "ON_DEINIT", shutdownReason, detail);
}

#endif
